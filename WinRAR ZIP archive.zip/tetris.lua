Renderer.LoadFontFromFile("TetrisFont", "Arial", 14, true);
Renderer.LoadFontFromFile("TetrisTitleFont", "Arial", 18, true);
Renderer.LoadFontFromFile("TetrisScoreFont", "Arial", 16, true);
local enable_tetris = Menu.Checker("Enable Tetris Game", false);
local game_x = Menu.Slider("Game X Position", 500, 0, 1920);
local game_y = Menu.Slider("Game Y Position", 100, 0, 1080);
local ghost_enabled = Menu.Checker("Show Ghost Piece", true);
local BOARD_WIDTH = 10;
local BOARD_HEIGHT = 20;
local CELL_SIZE = 24;
local GAME_WIDTH = 400;
local GAME_HEIGHT = 600;
local BACKGROUND_COLOR = Color(20, 20, 20, 200);
local BOARD_BG_COLOR = Color(10, 10, 10, 255);
local GRID_COLOR = Color(40, 40, 40, 255);
local BORDER_COLOR = Color(80, 80, 80, 255);
local TEXT_COLOR = Color(255, 255, 255, 255);
local GHOST_COLOR = Color(100, 100, 100, 100);
local TETROMINOES = {{color=Color(0, 255, 255, 255),shapes={{{0,0,0,0},{1,1,1,1},{0,0,0,0},{0,0,0,0}},{{0,0,1,0},{0,0,1,0},{0,0,1,0},{0,0,1,0}},{{0,0,0,0},{0,0,0,0},{1,1,1,1},{0,0,0,0}},{{0,1,0,0},{0,1,0,0},{0,1,0,0},{0,1,0,0}}}},{color=Color(255, 255, 0, 255),shapes={{{0,1,1,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}},{{0,1,1,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}},{{0,1,1,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}},{{0,1,1,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}}}},{color=Color(128, 0, 128, 255),shapes={{{0,1,0,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},{{0,1,0,0},{0,1,1,0},{0,1,0,0},{0,0,0,0}},{{0,0,0,0},{1,1,1,0},{0,1,0,0},{0,0,0,0}},{{0,1,0,0},{1,1,0,0},{0,1,0,0},{0,0,0,0}}}},{color=Color(0, 255, 0, 255),shapes={{{0,1,1,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},{{0,1,0,0},{0,1,1,0},{0,0,1,0},{0,0,0,0}},{{0,0,0,0},{0,1,1,0},{1,1,0,0},{0,0,0,0}},{{1,0,0,0},{1,1,0,0},{0,1,0,0},{0,0,0,0}}}},{color=Color(255, 0, 0, 255),shapes={{{1,1,0,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}},{{0,0,1,0},{0,1,1,0},{0,1,0,0},{0,0,0,0}},{{0,0,0,0},{1,1,0,0},{0,1,1,0},{0,0,0,0}},{{0,1,0,0},{1,1,0,0},{1,0,0,0},{0,0,0,0}}}},{color=Color(123, 123, 123, 255),shapes={{{1,0,0,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},{{0,1,1,0},{0,1,0,0},{0,1,0,0},{0,0,0,0}},{{0,0,0,0},{1,1,1,0},{0,0,1,0},{0,0,0,0}},{{0,1,0,0},{0,1,0,0},{1,1,0,0},{0,0,0,0}}}},{color=Color(255, 165, 0, 255),shapes={{{0,0,1,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},{{0,1,0,0},{0,1,0,0},{0,1,1,0},{0,0,0,0}},{{0,0,0,0},{1,1,1,0},{1,0,0,0},{0,0,0,0}},{{1,1,0,0},{0,1,0,0},{0,1,0,0},{0,0,0,0}}}}};
local board = {};
local current_piece = nil;
local current_x = 0;
local current_y = 0;
local current_rotation = 1;
local next_piece = nil;
local score = 0;
local lines_cleared = 0;
local level = 1;
local game_over = false;
local paused = false;
local game_started = false;
local last_drop_time = 0;
local drop_interval = 1;
local key_states = {};
local key_repeat_timers = {};
local KEY_REPEAT_DELAY = 0.15;
local KEY_REPEAT_RATE = 0.05;
local KEY_LEFT = 65;
local KEY_RIGHT = 68;
local KEY_DOWN = 83;
local KEY_UP = 87;
local KEY_SPACE = 32;
local KEY_R = 82;
local function IsKeyPressed(keycode)
	local is_down = Input.GetKeyDown(keycode);
	local was_down = key_states[keycode] or false;
	key_states[keycode] = is_down;
	return is_down and not was_down;
end
local function IsKeyHeldWithRepeat(keycode)
	local is_down = Input.GetKeyDown(keycode);
	local current_time = Globals.GetCurrentTime();
	if not is_down then
		key_repeat_timers[keycode] = nil;
		return false;
	end
	if not key_repeat_timers[keycode] then
		key_repeat_timers[keycode] = {start_time=current_time,last_repeat=current_time};
		return true;
	end
	local timer = key_repeat_timers[keycode];
	if ((current_time - timer.start_time) < KEY_REPEAT_DELAY) then
		return false;
	end
	if ((current_time - timer.last_repeat) >= KEY_REPEAT_RATE) then
		timer.last_repeat = current_time;
		return true;
	end
	return false;
end
local function InitBoard()
	board = {};
	for y = 1, BOARD_HEIGHT do
		board[y] = {};
		for x = 1, BOARD_WIDTH do
			board[y][x] = 0;
		end
	end
end
local function GetRandomPiece()
	return math.random(1, #TETROMINOES);
end
local function CanPlacePiece(piece_type, x, y, rotation)
	local shape = TETROMINOES[piece_type].shapes[rotation];
	for row = 1, 4 do
		for col = 1, 4 do
			if (shape[row][col] == 1) then
				local board_x = (x + col) - 1;
				local board_y = (y + row) - 1;
				if ((board_x < 1) or (board_x > BOARD_WIDTH) or (board_y < 1) or (board_y > BOARD_HEIGHT)) then
					return false;
				end
				if (board[board_y][board_x] ~= 0) then
					return false;
				end
			end
		end
	end
	return true;
end
local function PlacePiece()
	local shape = TETROMINOES[current_piece].shapes[current_rotation];
	for row = 1, 4 do
		for col = 1, 4 do
			if (shape[row][col] == 1) then
				local board_x = (current_x + col) - 1;
				local board_y = (current_y + row) - 1;
				board[board_y][board_x] = current_piece;
			end
		end
	end
end
local function CheckLines()
	local lines_to_clear = {};
	for y = BOARD_HEIGHT, 1, -1 do
		local full_line = true;
		for x = 1, BOARD_WIDTH do
			if (board[y][x] == 0) then
				full_line = false;
				break;
			end
		end
		if full_line then
			table.insert(lines_to_clear, y);
		end
	end
	for _, line in ipairs(lines_to_clear) do
		for y = line, 2, -1 do
			for x = 1, BOARD_WIDTH do
				board[y][x] = board[y - 1][x];
			end
		end
		for x = 1, BOARD_WIDTH do
			board[1][x] = 0;
		end
	end
	if (#lines_to_clear > 0) then
		lines_cleared = lines_cleared + #lines_to_clear;
		local line_scores = {100,300,500,800};
		score = score + ((line_scores[#lines_to_clear] or 0) * level);
		level = math.floor(lines_cleared / 10) + 1;
		drop_interval = math.max(0.1, 1 - ((level - 1) * 0.1));
	end
end
local function SpawnNewPiece()
	current_piece = next_piece or GetRandomPiece();
	next_piece = GetRandomPiece();
	current_x = 4;
	current_y = 1;
	current_rotation = 1;
	if not CanPlacePiece(current_piece, current_x, current_y, current_rotation) then
		game_over = true;
	end
end
local function GetGhostY()
	local ghost_y = current_y;
	while CanPlacePiece(current_piece, current_x, ghost_y + 1, current_rotation) do
		ghost_y = ghost_y + 1;
	end
	return ghost_y;
end
local function InitGame()
	InitBoard();
	score = 0;
	lines_cleared = 0;
	level = 1;
	drop_interval = 1;
	game_over = false;
	paused = false;
	game_started = true;
	last_drop_time = Globals.GetCurrentTime();
	next_piece = GetRandomPiece();
	SpawnNewPiece();
end
local function UpdateGame()
	if (not game_started or game_over or paused) then
		return;
	end
	local current_time = Globals.GetCurrentTime();
	if ((current_time - last_drop_time) >= drop_interval) then
		if CanPlacePiece(current_piece, current_x, current_y + 1, current_rotation) then
			current_y = current_y + 1;
		else
			PlacePiece();
			CheckLines();
			SpawnNewPiece();
		end
		last_drop_time = current_time;
	end
end
local function HandleInput()
	if not game_started then
		if IsKeyPressed(KEY_SPACE) then
			InitGame();
		end
		return;
	end
	if IsKeyPressed(KEY_SPACE) then
		paused = not paused;
	end
	if (IsKeyPressed(KEY_R) and game_over) then
		InitGame();
	end
	if (not paused and not game_over) then
		if IsKeyHeldWithRepeat(KEY_LEFT) then
			if CanPlacePiece(current_piece, current_x - 1, current_y, current_rotation) then
				current_x = current_x - 1;
			end
		end
		if IsKeyHeldWithRepeat(KEY_RIGHT) then
			if CanPlacePiece(current_piece, current_x + 1, current_y, current_rotation) then
				current_x = current_x + 1;
			end
		end
		if IsKeyHeldWithRepeat(KEY_DOWN) then
			if CanPlacePiece(current_piece, current_x, current_y + 1, current_rotation) then
				current_y = current_y + 1;
				score = score + 1;
				last_drop_time = Globals.GetCurrentTime();
			end
		end
		if IsKeyPressed(KEY_UP) then
			local new_rotation = (current_rotation % 4) + 1;
			if CanPlacePiece(current_piece, current_x, current_y, new_rotation) then
				current_rotation = new_rotation;
			end
		end
	end
end
local function RenderGame()
	if not enable_tetris:GetBool() then
		return;
	end
	local pos_x = game_x:GetInt();
	local pos_y = game_y:GetInt();
	Renderer.DrawRectFilled(Vector2D(pos_x, pos_y), Vector2D(pos_x + GAME_WIDTH, pos_y + GAME_HEIGHT), BACKGROUND_COLOR, 8);
	Renderer.DrawRect(Vector2D(pos_x, pos_y), Vector2D(pos_x + GAME_WIDTH, pos_y + GAME_HEIGHT), BORDER_COLOR, 8);
	Renderer.DrawText("TetrisTitleFont", "TETRIS", Vector2D(pos_x + (GAME_WIDTH / 2), pos_y + 10), true, true, TEXT_COLOR);
	Renderer.DrawText("TetrisScoreFont", "Score: " .. score, Vector2D(pos_x + 280, pos_y + 60), false, true, TEXT_COLOR);
	Renderer.DrawText("TetrisScoreFont", "Level: " .. level, Vector2D(pos_x + 280, pos_y + 80), false, true, TEXT_COLOR);
	Renderer.DrawText("TetrisScoreFont", "Lines: " .. lines_cleared, Vector2D(pos_x + 280, pos_y + 100), false, true, TEXT_COLOR);
	local board_x = pos_x + 20;
	local board_y = pos_y + 50;
	local board_pixel_width = BOARD_WIDTH * CELL_SIZE;
	local board_pixel_height = BOARD_HEIGHT * CELL_SIZE;
	Renderer.DrawRectFilled(Vector2D(board_x, board_y), Vector2D(board_x + board_pixel_width, board_y + board_pixel_height), BOARD_BG_COLOR, 0);
	Renderer.DrawRect(Vector2D(board_x - 2, board_y - 2), Vector2D(board_x + board_pixel_width + 2, board_y + board_pixel_height + 2), BORDER_COLOR, 0);
	for x = 1, BOARD_WIDTH - 1 do
		Renderer.DrawLine(Vector2D(board_x + (x * CELL_SIZE), board_y), Vector2D(board_x + (x * CELL_SIZE), board_y + board_pixel_height), GRID_COLOR, 1);
	end
	for y = 1, BOARD_HEIGHT - 1 do
		Renderer.DrawLine(Vector2D(board_x, board_y + (y * CELL_SIZE)), Vector2D(board_x + board_pixel_width, board_y + (y * CELL_SIZE)), GRID_COLOR, 1);
	end
	if not game_started then
		Renderer.DrawText("TetrisTitleFont", "Press SPACE to Start!", Vector2D(pos_x + (GAME_WIDTH / 2), (board_y + (board_pixel_height / 2)) - 40), true, true, TEXT_COLOR);
		Renderer.DrawText("TetrisFont", "Controls:", Vector2D(pos_x + (GAME_WIDTH / 2), board_y + (board_pixel_height / 2)), true, true, TEXT_COLOR);
		Renderer.DrawText("TetrisFont", "A/D - Move | W - Rotate | S - Soft Drop", Vector2D(pos_x + (GAME_WIDTH / 2), board_y + (board_pixel_height / 2) + 20), true, true, Color(200, 200, 200, 255));
		Renderer.DrawText("TetrisFont", "SPACE - Pause | R - Restart", Vector2D(pos_x + (GAME_WIDTH / 2), board_y + (board_pixel_height / 2) + 40), true, true, Color(200, 200, 200, 255));
		return;
	end
	for y = 1, BOARD_HEIGHT do
		for x = 1, BOARD_WIDTH do
			if (board[y][x] ~= 0) then
				local piece_type = board[y][x];
				local cell_x = board_x + ((x - 1) * CELL_SIZE);
				local cell_y = board_y + ((y - 1) * CELL_SIZE);
				Renderer.DrawRectFilled(Vector2D(cell_x + 1, cell_y + 1), Vector2D((cell_x + CELL_SIZE) - 1, (cell_y + CELL_SIZE) - 1), TETROMINOES[piece_type].color, 2);
			end
		end
	end
	if (current_piece and ghost_enabled:GetBool() and not game_over and not paused) then
		local ghost_y = GetGhostY();
		local shape = TETROMINOES[current_piece].shapes[current_rotation];
		for row = 1, 4 do
			for col = 1, 4 do
				if (shape[row][col] == 1) then
					local x = (current_x + col) - 1;
					local y = (ghost_y + row) - 1;
					if ((x >= 1) and (x <= BOARD_WIDTH) and (y >= 1) and (y <= BOARD_HEIGHT)) then
						local cell_x = board_x + ((x - 1) * CELL_SIZE);
						local cell_y = board_y + ((y - 1) * CELL_SIZE);
						Renderer.DrawRect(Vector2D(cell_x + 1, cell_y + 1), Vector2D((cell_x + CELL_SIZE) - 1, (cell_y + CELL_SIZE) - 1), GHOST_COLOR, 2);
					end
				end
			end
		end
	end
	if (current_piece and not game_over) then
		local shape = TETROMINOES[current_piece].shapes[current_rotation];
		local color = TETROMINOES[current_piece].color;
		for row = 1, 4 do
			for col = 1, 4 do
				if (shape[row][col] == 1) then
					local x = (current_x + col) - 1;
					local y = (current_y + row) - 1;
					if ((x >= 1) and (x <= BOARD_WIDTH) and (y >= 1) and (y <= BOARD_HEIGHT)) then
						local cell_x = board_x + ((x - 1) * CELL_SIZE);
						local cell_y = board_y + ((y - 1) * CELL_SIZE);
						Renderer.DrawRectFilled(Vector2D(cell_x + 1, cell_y + 1), Vector2D((cell_x + CELL_SIZE) - 1, (cell_y + CELL_SIZE) - 1), color, 2);
					end
				end
			end
		end
	end
	if next_piece then
		Renderer.DrawText("TetrisFont", "Next:", Vector2D(pos_x + 280, pos_y + 140), false, true, TEXT_COLOR);
		local preview_x = pos_x + 280;
		local preview_y = pos_y + 160;
		local preview_size = 15;
		Renderer.DrawRectFilled(Vector2D(preview_x, preview_y), Vector2D(preview_x + (preview_size * 4), preview_y + (preview_size * 4)), BOARD_BG_COLOR, 4);
		Renderer.DrawRect(Vector2D(preview_x, preview_y), Vector2D(preview_x + (preview_size * 4), preview_y + (preview_size * 4)), BORDER_COLOR, 4);
		local shape = TETROMINOES[next_piece].shapes[1];
		local color = TETROMINOES[next_piece].color;
		for row = 1, 4 do
			for col = 1, 4 do
				if (shape[row][col] == 1) then
					local cell_x = preview_x + ((col - 1) * preview_size);
					local cell_y = preview_y + ((row - 1) * preview_size);
					Renderer.DrawRectFilled(Vector2D(cell_x + 1, cell_y + 1), Vector2D((cell_x + preview_size) - 1, (cell_y + preview_size) - 1), color, 2);
				end
			end
		end
	end
	if game_over then
		Renderer.DrawRectFilled(Vector2D(board_x, (board_y + (board_pixel_height / 2)) - 60), Vector2D(board_x + board_pixel_width, board_y + (board_pixel_height / 2) + 60), Color(0, 0, 0, 200), 4);
		Renderer.DrawText("TetrisTitleFont", "GAME OVER!", Vector2D(board_x + (board_pixel_width / 2), (board_y + (board_pixel_height / 2)) - 30), true, true, Color(255, 100, 100, 255));
		Renderer.DrawText("TetrisFont", "Final Score: " .. score, Vector2D(board_x + (board_pixel_width / 2), board_y + (board_pixel_height / 2)), true, true, TEXT_COLOR);
		Renderer.DrawText("TetrisFont", "Press R to restart", Vector2D(board_x + (board_pixel_width / 2), board_y + (board_pixel_height / 2) + 25), true, true, Color(200, 200, 200, 255));
	end
	if (paused and not game_over) then
		Renderer.DrawRectFilled(Vector2D(board_x, (board_y + (board_pixel_height / 2)) - 40), Vector2D(board_x + board_pixel_width, board_y + (board_pixel_height / 2) + 40), Color(0, 0, 0, 200), 4);
		Renderer.DrawText("TetrisTitleFont", "PAUSED", Vector2D(board_x + (board_pixel_width / 2), (board_y + (board_pixel_height / 2)) - 10), true, true, Color(255, 255, 0, 255));
		Renderer.DrawText("TetrisFont", "Press SPACE to continue", Vector2D(board_x + (board_pixel_width / 2), board_y + (board_pixel_height / 2) + 15), true, true, Color(200, 200, 200, 255));
	end
	Renderer.DrawText("TetrisFont", "Controls: A/D - Move | W - Rotate", Vector2D(pos_x + 20, (pos_y + GAME_HEIGHT) - 45), false, true, Color(150, 150, 150, 255));
	Renderer.DrawText("TetrisFont", "S - Drop | SPACE - Pause | R - Restart", Vector2D(pos_x + 20, (pos_y + GAME_HEIGHT) - 25), false, true, Color(150, 150, 150, 255));
end
local function OnRender()
	if not enable_tetris:GetBool() then
		return;
	end
	HandleInput();
	UpdateGame();
	RenderGame();
end
Cheat.RegisterCallback("OnRenderer", OnRender);
math.randomseed(os.time());