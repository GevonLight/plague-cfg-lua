--// SCRIPT SETUP & FONT LOADING //--
Renderer.LoadFontFromFile("TahomaDebug23", "Tahoma", 12, true)

--// MENU OPTIONS //--
local blockbot_enable = Menu.Checker("Blockbot Enable", false, false, true)
local blocking_mode_combo = Menu.Combo("Blocking Mode", 0, {"View Angles", "Front Block"})
local autojump_enable = Menu.Checker("Auto Jump", false)

-- Custom color settings for visuals
local circle_color = Menu.Checker("Circle Color", false, true)
local on_head_color = Menu.Checker("On Head Color", false, true)
local mode_indicator_color = Menu.Checker("Mode Indicator Color", false, true)

--// GLOBAL STATE VARIABLES //--
local blockEnemy = nil
local currentTarget = nil

-- Visual smoothing
local lastDrawnTeammatePos = nil
local INTERPOLATION_ALPHA = 0.2 -- Smoothing factor for visual indicators

-- Auto-jump state
local bot_has_active_jump_command = false

-- Acceleration prediction state
local prev_block_enemy_ref_for_accel = nil
local prev_target_pos_for_accel = nil
local prev_target_vel_for_accel = nil
local prev_actual_frame_time_for_accel_calc = 0.015625 -- Default reasonable frametime

-- ADAD (A-D-A-D strafing pattern) Detection State
local prev_lateral_offset_sign_for_adad = 0 -- Stores the sign of the target's lateral movement relative to us (-1 left, 0 center, 1 right)
local adad_active_timer = 0                 -- Timer to keep ADAD countermeasures active for a short duration
local last_lateral_change_time = 0          -- Timestamp of the last lateral direction change
local adad_rhythm_streak = 0                -- Counts consecutive rhythmic ADAD reversals

-- Animated Circle State
local animated_circle_phase = 0 -- Phase for the up/down animation of the circle

--// CONSTANTS //--

-- General
local MAX_PLAYER_SPEED = 250
local MAX_PREDICTION_FRAMETIME = 0.033 -- Cap prediction frametime to avoid issues with extreme lag spikes (approx 30 FPS)
local AUTOJUMP_TARGET_Z_VEL_THRESHOLD = 200 -- Minimum vertical speed of target to trigger autojump (UPDATED FROM 100 TO 200)
local MAX_CORRECTION_DISTANCE = 100 -- Define this constant for correction speed calculation

-- On-Head Blocking Mode
local ON_HEAD_PREDICTION_FRAMES = 10
local ON_HEAD_DEADZONE_HORIZONTAL = 1
local ON_HEAD_HEIGHT_OFFSET = 72         -- How far above the target's head we aim to be
local ON_HEAD_Z_THRESHOLD = 5            -- Minimum Z distance above target to be considered "on head"
local ON_HEAD_XY_TOLERANCE = 15
local ON_HEAD_CORRECTION_TIMESCALE_FRAMES = 0.5 -- How quickly to correct position (in frames)
local ON_HEAD_CORRECTION_GAIN = 15       -- Multiplier for correction speed

-- Front Block Mode (Aggressive blocking in front of the teammate)
local FRONT_BLOCK_DISTANCE = 35          -- How far in front of the teammate to position
local FRONT_BLOCK_HEIGHT_OFFSET = 0      -- Vertical offset for the block position
local FRONT_BLOCK_DEADZONE_HORIZONTAL = 5
local FRONT_BLOCK_PREDICTION_FRAMES = 4
local FRONT_BLOCK_CORRECTION_TIMESCALE_FRAMES = 0.15
local FRONT_BLOCK_CORRECTION_GAIN = 35
local FRONT_BLOCK_VELOCITY_THRESHOLD_FOR_DIRECTION = 50 -- Min speed for target to use their velocity dir for front block

-- View Angles Mode (Side-to-side blocking, with ADAD adaptation)
local VIEW_ANGLES_MAX_STRAFE_POWER_BASE = 1.0
local VIEW_ANGLES_MAX_STRAFE_POWER_ADAD = 1.0

local VIEW_ANGLES_PREDICTION_FRAMES_ACCEL_BASE_MIN = 1
local VIEW_ANGLES_PREDICTION_FRAMES_ACCEL_BASE_MAX = 4
local VIEW_ANGLES_PREDICTION_FRAMES_ACCEL_ADAD = 1

local VIEW_ANGLES_ACCEL_DAMPING_FACTOR = 0.85

local VIEW_ANGLES_LATERAL_OFFSET_DEADZONE_BASE = 0.2
local VIEW_ANGLES_LATERAL_OFFSET_DEADZONE_ADAD = 0.05

local VIEW_ANGLES_MIN_VALID_PREV_FRAME_TIME = 0.001

-- ADAD Detection Specific Constants
local ADAD_DETECTION_MIN_SPEED_XY = 70
local ADAD_COUNTER_DURATION_SECONDS = 0.3
local ADAD_MIN_LATERAL_OFFSET_FOR_SIGN = 0.1
local ADAD_RHYTHM_WINDOW_SECONDS = 0.15
local ADAD_MIN_RHYTHM_COUNT = 2

-- Animated Circle Visuals
local ANIMATED_CIRCLE_RADIUS = 30 -- Radius for the animated circle
local ANIMATED_CIRCLE_SPEED = 2.0 -- How fast the circle moves up and down
local ANIMATED_CIRCLE_HEIGHT_RANGE = 72 -- How much the circle moves up and down (e.g., player height)
local ANIMATED_CIRCLE_BASE_Z_OFFSET = 0 -- Base Z offset (e.g., from feet)

--// HELPER FUNCTIONS //--

local function fmod(a, b)
    return a - math.floor(a / b) * b
end

local function NormalizeYaw(yaw)
    local sign = 1
    if yaw < 0 then sign = -1 end
    return (fmod(math.abs(yaw) + 180, 360) - 180) * sign
end

local function NormalizeVector(vec)
    local magnitude = math.sqrt(vec.x^2 + vec.y^2 + vec.z^2)
    if magnitude > 1e-4 then -- Avoid division by zero or near-zero
        return Vector(vec.x / magnitude, vec.y / magnitude, vec.z / magnitude)
    else
        return Vector(0, 0, 0)
    end
end

local function CheckSameXY(pos1, pos2, tolerance)
    tolerance = tolerance or 32 -- Default tolerance if not provided
    return math.abs(pos1.x - pos2.x) <= tolerance and math.abs(pos1.y - pos2.y) <= tolerance
end

local function GetTeammateViewYaw(teammatePawn)
    if teammatePawn.m_angEyeAngles then
        return teammatePawn.m_angEyeAngles.y
    end
    -- Fallback to velocity direction if eye angles are not available
    local velocity = teammatePawn.m_vecAbsVelocity or Vector(0,0,0)
    if math.sqrt(velocity.x^2 + velocity.y^2) > 10 then -- Only if moving significantly
        return math.atan2(velocity.y, velocity.x) * (180 / math.pi)
    end
    return 0 -- Default yaw
end

local function IsOnScreen(screenPos)
    if not screenPos or (screenPos.x == 0 and screenPos.y == 0) then return false end
    local screenSize = Renderer.GetScreenSize()
    return screenPos.x >= 0 and screenPos.x <= screenSize.x and screenPos.y >= 0 and screenPos.y <= screenSize.y
end

local function IsTeammateValid(teammatePawn)
    if not teammatePawn or not teammatePawn.m_pGameSceneNode then return false end
    
    local health = teammatePawn.m_iHealth or 0
    if health <= 0 then return false end
    
    if teammatePawn.m_lifeState and teammatePawn.m_lifeState ~= 0 then -- LIFE_ALIVE is 0
        return false
    end
    return true
end

local function GetLocalPlayerPawn()
    local highestIndex = Entities.GetHighestEntityIndex() or 0
    for i = 1, highestIndex do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_bIsLocalPlayerController then
            return entity.m_hPawn
        end
    end
    return nil
end

local function GetLocalPlayerPing() 
    local highest_entity_index = Entities.GetHighestEntityIndex() or 0
    for i = 1, highest_entity_index do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_bIsLocalPlayerController then
            return entity.m_iPing or 0
        end
    end
    return 0
end

local function FindBlockTeammate()
    local localPlayerControllerPawn = GetLocalPlayerPawn()
    if not localPlayerControllerPawn or not localPlayerControllerPawn.m_pGameSceneNode then
        blockEnemy = nil; currentTarget = nil
        prev_lateral_offset_sign_for_adad = 0; adad_active_timer = 0
        last_lateral_change_time = 0; adad_rhythm_streak = 0
        return
    end

    local localPlayerOrigin = localPlayerControllerPawn.m_pGameSceneNode.m_vecAbsOrigin
    local localPlayerTeam = localPlayerControllerPawn.m_iTeamNum

    -- Target stickiness: if current target is still valid and relatively close, keep them.
    if currentTarget and IsTeammateValid(currentTarget) then
        if currentTarget.m_pGameSceneNode then -- Ensure scene node exists before accessing origin
             if localPlayerOrigin:DistTo(currentTarget.m_pGameSceneNode.m_vecAbsOrigin) < 1000 then
                blockEnemy = currentTarget
                return
             end
        end
    end
    
    -- Reset current target and search for a new one
    currentTarget = nil
    local closestDistance = math.huge
    local bestTeammatePawn = nil
    local highestIndex = Entities.GetHighestEntityIndex() or 0

    for i = 1, highestIndex do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_bIsLocalPlayerController ~= nil and not entity.m_bIsLocalPlayerController and entity.m_hPawn then
            local potentialTeammatePawn = entity.m_hPawn
            if potentialTeammatePawn and potentialTeammatePawn.m_iTeamNum == localPlayerTeam and potentialTeammatePawn ~= localPlayerControllerPawn then
                if IsTeammateValid(potentialTeammatePawn) and potentialTeammatePawn.m_pGameSceneNode then
                    local teammateOrigin = potentialTeammatePawn.m_pGameSceneNode.m_vecAbsOrigin
                    local distanceToTeammate = localPlayerOrigin:DistTo(teammateOrigin)
                    
                    -- Consider a teammate if they are close enough and closer than the current best
                    if distanceToTeammate > 1 and distanceToTeammate < 800 and distanceToTeammate < closestDistance then
                        closestDistance = distanceToTeammate
                        bestTeammatePawn = potentialTeammatePawn
                    end
                end
            end
        end
    end

    blockEnemy = bestTeammatePawn
    currentTarget = bestTeammatePawn -- Set for stickiness next frame

    if not blockEnemy then -- If no target found, reset ADAD state
        prev_lateral_offset_sign_for_adad = 0
        adad_active_timer = 0
        last_lateral_change_time = 0; adad_rhythm_streak = 0
    end
end

--// CORE BLOCKBOT LOGIC //--
local function BlockbotLogic(cmd)
    if not cmd then return end

    local localPlayerPawn = GetLocalPlayerPawn()
    local local_ping = GetLocalPlayerPing()

    -- Convert ping to seconds for prediction offset
    local ping_offset_seconds = local_ping / 1000.0

    -- Calculate actual frametime for prediction, with a safe default
    local actualFrameTime = Globals.GetFrameTime() or 0.015625
    if actualFrameTime <= 0 then actualFrameTime = 0.015625 end -- Ensure positive frametime
    local predictionFrameTime = math.min(actualFrameTime, MAX_PREDICTION_FRAMETIME) -- Cap frametime for prediction

    -- Handle local player state (on ground, jump commands)
    local is_on_ground_this_frame = true
    if localPlayerPawn and localPlayerPawn.m_pGameSceneNode then
        if localPlayerPawn.m_fFlags ~= nil then
            is_on_ground_this_frame = bit.band(localPlayerPawn.m_fFlags, 1) ~= 0 -- FL_ONGROUND
        end
        -- If a jump was commanded and we are now on ground, release jump key
        if bot_has_active_jump_command and is_on_ground_this_frame then
            CVar.ExecuteClientCmd("-jump")
            bot_has_active_jump_command = false
        end
    else
        -- Invalid local player, reset jump state and exit
        if bot_has_active_jump_command then CVar.ExecuteClientCmd("-jump"); bot_has_active_jump_command = false end
        blockEnemy = nil; currentTarget = nil
        prev_lateral_offset_sign_for_adad = 0; adad_active_timer = 0
        last_lateral_change_time = 0; adad_rhythm_streak = 0
        return
    end

    -- Check if blockbot is enabled and key is pressed
    if not blockbot_enable:GetBool() or not blockbot_enable:IsDown() then
        if bot_has_active_jump_command then CVar.ExecuteClientCmd("-jump"); bot_has_active_jump_command = false end
        blockEnemy = nil; currentTarget = nil
        prev_lateral_offset_sign_for_adad = 0; adad_active_timer = 0
        last_lateral_change_time = 0; adad_rhythm_streak = 0
        return
    end

    if not Globals.IsConnected() then return end -- Not in a game

    FindBlockTeammate() -- Find or update the teammate to block

    -- Initialize acceleration variables
    local accel_x, accel_y = 0, 0

    -- Validate block target
    if not blockEnemy or not blockEnemy.m_pGameSceneNode or not IsTeammateValid(blockEnemy) then
        if bot_has_active_jump_command then CVar.ExecuteClientCmd("-jump"); bot_has_active_jump_command = false end
        blockEnemy = nil; currentTarget = nil;
        -- Reset acceleration prediction state
        prev_block_enemy_ref_for_accel = nil
        prev_target_pos_for_accel = nil
        prev_target_vel_for_accel = nil
        -- Reset ADAD state
        prev_lateral_offset_sign_for_adad = 0
        adad_active_timer = 0
        last_lateral_change_time = 0; adad_rhythm_streak = 0
        return
    end

    -- Get teammate's ping and convert to seconds for prediction offset
    local teammate_ping = blockEnemy.m_iPing or 0
    local teammate_ping_offset_seconds = teammate_ping / 1000.0

    -- Get positions and velocities
    local localPos = localPlayerPawn.m_pGameSceneNode.m_vecAbsOrigin
    local teammatePos = blockEnemy.m_pGameSceneNode.m_vecAbsOrigin
    local teammateVel = blockEnemy.m_vecAbsVelocity or Vector(0,0,0)
    local teammateSpeedXY = math.sqrt(teammateVel.x^2 + teammateVel.y^2)
    
    -- Calculate target's acceleration
    if prev_block_enemy_ref_for_accel ~= blockEnemy or not prev_target_pos_for_accel or not prev_target_vel_for_accel then
        -- New target or first time, initialize previous state
        prev_target_pos_for_accel = Vector(teammatePos.x, teammatePos.y, teammatePos.z)
        prev_target_vel_for_accel = Vector(teammateVel.x, teammateVel.y, teammateVel.z)
        prev_actual_frame_time_for_accel_calc = actualFrameTime 
        prev_block_enemy_ref_for_accel = blockEnemy
    else
        -- Calculate acceleration based on change in velocity over time
        if prev_actual_frame_time_for_accel_calc > VIEW_ANGLES_MIN_VALID_PREV_FRAME_TIME then
            local delta_vx = teammateVel.x - prev_target_vel_for_accel.x
            local delta_vy = teammateVel.y - prev_target_vel_for_accel.y
            accel_x = delta_vx / prev_actual_frame_time_for_accel_calc
            accel_y = delta_vy / prev_actual_frame_time_for_accel_calc
            
            -- Apply damping to smooth out acceleration values
            accel_x = accel_x * VIEW_ANGLES_ACCEL_DAMPING_FACTOR
            accel_y = accel_y * VIEW_ANGLES_ACCEL_DAMPING_FACTOR
        end
        -- Update previous state for next frame's calculation
        prev_target_pos_for_accel = Vector(teammatePos.x, teammatePos.y, teammatePos.z)
        prev_target_vel_for_accel = Vector(teammateVel.x, teammateVel.y, teammateVel.z)
        prev_actual_frame_time_for_accel_calc = actualFrameTime
    end
    
    -- Check if local player is on the target's head
    local isOnHead = (localPos.z - teammatePos.z) > ON_HEAD_Z_THRESHOLD and 
                     CheckSameXY(localPos, teammatePos, ON_HEAD_XY_TOLERANCE)

    -- Auto-jump logic: if enabled, not on head, target is jumping, and we are on ground
    if autojump_enable:GetBool() and 
       not isOnHead and 
       math.abs(teammateVel.z) > AUTOJUMP_TARGET_Z_VEL_THRESHOLD and 
       is_on_ground_this_frame and 
       not bot_has_active_jump_command then
        CVar.ExecuteClientCmd("+jump")
        bot_has_active_jump_command = true
    end

    -- Decrement ADAD active timer
    if adad_active_timer > 0 then
        adad_active_timer = adad_active_timer - actualFrameTime
        if adad_active_timer < 0 then adad_active_timer = 0 end
    end
    local is_adad_currently_active = adad_active_timer > 0

    --// MOVEMENT LOGIC BRANCH: ON-HEAD OR GROUND //--
    if isOnHead then
        local predFrames = ON_HEAD_PREDICTION_FRAMES
        -- Add both local and teammate ping to prediction time
        local total_pred_time = (predictionFrameTime * predFrames) + ping_offset_seconds + teammate_ping_offset_seconds

        local predictedTeammatePos = Vector(
            teammatePos.x + teammateVel.x * total_pred_time, 
            teammatePos.y + teammateVel.y * total_pred_time, 
            teammatePos.z + teammateVel.z * total_pred_time
        )

        -- Target position: center of the head (X, Y of predicted teammate origin, Z at head height)
        local targetPos = Vector(predictedTeammatePos.x, predictedTeammatePos.y, predictedTeammatePos.z + ON_HEAD_HEIGHT_OFFSET)
        
        -- Calculate needed movement relative to local player (only XY for ground movement)
        local neededMovement = Vector(targetPos.x - localPos.x, targetPos.y - localPos.y, 0)

        local finalForwardMove = 0.0
        local finalLeftMove = 0.0

        local horizontalDistanceToTarget = math.sqrt(neededMovement.x^2 + neededMovement.y^2)

        -- Apply movement only if outside the deadzone
        if horizontalDistanceToTarget > ON_HEAD_DEADZONE_HORIZONTAL then
            -- Normalize the needed movement to get a direction vector using our custom function
            local normalizedNeededMovement = NormalizeVector(neededMovement)

            local ourViewRadians = math.rad(cmd.m_angViewAngles.y)
            local cos_yaw = math.cos(ourViewRadians)
            local sin_yaw = math.sin(ourViewRadians)

            -- Calculate correction speed based on distance error
            local correctionSpeedFactor = math.min(horizontalDistanceToTarget / MAX_CORRECTION_DISTANCE, 1.0)
            local desiredTotalSpeed = teammateSpeedXY + (MAX_PLAYER_SPEED * correctionSpeedFactor)

            -- Clamp desired total speed to MAX_PLAYER_SPEED
            desiredTotalSpeed = math.min(desiredTotalSpeed, MAX_PLAYER_SPEED)

            -- Calculate movement scale based on desired total speed
            local movementScale = 0
            if MAX_PLAYER_SPEED > 1e-5 then
                movementScale = desiredTotalSpeed / MAX_PLAYER_SPEED
            end

            -- Convert normalizedNeededMovement to local player's forward/left axes
            -- And apply scaled speed
            finalForwardMove = (normalizedNeededMovement.x * cos_yaw + normalizedNeededMovement.y * sin_yaw) * movementScale
            finalLeftMove = (-normalizedNeededMovement.x * sin_yaw + normalizedNeededMovement.y * cos_yaw) * movementScale

            -- Clamp to -1.0 to 1.0 (full movement) - this is still important for safety
            finalForwardMove = math.max(-1.0, math.min(1.0, finalForwardMove))
            finalLeftMove = math.max(-1.0, math.min(1.0, finalLeftMove))
        end
        -- If within deadzone, finalForwardMove and finalLeftMove remain 0.0, effectively quick stopping.

        cmd.m_flForwardMove = finalForwardMove
        cmd.m_flLeftMove = finalLeftMove
    else -- GROUND LOGIC (View Angles or Front Block)
        local selectedMode = blocking_mode_combo:GetInt()

        if selectedMode == 0 then -- View Angles Mode
            cmd.m_flLeftMove = 0.0
            
            -- Adaptive Prediction: Adjust prediction frames based on target speed (when not in ADAD mode)
            local speed_factor = math.max(0, math.min(1, teammateSpeedXY / MAX_PLAYER_SPEED)) -- Normalize speed 0-1
            local dynamic_pred_frames_base = VIEW_ANGLES_PREDICTION_FRAMES_ACCEL_BASE_MIN + 
                                             (VIEW_ANGLES_PREDICTION_FRAMES_ACCEL_BASE_MAX - VIEW_ANGLES_PREDICTION_FRAMES_ACCEL_BASE_MIN) * speed_factor
            
            local current_prediction_frames_accel = dynamic_pred_frames_base
            if is_adad_currently_active then
                current_prediction_frames_accel = VIEW_ANGLES_PREDICTION_FRAMES_ACCEL_ADAD -- Override with ADAD specific short prediction
            end
            
            -- Calculate predicted target position using velocity and acceleration
            -- Add both local and teammate ping to prediction time
            local pred_time_seconds = (predictionFrameTime * current_prediction_frames_accel) + ping_offset_seconds + teammate_ping_offset_seconds
            
            local predicted_x = teammatePos.x + (teammateVel.x * pred_time_seconds) + (0.5 * accel_x * pred_time_seconds^2)
            local predicted_y = teammatePos.y + (teammateVel.y * pred_time_seconds) + (0.5 * accel_y * pred_time_seconds^2)
            local targetPosForLateralCalc = Vector(predicted_x, predicted_y, teammatePos.z)
            
            -- Calculate lateral offset: how far left/right the target is relative to our facing direction
            local vectorToTarget = Vector(targetPosForLateralCalc.x - localPos.x, targetPosForLateralCalc.y - localPos.y, 0)
            local currentYawRad = math.rad(cmd.m_angViewAngles.y)
            local localRightVectorX = math.sin(currentYawRad)
            local localRightVectorY = -math.cos(currentYawRad)
            local lateralOffset = vectorToTarget.x * localRightVectorX + vectorToTarget.y * localRightVectorY

            -- ADAD Detection Logic: Check for reversals in lateral movement
            local current_lateral_offset_sign = 0
            if math.abs(lateralOffset) > ADAD_MIN_LATERAL_OFFSET_FOR_SIGN then
                 current_lateral_offset_sign = lateralOffset > 0 and 1 or -1 -- 1 for right, -1 for left
            end

            local current_time = Globals.GetCurrentTime() or 0

            if teammateSpeedXY > ADAD_DETECTION_MIN_SPEED_XY and
               current_lateral_offset_sign ~= 0 and
               prev_lateral_offset_sign_for_adad ~= 0 and
               current_lateral_offset_sign ~= prev_lateral_offset_sign_for_adad then -- Sign must have changed (reversal)
                
                local time_since_last_change = current_time - last_lateral_change_time
                if time_since_last_change > 0 and time_since_last_change <= ADAD_RHYTHM_WINDOW_SECONDS then
                    adad_rhythm_streak = adad_rhythm_streak + 1
                else
                    adad_rhythm_streak = 1 -- Reset streak if rhythm is broken or first reversal
                end
                last_lateral_change_time = current_time -- Update last change time

                if adad_rhythm_streak >= ADAD_MIN_RHYTHM_COUNT then
                    adad_active_timer = ADAD_COUNTER_DURATION_SECONDS -- Activate/Refresh ADAD countermeasures
                    is_adad_currently_active = true                   -- Update for this frame's logic
                end
            else
                -- If no reversal or conditions not met, reset streak
                adad_rhythm_streak = 0
                last_lateral_change_time = current_time -- Keep updating for future checks
            end
            prev_lateral_offset_sign_for_adad = current_lateral_offset_sign -- Store for next frame's comparison

            -- Apply Dynamic Deadzone and Strafe Power based on ADAD state
            local effective_deadzone = VIEW_ANGLES_LATERAL_OFFSET_DEADZONE_BASE
            local effective_strafe_power = VIEW_ANGLES_MAX_STRAFE_POWER_BASE
            if is_adad_currently_active then
                effective_deadzone = VIEW_ANGLES_LATERAL_OFFSET_DEADZONE_ADAD
                effective_strafe_power = VIEW_ANGLES_MAX_STRAFE_POWER_ADAD
            end
            
            -- Apply strafe movement if outside the deadzone
            if math.abs(lateralOffset) > effective_deadzone then
                if lateralOffset > 0 then 
                    cmd.m_flLeftMove = -effective_strafe_power -- Target is to our right, so we move left
                else 
                    cmd.m_flLeftMove = effective_strafe_power  -- Target is to our left, so we move right
                end
            end

        elseif selectedMode == 1 then -- Front Block Mode
            -- Reset ADAD state if switching out of View Angles mode
            prev_lateral_offset_sign_for_adad = 0 
            adad_active_timer = 0
            last_lateral_change_time = 0; adad_rhythm_streak = 0
            is_adad_currently_active = false

            local predFramesFB = FRONT_BLOCK_PREDICTION_FRAMES
            -- Add both local and teammate ping to prediction time
            local total_pred_time_fb = (predictionFrameTime * predFramesFB) + ping_offset_seconds + teammate_ping_offset_seconds

            local predTargetPosFB = Vector(
                teammatePos.x + teammateVel.x * total_pred_time_fb,
                teammatePos.y + teammateVel.y * total_pred_time_fb,
                teammatePos.z
            )
            
            local targetForwardAngleDegreesFB
            if teammateSpeedXY > FRONT_BLOCK_VELOCITY_THRESHOLD_FOR_DIRECTION and (teammateVel.x ~= 0 or teammateVel.y ~= 0) then
                targetForwardAngleDegreesFB = math.atan2(teammateVel.y, teammateVel.x) * (180 / math.pi) -- Use velocity direction
            else
                targetForwardAngleDegreesFB = GetTeammateViewYaw(blockEnemy) -- Use teammate's view yaw
            end
            
            local angleRadiansFB = math.rad(targetForwardAngleDegreesFB)
            local blockPositionFB = Vector(
                predTargetPosFB.x + math.cos(angleRadiansFB) * FRONT_BLOCK_DISTANCE, 
                predTargetPosFB.y + math.sin(angleRadiansFB) * FRONT_BLOCK_DISTANCE, 
                predTargetPosFB.z + FRONT_BLOCK_HEIGHT_OFFSET
            )
            
            local neededMoveFB = Vector(blockPositionFB.x - localPos.x, blockPositionFB.y - localPos.y, 0)
            local distToTargetXY_FB = math.sqrt(neededMoveFB.x^2 + neededMoveFB.y^2)
            
            local fwdMoveFB, leftMoveFB = 0.0, 0.0
            if distToTargetXY_FB > FRONT_BLOCK_DEADZONE_HORIZONTAL then
                local corrTimeFB = predictionFrameTime * math.max(0.001, FRONT_BLOCK_CORRECTION_TIMESCALE_FRAMES)
                if corrTimeFB <= 1e-5 then corrTimeFB = 1e-5 end
                
                local speedGapCloseFB = (distToTargetXY_FB / corrTimeFB) * FRONT_BLOCK_CORRECTION_GAIN
                local desiredSpeedFB = math.min(teammateSpeedXY + speedGapCloseFB, MAX_PLAYER_SPEED)
                
                local normMoveFB = NormalizeVector(neededMoveFB)
                local viewRadFB = math.rad(cmd.m_angViewAngles.y)
                local cosY_fb, sinY_fb = math.cos(viewRadFB), math.sin(viewRadFB)
                
                local moveScaleFB = 0
                if MAX_PLAYER_SPEED > 0.001 then moveScaleFB = desiredSpeedFB / MAX_PLAYER_SPEED end
                
                fwdMoveFB = (normMoveFB.x * cosY_fb + normMoveFB.y * sinY_fb) * moveScaleFB
                leftMoveFB = (-normMoveFB.x * sinY_fb + normMoveFB.y * cosY_fb) * moveScaleFB
            end
            cmd.m_flForwardMove = math.max(-1, math.min(1, fwdMoveFB))
            cmd.m_flLeftMove = math.max(-1, math.min(1, leftMoveFB))
        end
    end
end

--// VISUAL INDICATORS //--
local function DrawPlayerIndicators()
    if not blockbot_enable:GetBool() or not blockbot_enable:IsDown() then return end
    if not blockEnemy or not blockEnemy.m_pGameSceneNode then return end

    local teammatePosRaw = blockEnemy.m_pGameSceneNode.m_vecAbsOrigin
    local teammateVel = blockEnemy.m_vecAbsVelocity or Vector(0,0,0)

    local actualFrameTime = Globals.GetFrameTime() or 0.015625
    if actualFrameTime <= 0 then actualFrameTime = 0.015625 end
    local predFrameTimeForVisuals = math.min(actualFrameTime, MAX_PREDICTION_FRAMETIME)
    
    local visualPredictionFrames = 4 -- How many frames ahead to predict for the visual indicator
    local predictedTeammateVisualPos = Vector(
        teammatePosRaw.x + teammateVel.x * predFrameTimeForVisuals * visualPredictionFrames, 
        teammatePosRaw.y + teammateVel.y * predFrameTimeForVisuals * visualPredictionFrames, 
        teammatePosRaw.z + teammateVel.z * predFrameTimeForVisuals * visualPredictionFrames
    )

    -- Interpolate visual position for smoothness
    local interpolatedPos
    if lastDrawnTeammatePos then
        interpolatedPos = Vector(
            lastDrawnTeammatePos.x + (predictedTeammateVisualPos.x - lastDrawnTeammatePos.x) * INTERPOLATION_ALPHA,
            lastDrawnTeammatePos.y + (predictedTeammateVisualPos.y - lastDrawnTeammatePos.y) * INTERPOLATION_ALPHA,
            lastDrawnTeammatePos.z + (predictedTeammateVisualPos.z - lastDrawnTeammatePos.z) * INTERPOLATION_ALPHA
        )
    else
        interpolatedPos = predictedTeammateVisualPos
    end
    lastDrawnTeammatePos = interpolatedPos -- Store for next frame's interpolation

    -- Get screen positions for drawing
    local screenPosTargetFeet = Renderer.WorldToScreen(interpolatedPos)

    if not IsOnScreen(screenPosTargetFeet) then return end

    -- Define colors based on menu settings or defaults
    local baseCircleColor = circle_color:GetBool() and circle_color:GetColor() or Color(0, 255, 255, 255) -- Cyan
    local onHeadCircleColor = on_head_color:GetBool() and on_head_color:GetColor() or Color(255, 255, 0, 255) -- Yellow
    
    local localPlayerPawnForDraw = GetLocalPlayerPawn()
    if not localPlayerPawnForDraw or not localPlayerPawnForDraw.m_pGameSceneNode then return end
    
    local localPlayerPosForDraw = localPlayerPawnForDraw.m_pGameSceneNode.m_vecAbsOrigin
    local currentTargetPosForDraw = blockEnemy.m_pGameSceneNode.m_vecAbsOrigin
    
    local isPlayerOnHeadForDraw = (localPlayerPosForDraw.z - currentTargetPosForDraw.z) > ON_HEAD_Z_THRESHOLD and 
                                  CheckSameXY(localPlayerPosForDraw, currentTargetPosForDraw, ON_HEAD_XY_TOLERANCE)

    -- Draw main circle around target
    if IsOnScreen(screenPosTargetFeet) then
        if isPlayerOnHeadForDraw then
            Renderer.DrawCircleGradient3D(interpolatedPos, onHeadCircleColor, Color(onHeadCircleColor.r, onHeadCircleColor.g, onHeadCircleColor.b, 100), 25)
            Renderer.DrawCircle3D(interpolatedPos, onHeadCircleColor, 35)
        else
            Renderer.DrawCircleGradient3D(interpolatedPos, baseCircleColor, Color(baseCircleColor.r, baseCircleColor.g, baseCircleColor.b, 50), 20)
            
            -- Update animated circle phase
            animated_circle_phase = animated_circle_phase + (Globals.GetFrameTime() * ANIMATED_CIRCLE_SPEED)
            if animated_circle_phase > math.pi * 2 then
                animated_circle_phase = animated_circle_phase - (math.pi * 2)
            end

            -- Calculate Z offset for the animated circle (moves from feet to head)
            local z_offset_animated_circle = ANIMATED_CIRCLE_BASE_Z_OFFSET + 
                                             (math.sin(animated_circle_phase) * 0.5 + 0.5) * ANIMATED_CIRCLE_HEIGHT_RANGE

            local animatedCirclePos = Vector(interpolatedPos.x, interpolatedPos.y, interpolatedPos.z + z_offset_animated_circle)

            -- Draw animated circle
            Renderer.DrawCircle3D(animatedCirclePos, baseCircleColor, ANIMATED_CIRCLE_RADIUS)
        end
    end

    -- Draw line from local player to target (if not on head)
    if not isPlayerOnHeadForDraw then
        local localPlayerScreenPos = Renderer.WorldToScreen(localPlayerPosForDraw)
        if IsOnScreen(localPlayerScreenPos) and IsOnScreen(screenPosTargetFeet) then
            Renderer.DrawLine(localPlayerScreenPos, screenPosTargetFeet, Color(baseCircleColor.r, baseCircleColor.g, baseCircleColor.b, 100), 2)
        end
    end
end

--// REGISTER CALLBACKS //--
Cheat.RegisterCallback("OnPreCreateMove", function(cmd) BlockbotLogic(cmd) end)
Cheat.RegisterCallback("OnRenderer", function() DrawPlayerIndicators() end)
