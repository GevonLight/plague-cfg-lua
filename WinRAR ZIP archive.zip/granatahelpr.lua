package.path = "C:\\plaguecheat.cc\\lib\\?.lua;" .. package.path

local ini = require("LIP")
local GUI = require("plague_gui")

local modernDark           = Color(25, 25, 28, 240)
local modernDarkSecondary  = Color(32, 32, 36, 220)
local modernDarkAccent     = Color(40, 40, 44, 200)
local modernBlue           = Color(100, 150, 255, 200)
local modernBlueHighlight  = Color(120, 170, 255, 240)
local modernGreen          = Color(100, 255, 150, 200)
local modernGreenHighlight = Color(0, 184, 68, 240)
local modernYellow         = Color(255, 200, 80, 200)
local modernYellowHighlight= Color(255, 220, 100, 240)
local modernRed            = Color(255, 100, 100, 200)
local modernRedHighlight   = Color(255, 120, 120, 240)
local modernText           = Color(245, 245, 245, 255)
local modernTextSecondary  = Color(180, 180, 180, 255)
local modernTextMuted      = Color(140, 140, 145, 255)
local modernBorder         = Color(60, 60, 65, 180)
local modernAccent         = Color(0, 122, 255, 200)
local modernSuccess        = Color(52, 199, 89, 200)

Renderer.LoadFontFromFile("Verdana", "Poppins-Medium.ttf", 15, 1)
Renderer.LoadFontFromFile("VerdanaBold", "Poppins-Medium.ttf", 17, 1)
local dotSize = 6

local standingRadius = 50.0

local mouseHoverSpot = nil
local mouseHoverRadius = 15.0

local function IsOnScreen(pos, width, height)
    if not pos then return false end
    return pos.x >= 0 and pos.y >= 0 and pos.x <= width and pos.y <= height
end

local function IsMouseHovering(screenPos, radius)
    if not screenPos then return false end
    local mousePos = Input.GetCursorPos()
    if not mousePos then return false end
    
    local dx = mousePos.x - screenPos.x
    local dy = mousePos.y - screenPos.y
    local distance = math.sqrt(dx * dx + dy * dy)
    
    return distance <= radius
end

local CONFIG_PATH = "C:\\plaguecheat.cc\\config\\granatahelper.ini"
local currentSpots = {}
local selectedSpotName = nil

local currentWeaponName = "UNKNOWN"

local movementState = "MOVING_TO_STAND"
local lastTargetSpot = nil
local standPosReachedTime = 0
local STAND_POS_HOLD_TIME = 0.3
local commandsExecuted = false
local crouchState = "NONE"
local crouchStartTime = 0
local CROUCH_DELAY_TIME = 0.25

local movementStrategies = {
    "direct",
    "arc_left",
    "arc_right",
    "backwards_then_forward",
    "zigzag"
}
local currentStrategyIndex = 1

local function GetCurrentWeapon()
    for i = 1, 64 do
        local entity = Entities.GetEntityFromIndex(i)
        if entity ~= nil then
            if entity.m_bIsLocalPlayerController then
                local pawn = entity.m_hPawn
                if pawn ~= nil then
                   local wpn_services = pawn.m_pWeaponServices
                   if wpn_services ~= nil then
                      local weapon = Entities.GetEntityFromIndex(wpn_services.m_hActiveWeapon)
                        if weapon ~= nil then
                           return Entities.GetDesignerName(weapon)
                        end
                   end
                end
            end
        end
    end
    return "UNKNOWN"
end

local function DoesWeaponMatchSpot(weaponName, spotGrenadeType)
    if not weaponName or not spotGrenadeType then return false end
    
    local weaponToGrenadeMap = {
        ["weapon_hegrenade"] = {"HE Grenade", "grenade_placeholder"},
        ["weapon_smokegrenade"] = {"Smoke", "grenade_placeholder"},
        ["weapon_flashbang"] = {"Flash", "grenade_placeholder"},
        ["weapon_molotov"] = {"Molotov", "grenade_placeholder"},
        ["weapon_incgrenade"] = {"Molotov", "grenade_placeholder"}
    }
    
    local grenadeTypes = weaponToGrenadeMap[weaponName]
    if not grenadeTypes then return false end
    
    for _, grenadeType in ipairs(grenadeTypes) do
        if spotGrenadeType == grenadeType then
            return true
        end
    end
    
    return false
end


local function LoadWallbangSpots()
    local spots = {}
    local iniData = ini.load(CONFIG_PATH)
    
    for section, data in pairs(iniData) do
        if data.map and data.name and data.grenade then
            local renderRadius = data.renderRadius or data.radius or 60.0
            local triggerRadius = data.triggerRadius or 30.0
            
            if triggerRadius >= renderRadius then
                print("[LoadWallbangSpots] ERROR: Spot '" .. data.name .. "' has triggerRadius (" .. triggerRadius .. ") >= renderRadius (" .. renderRadius .. "). Skipping this spot!")
                goto continue
            end
            
            local spot = {
                map = data.map,
                name = data.name,
                grenade = data.grenade,
                instruction = data.instruction,
                renderRadius = renderRadius,
                triggerRadius = triggerRadius,
                standPos_x = data.standPos_x,
                standPos_y = data.standPos_y,
                standPos_z = data.standPos_z,
                aimPos_x = data.aimPos_x,
                aimPos_y = data.aimPos_y,
                aimPos_z = data.aimPos_z,
                standPos = Vector(data.standPos_x, data.standPos_y, data.standPos_z),
                aimPos = Vector(data.aimPos_x, data.aimPos_y, data.aimPos_z)
            }
            table.insert(spots, spot)
            currentSpots[data.name] = {
                section = section,
                data = spot
            }
        end
        ::continue::
    end
    
    return spots
end

local function SaveSpotToIni(section, data)
    local iniData = ini.load(CONFIG_PATH)
    
    iniData[section] = iniData[section] or {}
    
    iniData[section].map = data.map
    iniData[section].name = data.name
    iniData[section].grenade = data.grenade
    iniData[section].instruction = data.instruction
    iniData[section].renderRadius = data.renderRadius
    iniData[section].triggerRadius = data.triggerRadius
    iniData[section].standPos_x = data.standPos_x
    iniData[section].standPos_y = data.standPos_y
    iniData[section].standPos_z = data.standPos_z
    iniData[section].aimPos_x = data.aimPos_x
    iniData[section].aimPos_y = data.aimPos_y
    iniData[section].aimPos_z = data.aimPos_z
    
    ini.save(CONFIG_PATH, iniData)
    
    wbSpots = LoadWallbangSpots()
	print("[DEBUG] Yo i loaded the spots next is reload.")
	LoadWallbangSpots()
    print("[SaveSpotToIni] Saved spot: " .. data.name)
end

local initialRawMapName = Globals.GetMapName() or ""
local initialMapName = initialRawMapName:gsub("^maps/",""):gsub("%.bsp$",""):gsub("%.vpk$","")
local wbSpots = LoadWallbangSpots()

local showWatermarkCheckbox = Menu.Checker("Show Watermark", true)
local showEditorCheckbox = Menu.Checker("GUI Grenade Spot Editor", false)
local showCoordinatesCheckbox = Menu.Checker("Show Coordinates & Weapon", false)
local rainbowModeCheckbox = Menu.Checker("Rainbow Mode", true)
local viewangleModificationCheckbox = Menu.Checker("Auto Grenade Throw", false, false, true)
local themeSelector = Menu.Combo("Theme", 0, {"Aero", "Chromatic"})

local trailParticles = {}
local maxTrailAge = 3.0
local trailSpawnRate = 0.05

local function GetDistance3D(a, b)
    if not a or not b then return math.huge end
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return math.sqrt(dx*dx + dy*dy + dz*dz)
end

local function GetDistance2D(a, b)
    if not a or not b then return math.huge end
    local dx, dy = a.x - b.x, a.y - b.y
    return math.sqrt(dx*dx + dy*dy)
end

local function FormatCoord(v) return string.format("%.2f", v) end

local function fmod(a, b)
    return a - math.floor(a / b) * b
end

local function NormalizeYaw(yaw)
    local sign = 1
    if yaw < 0 then sign = -1 end
    return (fmod(math.abs(yaw) + 180, 360) - 180) * sign
end

local function CalculateViewAngles(fromPos, toPos)
    if not fromPos or not toPos then return nil end
    
    local dx = toPos.x - fromPos.x
    local dy = toPos.y - fromPos.y
    local dz = toPos.z - fromPos.z
    
    local yaw = math.atan2(dy, dx) * (180 / math.pi)
    
    local horizontal_distance = math.sqrt(dx*dx + dy*dy)
    local pitch = math.atan2(-dz, horizontal_distance) * (180 / math.pi)
    
    return Vector(pitch, yaw, 0)
end

local function NormalizeAngle(angle)
    while angle > 180 do
        angle = angle - 360
    end
    while angle < -180 do
        angle = angle + 360
    end
    return angle
end

local function FindClosestActiveAimSpot()
    if not viewangleModificationCheckbox:GetBool() then return nil end
    
    local localPlayer = nil
    for i = 1, Entities.GetHighestEntityIndex() do
        local e = Entities.GetEntityFromIndex(i)
        if e and e.m_bIsLocalPlayerController then
            localPlayer = e.m_hPawn
            break
        end
    end
    
    if not localPlayer or not localPlayer.m_pGameSceneNode then return nil end
    
    local origin = localPlayer.m_pGameSceneNode.m_vecAbsOrigin
    if not origin then return nil end
    
    local rawMapName = Globals.GetMapName() or ""
    local mapName = rawMapName:gsub("^maps/",""):gsub("%.bsp$",""):gsub("%.vpk$","")
    
    local currentWeapon = GetCurrentWeapon()
    
    local closestSpot = nil
    local closestDistance = math.huge
    
    for _, spot in ipairs(wbSpots) do
        if spot.map == mapName and DoesWeaponMatchSpot(currentWeapon, spot.grenade) then
            local dist = GetDistance3D(origin, spot.standPos)
            if dist <= spot.triggerRadius then
                if dist < closestDistance then
                    closestDistance = dist
                    closestSpot = spot
                end
            end
        end
    end
    
    return closestSpot
end

local function GetLocalPlayerPawn()
    local highestIndex = Entities.GetHighestEntityIndex() or 0
    for i = 1, highestIndex do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_bIsLocalPlayerController then
            return entity.m_hPawn
        end
    end
    return nil
end

local function fix_movement(cmd, original_yaw, new_yaw)
    local yaw_delta = new_yaw - original_yaw
    
    while yaw_delta > 180 do yaw_delta = yaw_delta - 360 end
    while yaw_delta < -180 do yaw_delta = yaw_delta + 360 end
    
    local yaw_delta_rad = math.rad(yaw_delta)
    local cos_yaw = math.cos(yaw_delta_rad)
    local sin_yaw = math.sin(yaw_delta_rad)
    
    local old_forward = cmd.m_flForwardMove
    local old_side = cmd.m_flLeftMove
    
    cmd.m_flForwardMove = old_forward * cos_yaw + old_side * sin_yaw
    cmd.m_flLeftMove = old_side * cos_yaw - old_forward * sin_yaw
    
    cmd.m_flForwardMove = math.max(-1.0, math.min(1.0, cmd.m_flForwardMove))
    cmd.m_flLeftMove = math.max(-1.0, math.min(1.0, cmd.m_flLeftMove))
end

local function ViewAngleModification(cmd)
    if not viewangleModificationCheckbox:GetBool() then return end
    if not viewangleModificationCheckbox:IsDown() then return end
    if not Globals.IsConnected() then return end
    local localPlayerPawn = GetLocalPlayerPawn()
    if not localPlayerPawn or not localPlayerPawn.m_pGameSceneNode then return end
    
    local origin = localPlayerPawn.m_pGameSceneNode.m_vecAbsOrigin
    if not origin then return end
    local eyeHeight = 64
    if crouchState == "DUCKING" or crouchState == "READY_TO_THROW" then
        eyeHeight = 46
    end
    local eyePos = Vector(origin.x, origin.y, origin.z + eyeHeight)
    local original_yaw = cmd.m_angViewAngles.y
    while original_yaw > 180 do original_yaw = original_yaw - 360 end
    while original_yaw < -180 do original_yaw = original_yaw + 360 end
    local rawMapName = Globals.GetMapName() or ""
    local mapName = rawMapName:gsub("^maps/",""):gsub("%.bsp$",""):gsub("%.vpk$","")
    local currentWeapon = GetCurrentWeapon()
    
    local closestSpot = nil
    local closestDistance = math.huge
    
    for _, spot in ipairs(wbSpots) do
        if spot.map == mapName and DoesWeaponMatchSpot(currentWeapon, spot.grenade) then
            local dist3D = GetDistance3D(origin, spot.standPos)
            local dist2D = GetDistance2D(origin, spot.standPos)
            if dist3D <= spot.triggerRadius and dist2D <= spot.triggerRadius then
                if dist3D < closestDistance then
                    closestDistance = dist3D
                    closestSpot = spot
                end
            end
        end
    end
    
    if not closestSpot then 
        movementState = "MOVING_TO_STAND"
        lastTargetSpot = nil
        commandsExecuted = false
        crouchState = "NONE"
        return 
    end
    if lastTargetSpot ~= closestSpot then
        movementState = "MOVING_TO_STAND"
        lastTargetSpot = closestSpot
        standPosReachedTime = 0
        commandsExecuted = false
        crouchState = "NONE"
    end
    
    local targetStandPos = closestSpot.standPos
    local neededMovement = Vector(targetStandPos.x - origin.x, targetStandPos.y - origin.y, 0)
    local horizontalDistanceToStand = math.sqrt(neededMovement.x^2 + neededMovement.y^2)
    
    local standMovementDeadzone = math.min(5.0, closestSpot.triggerRadius * 0.2)
    local currentTime = Globals.GetCurrentTime()
    
    if movementState == "MOVING_TO_STAND" then
        
        if horizontalDistanceToStand > standMovementDeadzone then
            local normalizedNeededMovement = Vector(0, 0, 0)
            local magnitude = math.sqrt(neededMovement.x^2 + neededMovement.y^2)
            if magnitude > 0.1 then
                normalizedNeededMovement.x = neededMovement.x / magnitude
                normalizedNeededMovement.y = neededMovement.y / magnitude
                normalizedNeededMovement.z = 0
            end

            local ourViewRadians = math.rad(original_yaw)
            local cos_yaw = math.cos(ourViewRadians)
            local sin_yaw = math.sin(ourViewRadians)

            local movementScale = 1.0

            local finalForwardMove = (normalizedNeededMovement.x * cos_yaw + normalizedNeededMovement.y * sin_yaw) * movementScale
            local finalLeftMove = (-normalizedNeededMovement.x * sin_yaw + normalizedNeededMovement.y * cos_yaw) * movementScale

            finalForwardMove = math.max(-1.0, math.min(1.0, finalForwardMove))
            finalLeftMove = math.max(-1.0, math.min(1.0, finalLeftMove))
            
            cmd.m_flForwardMove = finalForwardMove
            cmd.m_flLeftMove = finalLeftMove
            
            local debugTick = Globals.GetTickCount() or 0
            if debugTick % 60 == 0 then
                print("[GrenadeHelper] MOVING TO: " .. closestSpot.name .. " | Distance: " .. string.format("%.1f", horizontalDistanceToStand) .. " | TriggerRadius: " .. closestSpot.triggerRadius .. " | Movement: " .. string.format("%.3f", finalForwardMove) .. ", " .. string.format("%.3f", finalLeftMove))
            end
        else
            if standPosReachedTime == 0 then
                standPosReachedTime = currentTime
                print("[GrenadeHelper] REACHED standPos for: " .. closestSpot.name .. " | Quick aim transition...")
            end
            
            if (currentTime - standPosReachedTime) >= STAND_POS_HOLD_TIME then
                movementState = "AIMING"
                print("[GrenadeHelper] SWITCHING TO AIMING MODE for: " .. closestSpot.name)
            end
            
            cmd.m_flForwardMove = 0.0
            cmd.m_flLeftMove = 0.0
        end
        
    elseif movementState == "AIMING" then
        
        if horizontalDistanceToStand > standMovementDeadzone * 2.0 then
            movementState = "MOVING_TO_STAND"
            standPosReachedTime = 0
            commandsExecuted = false
            crouchState = "NONE"
            print("[GrenadeHelper] Player moved away from standPos, returning to movement phase")
            return
        end
        
        cmd.m_flForwardMove = 0.0
        cmd.m_flLeftMove = 0.0
        
        local delta_x = closestSpot.aimPos.x - eyePos.x
        local delta_y = closestSpot.aimPos.y - eyePos.y
        local delta_z = closestSpot.aimPos.z - eyePos.z
        
        local yaw = math.atan2(delta_y, delta_x) * (180 / math.pi)
        local horizontal_distance = math.sqrt(delta_x*delta_x + delta_y*delta_y)
        local pitch = math.atan2(-delta_z, horizontal_distance) * (180 / math.pi)
        
        while yaw > 180 do yaw = yaw - 360 end
        while yaw < -180 do yaw = yaw + 360 end
        pitch = math.max(-89, math.min(89, pitch))
        
        cmd.m_angViewAngles = Vector(pitch, yaw, cmd.m_angViewAngles.z)
        
        if not commandsExecuted then
            local instruction = closestSpot.instruction or "Stand"
            
            if instruction == "Stand" then
                CVar.ExecuteClientCmd("+attack")
                CVar.ExecuteClientCmd("-attack")
                print("[GrenadeHelper] Executed STAND throw sequence for: " .. closestSpot.name)
                commandsExecuted = true
                
            elseif instruction == "Jump" then
                CVar.ExecuteClientCmd("+attack")
                CVar.ExecuteClientCmd("-attack")
                CVar.ExecuteClientCmd("+jump")
                CVar.ExecuteClientCmd("-jump")
                print("[GrenadeHelper] Executed JUMP throw sequence for: " .. closestSpot.name)
                commandsExecuted = true
                
            elseif instruction == "Crouch" then
                if crouchState == "NONE" then
                    CVar.ExecuteClientCmd("+duck")
                    crouchState = "DUCKING"
                    crouchStartTime = currentTime
                    print("[GrenadeHelper] Started CROUCH sequence for: " .. closestSpot.name .. " | Waiting 1 second...")
                    
                elseif crouchState == "DUCKING" then
                    if (currentTime - crouchStartTime) >= CROUCH_DELAY_TIME then
                        CVar.ExecuteClientCmd("+attack")
                        CVar.ExecuteClientCmd("-attack")
                        CVar.ExecuteClientCmd("-duck")                        crouchState = "READY_TO_THROW"
                        commandsExecuted = true
                        print("[GrenadeHelper] Completed CROUCH throw sequence for: " .. closestSpot.name)
                    end
                end
            end
        end
        
        if crouchState == "READY_TO_THROW" and horizontalDistanceToStand > closestSpot.triggerRadius * 1.5 then
            crouchState = "NONE"
            print("[GrenadeHelper] Reset crouch state - player moved away from spot")
        end
        
        local debugTick = Globals.GetTickCount() or 0
        if debugTick % 60 == 0 then
            print("[GrenadeHelper] AIMING AT: " .. closestSpot.name .. " | P:" .. string.format("%.1f", pitch) .. "° Y:" .. string.format("%.1f", yaw) .. "° | TriggerRadius: " .. closestSpot.triggerRadius)
            print("[GrenadeHelper] Eye pos: " .. string.format("%.1f", eyePos.x) .. ", " .. string.format("%.1f", eyePos.y) .. ", " .. string.format("%.1f", eyePos.z))
            print("[GrenadeHelper] Aim pos: " .. string.format("%.1f", closestSpot.aimPos.x) .. ", " .. string.format("%.1f", closestSpot.aimPos.y) .. ", " .. string.format("%.1f", closestSpot.aimPos.z))
            if crouchState == "DUCKING" then
                local timeRemaining = CROUCH_DELAY_TIME - (currentTime - crouchStartTime)
                print("[GrenadeHelper] Crouch delay remaining: " .. string.format("%.1f", math.max(0, timeRemaining)) .. " seconds")
            end
        end
    end
end

local function GetSpotNames()
    local names = {}
    for _, spot in ipairs(wbSpots) do
        table.insert(names, spot.name)
    end
    return names
end

local function RefreshComboboxData()
    if spotsCombobox then
        local spotNames = GetSpotNames()
        spotsCombobox.options = spotNames
        
        if selectedSpotName and not currentSpots[selectedSpotName] then
            selectedSpotName = nil
            spotsCombobox.selectedIndex = 0
        else
            for i, name in ipairs(spotNames) do
                if name == selectedSpotName then
                    spotsCombobox.selectedIndex = i - 1
                    break
                end
            end
        end
        
        spotsCombobox.scrollOffset = 0
    end
end

local function CreateEditorWindow()
    if editorWindow then
        GUI.HideWindow(editorWindow)
    end
    
    editorWindow = GUI.Window("Grenade Spot Editor & Helper | by fate", 100, 100, 600, 1350)
    
    local spotNames = GetSpotNames()
    
    GUI.Label("Select Grenade Spot:")
    spotsCombobox = GUI.Combobox("Spot", spotNames, 0, function(index)
        if spotNames[index + 1] then
            selectedSpotName = spotNames[index + 1]
            local spot = nil
            
            for _, s in ipairs(wbSpots) do
                if s.name == selectedSpotName then
                    spot = s
                    break
                end
            end
            
            if spot then
                spotNameTextbox.text = spot.name
                spotNameTextbox.cursorPos = #spot.name
                standPosX_slider.value = spot.standPos_x
                standPosY_slider.value = spot.standPos_y
                standPosZ_slider.value = spot.standPos_z
                aimPosX_slider.value = spot.aimPos_x
                aimPosY_slider.value = spot.aimPos_y
                aimPosZ_slider.value = spot.aimPos_z
                renderRadiusEdit_slider.value = spot.renderRadius
                triggerRadiusEdit_slider.value = spot.triggerRadius
                
                local grenadeTypes = {"HE Grenade", "Smoke", "Flash", "Molotov"}
                for i, grenadeType in ipairs(grenadeTypes) do
                    if spot.grenade == grenadeType then
                        grenadeTypeCombobox.selectedIndex = i - 1
                        break
                    end
                end
                
                local instructionTypes = {"Stand", "Jump", "Crouch"}
                for i, instructionType in ipairs(instructionTypes) do
                    if spot.instruction == instructionType then
                        instructionCombobox.selectedIndex = i - 1
                        break
                    end
                end
            end
        end
    end)
    
    GUI.Label(" ")
    
    GUI.Label("Edit Spot Name:")
    spotNameTextbox = GUI.Textbox("", selectedSpotName or "", "Enter spot name...", 50, function(text)
    end)
    
    GUI.Label(" ")
    
    GUI.Label("Grenade Type:")
    grenadeTypeCombobox = GUI.Combobox("Type", {"HE Grenade", "Smoke", "Flash", "Molotov"}, 0, function(index)
    end)
    
    GUI.Label(" ")
    
    GUI.Label("Instruction Type:")
    instructionCombobox = GUI.Combobox("Instruction", {"Stand", "Jump", "Crouch"}, 0, function(index)
    end)
    
    GUI.Label(" ")
    
    GUI.Label("Standing Position (X, Y, Z):")
    standPosX_slider = GUI.Slider("Stand X", -5000, 5000, 0)
    standPosY_slider = GUI.Slider("Stand Y", -5000, 5000, 0)
    standPosZ_slider = GUI.Slider("Stand Z", -5000, 5000, 0)
    
    GUI.Label(" ")
    
    GUI.Label("Aim Position (X, Y, Z):")
    aimPosX_slider = GUI.Slider("Aim X", -5000, 5000, 0)
    aimPosY_slider = GUI.Slider("Aim Y", -5000, 5000, 0)
    aimPosZ_slider = GUI.Slider("Aim Z", -5000, 5000, 0)
    
    GUI.Label(" ")
    
    
    GUI.Label("Render Radius (when spot becomes visible):")
    renderRadiusEdit_slider = GUI.Slider("Render Radius", 10, 1000, 100)
    
    GUI.Label("Trigger Radius (when spot becomes active/green):")
    triggerRadiusEdit_slider = GUI.Slider("Trigger Radius", 5, 999, 50)
    
    GUI.Button("Save Changes", function()
        local newName = spotNameTextbox.text:match("^%s*(.-)%s*$")
        
        if not newName or newName == "" then
            print("[SaveChanges] Error: Spot name cannot be blank!")
            return
        end
        
        local newRenderRadius = renderRadiusEdit_slider.value
        local newTriggerRadius = triggerRadiusEdit_slider.value
        
        if newTriggerRadius >= newRenderRadius then
            print("[SaveChanges] Error: Trigger Radius (" .. newTriggerRadius .. ") must be smaller than Render Radius (" .. newRenderRadius .. ")!")
            return
        end
        
        if selectedSpotName and currentSpots[selectedSpotName] then
            local section = currentSpots[selectedSpotName].section
            local data = currentSpots[selectedSpotName].data
            local oldName = selectedSpotName
            
            local grenadeTypes = {"HE Grenade", "Smoke", "Flash", "Molotov"}
            local selectedGrenadeType = grenadeTypes[grenadeTypeCombobox.selectedIndex + 1] or "HE Grenade"
            
            local instructionTypes = {"Stand", "Jump", "Crouch"}
            local selectedInstruction = instructionTypes[instructionCombobox.selectedIndex + 1] or "Stand"
            
            data.name = newName
            data.grenade = selectedGrenadeType
            data.instruction = selectedInstruction
            data.standPos_x = standPosX_slider.value
            data.standPos_y = standPosY_slider.value
            data.standPos_z = standPosZ_slider.value
            data.aimPos_x = aimPosX_slider.value
            data.aimPos_y = aimPosY_slider.value
            data.aimPos_z = aimPosZ_slider.value
            data.renderRadius = newRenderRadius
            data.triggerRadius = newTriggerRadius
            
            data.standPos = Vector(data.standPos_x, data.standPos_y, data.standPos_z)
            data.aimPos = Vector(data.aimPos_x, data.aimPos_y, data.aimPos_z)
            
            SaveSpotToIni(section, data)
            
            if newName ~= oldName then
                selectedSpotName = newName
                currentSpots[oldName] = nil
                currentSpots[newName] = {
                    section = section,
                    data = data
                }
                print("[SaveChanges] Renamed spot from '" .. oldName .. "' to '" .. newName .. "'")
            else
                print("[SaveChanges] Updated spot: " .. newName)
            end
            
            print("[SaveChanges] Grenade type set to: " .. selectedGrenadeType)
            print("[SaveChanges] Instruction set to: " .. selectedInstruction)
            print("[SaveChanges] Render Radius: " .. newRenderRadius .. ", Trigger Radius: " .. newTriggerRadius)
        end
    end)
    
    GUI.Button("Create New Spot", function()
        local newName = spotNameTextbox.text:match("^%s*(.-)%s*$")
        
        if not newName or newName == "" then
            print("[CreateNewSpot] Error: Spot name cannot be blank!")
            return
        end
        
        if currentSpots[newName] then
            print("[CreateNewSpot] Error: A spot with name '" .. newName .. "' already exists!")
            return
        end
        
        local newRenderRadius = renderRadiusEdit_slider.value
        local newTriggerRadius = triggerRadiusEdit_slider.value
        
        if newTriggerRadius >= newRenderRadius then
            print("[CreateNewSpot] Error: Trigger Radius (" .. newTriggerRadius .. ") must be smaller than Render Radius (" .. newRenderRadius .. ")!")
            return
        end
        
        local rawMapName = Globals.GetMapName() or ""
        local mapName = rawMapName:gsub("^maps/",""):gsub("%.bsp$",""):gsub("%.vpk$","")
        
        local grenadeTypes = {"HE Grenade", "Smoke", "Flash", "Molotov"}
        local selectedGrenadeType = grenadeTypes[grenadeTypeCombobox.selectedIndex + 1] or "HE Grenade"
        
        local instructionTypes = {"Stand", "Jump", "Crouch"}
        local selectedInstruction = instructionTypes[instructionCombobox.selectedIndex + 1] or "Stand"
        
        local newSpotData = {
            map = mapName,
            name = newName,
            grenade = selectedGrenadeType,
            instruction = selectedInstruction,
            renderRadius = newRenderRadius,
            triggerRadius = newTriggerRadius,
            standPos_x = 0,
            standPos_y = 0,
            standPos_z = 0,
            aimPos_x = 0,
            aimPos_y = 0,
            aimPos_z = 0,
            standPos = Vector(0, 0, 0),
            aimPos = Vector(0, 0, 0)
        }
        
        local sectionName = "spot_" .. newName:gsub("%s+", "_"):lower() .. "_" .. os.time()
        
        SaveSpotToIni(sectionName, newSpotData)
        
        selectedSpotName = newName
        standPosX_slider.value = 0
        standPosY_slider.value = 0
        standPosZ_slider.value = 0
        aimPosX_slider.value = 0
        aimPosY_slider.value = 0
        aimPosZ_slider.value = 0
        
        print("[CreateNewSpot] Created new spot: " .. newName .. " (Type: " .. selectedGrenadeType .. ", Instruction: " .. selectedInstruction .. ", Render: " .. newRenderRadius .. ", Trigger: " .. newTriggerRadius .. ")")
        
        RefreshComboboxData()
    end)

    GUI.Button("Use Current Position", function()
        local localPlayer = nil
        for i = 1, Entities.GetHighestEntityIndex() do
            local e = Entities.GetEntityFromIndex(i)
            if e and e.m_bIsLocalPlayerController then
                localPlayer = e.m_hPawn
                break
            end
        end
        
        if localPlayer then
            local pNode = localPlayer.m_pGameSceneNode
            local origin = pNode and pNode.m_vecAbsOrigin
            
            if origin then
                standPosX_slider.value = math.floor(origin.x)
                standPosY_slider.value = math.floor(origin.y)
                standPosZ_slider.value = math.floor(origin.z)
                print("[UseCurrentPosition] Set standing position to player location")
            end
        end
    end)
    
    GUI.Button("Refresh Spots", function()
        print("[RefreshSpots] Reloading spots from INI file...")
        
        currentSpots = {}
        
        wbSpots = LoadWallbangSpots()
        
        if selectedSpotName and not currentSpots[selectedSpotName] then
            selectedSpotName = nil
            print("[RefreshSpots] Previous selection no longer exists, cleared selection")
        end
        
        print("[RefreshSpots] Loaded " .. #wbSpots .. " spots from INI file")
        print("[RefreshSpots] Refreshing combobox data...")
        
        RefreshComboboxData()
    end)
    
    if showEditorCheckbox:GetBool() then
        GUI.ShowWindow(editorWindow)
    else
        GUI.HideWindow(editorWindow)
    end
end

local function DrawChromaticRect(x, y, width, height, color, borderColor, glowEffect)
    borderColor = borderColor or modernBorder
    glowEffect = glowEffect or false
    
    if glowEffect then
        Renderer.DrawRectFilled(Vector2D(x - 1, y - 1), Vector2D(x + width + 1, y + height + 1), Color(color.r, color.g, color.b, 15), 10)
    end
    
    local transparentColor = Color(color.r, color.g, color.b, math.floor(color.a * 0.7))
    Renderer.DrawRectFilled(Vector2D(x, y), Vector2D(x + width, y + height), transparentColor, 8)
    
    local highlightHeight = math.max(1, height * 0.15)
    Renderer.DrawRectFilled(
        Vector2D(x, y), 
        Vector2D(x + width, y + highlightHeight), 
        Color(255, 255, 255, 8),
        8
    )
    
    local transparentBorder = Color(borderColor.r, borderColor.g, borderColor.b, math.floor(borderColor.a * 0.8))
    Renderer.DrawRect(Vector2D(x, y), Vector2D(x + width, y + height), transparentBorder, 8)
end

local function DrawChromaticText(font, text, pos, centered, color, shadow)
    shadow = shadow ~= false
    
    if shadow then
        local shadowPos = Vector2D(pos.x + 1, pos.y + 1)
        Renderer.DrawText(font, text, shadowPos, centered, false, Color(0, 0, 0, 60))
    end
    
    Renderer.DrawText(font, text, pos, centered, true, color)
end

local function GetTextDimensions(text, fontSize)
    fontSize = fontSize or 12
    local charWidth = fontSize * 0.6
    local width = math.ceil(#text * charWidth)
    local height = fontSize + 4
    return width, height
end

local function GetRainbowColor()
    local time = Globals.GetCurrentTime()
    local speed = 2.0
    local r = math.floor(127 * (math.sin(time * speed) + 1))
    local g = math.floor(127 * (math.sin(time * speed + 2.0944) + 1))
    local b = math.floor(127 * (math.sin(time * speed + 4.1888) + 1))
    return Color(r, g, b, 200)
end

local function DrawAeroRect(x, y, width, height, color, borderColor, glowEffect)
    local glassColor = Color(color.r, color.g, color.b, math.floor(color.a * 0.3))
    Renderer.DrawRectFilled(Vector2D(x, y), Vector2D(x + width, y + height), glassColor, 0)
end

local function DrawAeroText(font, text, pos, centered, color, shadow)
    Renderer.DrawText(font, text, pos, centered, true, color)
end

local function IsChromaticTheme()
    return themeSelector:GetInt() == 1
end

local function DrawThemeRect(x, y, width, height, color, borderColor, glowEffect)
    if IsChromaticTheme() then
        DrawChromaticRect(x, y, width, height, color, borderColor, glowEffect)
    else
        DrawAeroRect(x, y, width, height, color, borderColor, glowEffect)
    end
end

local function DrawThemeText(font, text, pos, centered, color, shadow)
    if IsChromaticTheme() then
        DrawChromaticText(font, text, pos, centered, color, shadow)
    else
        DrawAeroText(font, text, pos, centered, color, shadow)
    end
end

local function OnRenderer()
    local showEditor = showEditorCheckbox:GetBool()
    
    if showEditor and not editorWindow then
        CreateEditorWindow()
    elseif editorWindow then
        if showEditor then
            GUI.ShowWindow(editorWindow)
        else
            GUI.HideWindow(editorWindow)
        end
    end
    
    local rawMapName = Globals.GetMapName() or ""
    local mapName = rawMapName:gsub("^maps/",""):gsub("%.bsp$",""):gsub("%.vpk$","")

    local screenSize = Renderer.GetScreenSize()
    if not screenSize then return end
    local cx, cy = screenSize.x * 0.5, screenSize.y * 0.5

    if showWatermarkCheckbox:GetBool() then
        local username = Cheat.GetUserName() or "Unknown"
        local watermarkText = "Grenade Helper V2-rel | " .. username
        
        local watermarkWidth, watermarkHeight = GetTextDimensions(watermarkText, 10)
        local padX, padY = 15, 6
        local wmWidth = watermarkWidth + padX * 2
        local wmHeight = watermarkHeight + padY * 2
        
        local minWidth = 200
        wmWidth = math.max(wmWidth, minWidth)
        
        local wmX = screenSize.x - wmWidth - 15
        local wmY = 15
        
        local time = Globals.GetCurrentTime()
        local pulseSpeed = 3.0
        local glowSpeed = 2.5
        local teardropSpeed = 0.3
        
        local pulseAlpha = math.floor(50 + 30 * math.sin(time * pulseSpeed))
        local glowRadius = 2 + math.sin(time * glowSpeed) * 1
        if IsChromaticTheme() then
            for i = 1, 3 do
                local glowSize = glowRadius + i
                local glowAlpha = pulseAlpha / (i * 2)
                DrawThemeRect(wmX - glowSize, wmY - glowSize, wmWidth + glowSize * 2, wmHeight + glowSize * 2, 
                    Color(modernDark.r, modernDark.g, modernDark.b, glowAlpha), Color(0, 0, 0, 0), false)
            end
        end
        
        DrawThemeRect(wmX, wmY, wmWidth, wmHeight, modernDark, modernBorder, false)
        
        local teardropProgress = (time * teardropSpeed) % 1
        local perimeter = (wmWidth + wmHeight) * 2
        local currentDistance = teardropProgress * perimeter
        
        local teardropX, teardropY
        local teardropAngle = 0
        
        if currentDistance <= wmWidth then
            teardropX = wmX + currentDistance
            teardropY = wmY
            teardropAngle = 0
        elseif currentDistance <= wmWidth + wmHeight then
            teardropX = wmX + wmWidth
            teardropY = wmY + (currentDistance - wmWidth)
            teardropAngle = math.pi / 2
        elseif currentDistance <= wmWidth * 2 + wmHeight then
            teardropX = wmX + wmWidth - (currentDistance - wmWidth - wmHeight)
            teardropY = wmY + wmHeight
            teardropAngle = math.pi
        else
            teardropX = wmX
            teardropY = wmY + wmHeight - (currentDistance - wmWidth * 2 - wmHeight)
            teardropAngle = -math.pi / 2
        end
        local borderColor = (rainbowModeCheckbox:GetBool() and IsChromaticTheme()) and GetRainbowColor() or modernAccent
        local teardropSize = (4 + math.sin(time * glowSpeed * 1.5) * 1) / 1.45
        local teardropAlpha = math.floor(200 + 40 * math.sin(time * pulseSpeed * 0.8))
        local teardropColor = Color(borderColor.r, borderColor.g, borderColor.b, teardropAlpha)
        
        if IsChromaticTheme() then
            if not trailParticles.lastSpawn or (time - trailParticles.lastSpawn) >= trailSpawnRate then
                table.insert(trailParticles, {
                    x = teardropX,
                    y = teardropY,
                    spawnTime = time,
                    color = {r = borderColor.r, g = borderColor.g, b = borderColor.b},
                    size = teardropSize
                })
                trailParticles.lastSpawn = time
            end
            
            local validParticles = {}
            for _, particle in ipairs(trailParticles) do
                local age = time - particle.spawnTime
                if age <= maxTrailAge then
                    local fadeRatio = 1 - (age / maxTrailAge)
                    local ageAlpha = math.floor(teardropAlpha * fadeRatio * fadeRatio * fadeRatio)
                    local ageSize = particle.size * (0.3 + fadeRatio * 0.7)
                    
                    if ageAlpha > 5 and ageSize > 0.5 then
                        local particleColor = Color(particle.color.r, particle.color.g, particle.color.b, ageAlpha)
                        Renderer.DrawCircleFilled(Vector2D(particle.x, particle.y), particleColor, ageSize)
                        
                        if age < maxTrailAge * 0.5 then
                            local innerGlowAlpha = math.floor(ageAlpha * 0.4)
                            local innerGlow = Color(255, 255, 255, innerGlowAlpha)
                            Renderer.DrawCircleFilled(Vector2D(particle.x, particle.y), innerGlow, ageSize * 0.6)
                        end
                        
                        if age < maxTrailAge * 0.2 then
                            local outerGlowAlpha = math.floor(ageAlpha * 0.2)
                            local outerGlow = Color(particle.color.r, particle.color.g, particle.color.b, outerGlowAlpha)
                            Renderer.DrawCircleFilled(Vector2D(particle.x, particle.y), outerGlow, ageSize * 1.5)
                        end
                    end
                    
                    table.insert(validParticles, particle)
                end
            end
            
            trailParticles = validParticles
            
            Renderer.DrawCircleFilled(Vector2D(teardropX, teardropY), teardropColor, teardropSize + 1)
            Renderer.DrawCircleFilled(Vector2D(teardropX, teardropY), Color(borderColor.r, borderColor.g, borderColor.b, teardropAlpha * 0.7), teardropSize * 0.8)            Renderer.DrawCircleFilled(Vector2D(teardropX, teardropY), Color(borderColor.r, borderColor.g, borderColor.b, teardropAlpha * 0.4), teardropSize * 0.5)
        else
            if rainbowModeCheckbox:GetBool() then
                local breathSpeed = 1.5
                local breathPhase = math.sin(time * breathSpeed)
                local breathIntensity = math.max(0, breathPhase)
                
                local lineThickness = breathIntensity * 2
                
                if lineThickness > 0.1 then
                    local breathColor = GetRainbowColor()
                    breathColor.a = math.floor(breathIntensity * 150)
                    
                    Renderer.DrawRect(Vector2D(wmX - 1, wmY - 1), Vector2D(wmX + wmWidth + 1, wmY + wmHeight + 1), breathColor, 0)
                    
                    if lineThickness > 1 then
                        local innerColor = Color(breathColor.r, breathColor.g, breathColor.b, math.floor(breathIntensity * 100))
                        Renderer.DrawRect(Vector2D(wmX, wmY), Vector2D(wmX + wmWidth, wmY + wmHeight), innerColor, 0)
                    end
                end
            end
        end
        
          local textAlpha = math.floor(220 + 25 * math.sin(time * pulseSpeed * 0.5))
        local textColor = Color(modernText.r, modernText.g, modernText.b, textAlpha)
          if IsChromaticTheme() then
            for i = 1, 2 do
                local glowOffset = i * 0.5
                DrawThemeText("Verdana", watermarkText, Vector2D(wmX + wmWidth/2 + glowOffset, wmY + padY + glowOffset), true, 
                    Color(borderColor.r, borderColor.g, borderColor.b, 30), false)
            end
        end
        
        DrawThemeText("Verdana", watermarkText, Vector2D(wmX + wmWidth/2, wmY + padY), true, textColor, false)
    end

    local hasSpots = false
    for _, spot in ipairs(wbSpots) do
        if spot.map == mapName then hasSpots = true; break end
    end
    if not hasSpots then return end
    
    local localPlayer
    for i = 1, Entities.GetHighestEntityIndex() do
        local e = Entities.GetEntityFromIndex(i)
        if e and e.m_bIsLocalPlayerController then
            localPlayer = e.m_hPawn
            break
        end
    end
    if not localPlayer then return end

    currentWeaponName = GetCurrentWeapon()

    local pNode = localPlayer.m_pGameSceneNode
    local origin = pNode and pNode.m_vecAbsOrigin
    if not origin then return end

    mouseHoverSpot = nil

    if showCoordinatesCheckbox:GetBool() then
        local coordText = ("X:%s Y:%s Z:%s"):format(
            FormatCoord(origin.x), FormatCoord(origin.y), FormatCoord(origin.z)
        )
        local weaponText = "Weapon: " .. currentWeaponName
        
        local coordWidth, coordHeight = GetTextDimensions(coordText, 12)
        local weaponWidth, weaponHeight = GetTextDimensions(weaponText, 12)
        local maxWidth = math.max(coordWidth, weaponWidth)
        
        local infoWidth = maxWidth + 30
        local infoHeight = coordHeight + weaponHeight + 20
        local infoX = cx - infoWidth/2
        local infoY = cy + 40
          local extraTransparentBg = Color(modernDarkSecondary.r, modernDarkSecondary.g, modernDarkSecondary.b, math.floor(modernDarkSecondary.a * 0.6))
        DrawThemeRect(infoX, infoY, infoWidth, infoHeight, extraTransparentBg, modernBorder, true)
        
        DrawThemeText("Verdana", coordText, Vector2D(cx, infoY + 12), true, modernText)
        DrawThemeText("Verdana", weaponText, Vector2D(cx, infoY + 12 + coordHeight + 8), true, modernSuccess)    end

    if viewangleModificationCheckbox:GetBool() then
        local quantizeCvar = CVar.FindVar("sv_quantize_movement_input")
        if quantizeCvar and quantizeCvar:GetBool() then
            local warningText = "Warning! Don't use Auto Grenade Throw on VAC protected servers!"
            local warningColor = Color(255, 100, 100, 255)
            
            local warningY = cy + 550
            DrawThemeText("Verdana", warningText, Vector2D(cx, warningY), true, warningColor)
        end
    end

    local lookThreshold = 12
    
    for _, spot in ipairs(wbSpots) do
        if spot.map == mapName then
            if DoesWeaponMatchSpot(currentWeaponName, spot.grenade) then
                local dist = GetDistance3D(origin, spot.standPos)
                local dist2D = GetDistance2D(origin, spot.standPos)

                if dist <= spot.renderRadius then
                    local stand2D = Renderer.WorldToScreen(spot.standPos)
                    local aim2D = Renderer.WorldToScreen(spot.aimPos)

                    if dist2D <= standingRadius then
                        if aim2D and IsOnScreen(aim2D, screenSize.x, screenSize.y) then
                            local isMouseOver = IsMouseHovering(aim2D, mouseHoverRadius)
                            local aimDotColor = modernYellow
                            
                            if isMouseOver then
                                mouseHoverSpot = spot
                                aimDotColor = modernYellowHighlight
                            elseif math.abs(aim2D.x - cx) < lookThreshold and math.abs(aim2D.y - cy) < lookThreshold then
                                aimDotColor = modernYellowHighlight
                            end
                            
                            Renderer.DrawCircleFilled(Vector2D(aim2D.x, aim2D.y), Color(aimDotColor.r, aimDotColor.g, aimDotColor.b, 100), dotSize + 2)
                            Renderer.DrawCircleFilled(Vector2D(aim2D.x, aim2D.y), aimDotColor, dotSize)
                        end

                        if showCoordinatesCheckbox:GetBool() then
                            if dist <= spot.triggerRadius then
                                local instructionText = spot.instruction or "Stand"
                                local maxLineLength = 45
                                local lines = {}
                                
                                if #instructionText > maxLineLength then
                                    local words = {}
                                    for word in instructionText:gmatch("%S+") do
                                        table.insert(words, word)
                                    end
                                    
                                    local currentLine = ""
                                    for _, word in ipairs(words) do
                                        if #currentLine + #word + 1 <= maxLineLength then
                                            currentLine = currentLine .. (currentLine == "" and "" or " ") .. word
                                        else
                                            table.insert(lines, currentLine)
                                            currentLine = word
                                        end
                                    end
                                    if currentLine ~= "" then
                                        table.insert(lines, currentLine)
                                    end
                                else
                                    table.insert(lines, instructionText)
                                end
                                
                                local titleText = "ACTIVE SPOT: " .. spot.name
                                local typeText = "TYPE: " .. spot.grenade
                                
                                local titleWidth = GetTextDimensions(titleText, 14)
                                local typeWidth = GetTextDimensions(typeText, 12)
                                local maxInstructWidth = 0
                                for _, line in ipairs(lines) do
                                    local lineWidth = GetTextDimensions(line, 12)
                                    maxInstructWidth = math.max(maxInstructWidth, lineWidth)
                                end
                                
                                local contentWidth = math.max(titleWidth, typeWidth, maxInstructWidth)
                                local spotInfoWidth = contentWidth + 40
                                local lineHeight = 18
                                local spotInfoHeight = 50 + 25 + (#lines * lineHeight) + 15
                                
                                local spotInfoY = cy + 130
                                local spotInfoX = cx - spotInfoWidth/2
                                  DrawThemeRect(spotInfoX, spotInfoY, spotInfoWidth, spotInfoHeight, modernDark, modernBorder, true)
                                  if IsChromaticTheme() then
                                    DrawThemeRect(spotInfoX, spotInfoY, spotInfoWidth, 35, modernDarkAccent, Color(0, 0, 0, 0))
                                    local accentColor = rainbowModeCheckbox:GetBool() and GetRainbowColor() or modernAccent
                                    Renderer.DrawRectFilled(Vector2D(spotInfoX, spotInfoY + 35), Vector2D(spotInfoX + spotInfoWidth, spotInfoY + 37), accentColor)
                                end
                                DrawThemeText("VerdanaBold", titleText, Vector2D(spotInfoX + spotInfoWidth/2, spotInfoY + 12), true, modernText)
                                
                                local contentY = spotInfoY + 50
                                DrawThemeText("Verdana", typeText, Vector2D(spotInfoX + 20, contentY), false, modernYellow)
                                
                                contentY = contentY + 25
                                for i, line in ipairs(lines) do
                                    local prefix = i == 1 and "INSTRUCTION: " or "           "
                                    DrawThemeText("Verdana", prefix .. line, Vector2D(spotInfoX + 20, contentY), false, modernTextSecondary)
                                    contentY = contentY + lineHeight
                                end
                            end
                        end
                    end
                    if stand2D and IsOnScreen(stand2D, screenSize.x, screenSize.y) then
                        local isWithinTriggerRadius = dist <= spot.triggerRadius
                        local standDotColor = isWithinTriggerRadius and modernGreenHighlight or modernBlue
                          if IsChromaticTheme() then
                            Renderer.DrawCircleFilled(Vector2D(stand2D.x, stand2D.y), Color(standDotColor.r, standDotColor.g, standDotColor.b, 100), dotSize + 2)
                            Renderer.DrawCircleFilled(Vector2D(stand2D.x, stand2D.y), standDotColor, dotSize)

                            local standText = ("%s [%s]"):format(spot.name, spot.grenade)
                            local textW, textH = GetTextDimensions(standText, 12)
                            local padX, padY = 20, 8
                            local textX = stand2D.x - textW * 0.5
                            local textY = stand2D.y + dotSize + 20

                            local bgX = textX - padX
                            local bgY = textY - padY
                            local bgW = textW + padX * 2
                            local bgH = textH + padY * 2
                            
                            if bgX >= 0 and bgY >= 0 and (bgX + bgW) <= screenSize.x and (bgY + bgH) <= screenSize.y then
                                local extraTransparentDark = Color(modernDark.r, modernDark.g, modernDark.b, math.floor(modernDark.a * 0.5))
                                DrawThemeRect(bgX, bgY, bgW, bgH, extraTransparentDark, modernBorder, true)
                                
                                local borderColor = rainbowModeCheckbox:GetBool() and GetRainbowColor() or modernAccent
                                Renderer.DrawRect(Vector2D(bgX, bgY), Vector2D(bgX + bgW, bgY + bgH), borderColor, 8)
                                
                                DrawThemeText("Verdana", standText, Vector2D(textX + padX, textY), false, standDotColor)
                            end
                        else
                            local spotText = " | " .. spot.name
                            local textW, textH = GetTextDimensions(spotText, 12)
                            local smallDotSize = 5
                            local rectPadding = 6
                            local dotToTextSpacing = 6
                            
                            local rectWidth = smallDotSize + dotToTextSpacing + textW + rectPadding * 2
                            local rectHeight = math.max(textH, smallDotSize * 2) + rectPadding
                            
                            local rectX = stand2D.x - rectWidth / 2
                            local rectY = stand2D.y - rectHeight / 2
                              if rectX >= 0 and rectY >= 0 and (rectX + rectWidth) <= screenSize.x and (rectY + rectHeight) <= screenSize.y then
                                local staticGrayColor = Color(128, 128, 128, 60)
                                Renderer.DrawRectFilled(Vector2D(rectX, rectY), Vector2D(rectX + rectWidth, rectY + rectHeight), staticGrayColor, 0)
                                
                                local dotX = rectX + rectPadding + smallDotSize
                                local dotY = rectY + rectHeight / 2
                                Renderer.DrawCircleFilled(Vector2D(dotX, dotY), standDotColor, smallDotSize)
                                
                                local textX = dotX + dotToTextSpacing
                                local textY = rectY + rectHeight / 2 - textH / 2 + 2
                                local whiteTextColor = Color(255, 255, 255, 255)
                                DrawThemeText("Verdana", spotText, Vector2D(textX, textY), false, whiteTextColor)
                            end
                        end
                    end
                end
            end
        end
    end

    if mouseHoverSpot then
        local spot = mouseHoverSpot
        
        
        local showDetailedCoords = showCoordinatesCheckbox:GetBool()
        
        local detailInfoPos = Vector(spot.aimPos.x, spot.aimPos.y, spot.aimPos.z - 10)
        local detailInfo2D = Renderer.WorldToScreen(detailInfoPos)
        
        if detailInfo2D and IsOnScreen(detailInfo2D, screenSize.x, screenSize.y) then
            local lines = {}
            table.insert(lines, "Name: " .. spot.name)
            table.insert(lines, "Type: " .. spot.grenade)
            table.insert(lines, "Instruction: " .. (spot.instruction or "Stand"))
            
            if showDetailedCoords then
                table.insert(lines, "Stand Position: " .. FormatCoord(spot.standPos.x) .. ", " .. FormatCoord(spot.standPos.y) .. " , " .. FormatCoord(spot.standPos.z))
                table.insert(lines, "Aim Position: " .. FormatCoord(spot.aimPos.x) .. ", " .. FormatCoord(spot.aimPos.y) .. ", " .. FormatCoord(spot.aimPos.z))
            end
            
            local maxLineWidth = 0
            for _, line in ipairs(lines) do
                local lineWidth = GetTextDimensions(line, 12)
                maxLineWidth = math.max(maxLineWidth, lineWidth)
            end
            
            local titleWidth = GetTextDimensions("GRENADE SPOT DETAILS", 14)
            local panelWidth = math.max(maxLineWidth, titleWidth) + 40
            local panelHeight = 50 + (#lines * 20) + 15
            
            local panelX = detailInfo2D.x - panelWidth/2
            local panelY = detailInfo2D.y - panelHeight - 20
            
            if panelX < 10 then panelX = 10 end
            if panelX + panelWidth > screenSize.x - 10 then panelX = screenSize.x - panelWidth - 10 end
            if panelY < 10 then panelY = detailInfo2D.y + 30 end
              local transparentDark = Color(modernDark.r, modernDark.g, modernDark.b, math.floor(modernDark.a * 0.8))
            DrawThemeRect(panelX, panelY, panelWidth, panelHeight, transparentDark, modernBorder, true)
              if IsChromaticTheme() then
                local transparentDarkAccent = Color(modernDarkAccent.r, modernDarkAccent.g, modernDarkAccent.b, math.floor(modernDarkAccent.a * 0.7))
                DrawThemeRect(panelX, panelY, panelWidth, 35, transparentDarkAccent, Color(0, 0, 0, 0))

                local accentColor = rainbowModeCheckbox:GetBool() and GetRainbowColor() or modernAccent
                Renderer.DrawRectFilled(Vector2D(panelX, panelY + 35), Vector2D(panelX + panelWidth, panelY + 37), accentColor)
            end
            DrawThemeText("VerdanaBold", "GRENADE SPOT DETAILS", Vector2D(panelX + panelWidth/2, panelY + 12), true, modernText)
            
            local contentY = panelY + 50
            local lineHeight = 20
              for i, line in ipairs(lines) do
                local color = modernTextSecondary
                if line:find("Name:") then color = Color(220, 220, 220, 255)
                elseif line:find("Type:") then color = modernYellow
                elseif line:find("Instruction:") then color = modernText
                elseif line:find("Stand Position:") then color = modernGreen
                elseif line:find("Aim Position:") then color = modernYellow
                end
                
                DrawThemeText("Verdana", line, Vector2D(panelX + 20, contentY), false, color)
                contentY = contentY + lineHeight
            end
        end
    end
end

local function OnEditor()
    local showEditor = showEditorCheckbox:GetBool()
    if showEditor and not editorWindow then
        CreateEditorWindow()
    elseif editorWindow then
        if showEditor then
            GUI.ShowWindow(editorWindow)
        else
            GUI.HideWindow(editorWindow)
        end
    end
end

Cheat.RegisterCallback("OnRenderer", OnRenderer)
Cheat.RegisterCallback("OnRenderer", OnEditor)
Cheat.RegisterCallback("OnPostCreateMove", ViewAngleModification)
print("Granata Helpar loaded. On: " .. initialMapName)
print("Granata Throw spots loaded from ini config.")
print("GUI Grenade Spot Editor available (toggle in menu)")

GUI.Initialize()

local editorWindow = nil
local spotsCombobox = nil
local spotNameTextbox = nil
local grenadeTypeCombobox = nil
local instructionCombobox = nil
local standPosX_slider = nil
local standPosY_slider = nil 
local standPosZ_slider = nil
local aimPosX_slider = nil
local aimPosY_slider = nil
local aimPosZ_slider = nil
local renderRadiusEdit_slider = nil
local triggerRadiusEdit_slider = nil