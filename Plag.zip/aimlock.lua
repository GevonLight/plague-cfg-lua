local ffi = require("ffi")
ffi.cdef[[
    typedef struct {
        unsigned long type;
        union {
            struct {
                long dx;
                long dy;
                unsigned long mouseData;
                unsigned long dwFlags;
                unsigned long time;
                uintptr_t dwExtraInfo;
            } mi;
        };
    } INPUT;

    unsigned int SendInput(unsigned int nInputs, INPUT* pInputs, int cbSize);
]]

local INPUT_MOUSE = 0
local MOUSEEVENTF_MOVE = 1

local function SendMouseMove(dx, dy)
    local input = ffi.new("INPUT")
    input.type = INPUT_MOUSE
    input.mi.dx = math.floor(dx + 0.5)
    input.mi.dy = math.floor(dy + 0.5)
    input.mi.mouseData = 0
    input.mi.dwFlags = MOUSEEVENTF_MOVE
    input.mi.time = 0
    input.mi.dwExtraInfo = 0
    ffi.C.SendInput(1, input, ffi.sizeof("INPUT"))
end

Menu.Combo("", 0, {"Aimlock"})
local aimlock_enabled = Menu.Checker("Aimlock", false, false, true)
local aimlock_fov = Menu.Slider("Aimlock FOV", 25, 1, 180)
local aimlock_smooth = Menu.Slider("Aim Smoothness", 8, 1, 50)
local show_fov = Menu.Checker("Show FOV Circle", true)

local function GetLocalPlayerPawn()
    for i = 1, 64 do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_bIsLocalPlayerController then
            return entity.m_hPawn
        end
    end
    return nil
end

local function GetHeadScreen(pawn)
    local node = pawn and pawn.m_pGameSceneNode
    if not node then
        return nil
    end
    local head = Vector(node.m_vecAbsOrigin.x, node.m_vecAbsOrigin.y, node.m_vecAbsOrigin.z + 64)
    return Renderer.WorldToScreen(head)
end

local function GetClosestTarget(centerX, centerY, radius)
    local localPawn = GetLocalPlayerPawn()
    if not localPawn or not localPawn.m_pGameSceneNode then
        return nil
    end
    local localTeam = localPawn.m_iTeamNum
    local bestTarget = nil
    local bestDist = radius

    for i = 1, 64 do
        local controller = Entities.GetEntityFromIndex(i)
        if controller and not controller.m_bIsLocalPlayerController then
            local pawn = controller.m_hPawn
            if pawn and pawn.m_iHealth and pawn.m_iHealth > 0 and controller.m_iTeamNum ~= localTeam then
                local screen = GetHeadScreen(pawn)
                if screen and screen.x ~= 0 and screen.y ~= 0 then
                    local dx = screen.x - centerX
                    local dy = screen.y - centerY
                    local dist = math.sqrt(dx * dx + dy * dy)
                    if dist < bestDist then
                        bestDist = dist
                        bestTarget = pawn
                    end
                end
            end
        end
    end
    return bestTarget
end

local lockedTarget = nil

local function OnPostCreateMove(cmd)
    if not aimlock_enabled:GetBool() or not aimlock_enabled:IsDown() then
        lockedTarget = nil
        return
    end

    local screenSize = Renderer.GetScreenSize()
    if not screenSize then
        return
    end
    local centerX, centerY = screenSize.x / 2, screenSize.y / 2
    local radius = aimlock_fov:GetInt() * 3

    if lockedTarget then
        local screen = GetHeadScreen(lockedTarget)
        if not screen then
            lockedTarget = nil
        else
            local dx = screen.x - centerX
            local dy = screen.y - centerY
            if math.sqrt(dx * dx + dy * dy) > radius or lockedTarget.m_iHealth <= 0 then
                lockedTarget = nil
            end
        end
    end

    if not lockedTarget then
        lockedTarget = GetClosestTarget(centerX, centerY, radius)
    end

    if lockedTarget then
        local screen = GetHeadScreen(lockedTarget)
        if screen then
            local dx = screen.x - centerX
            local dy = screen.y - centerY
            local smooth = math.max(1, aimlock_smooth:GetInt())
            SendMouseMove(dx / smooth, dy / smooth)
        end
    end
end

local function OnRenderer()
    if not show_fov:GetBool() then
        return
    end
    local screenSize = Renderer.GetScreenSize()
    if not screenSize then
        return
    end
    local centerX, centerY = screenSize.x / 2, screenSize.y / 2
    local radius = aimlock_fov:GetInt() * 3
    local color = Color(255, 255, 255, 100)
    for i = 0, 360, 5 do
        local a1 = math.rad(i)
        local a2 = math.rad(i + 5)
        local x1 = centerX + math.cos(a1) * radius
        local y1 = centerY + math.sin(a1) * radius
        local x2 = centerX + math.cos(a2) * radius
        local y2 = centerY + math.sin(a2) * radius
        Renderer.DrawLine(Vector2D(x1, y1), Vector2D(x2, y2), color, 1)
    end
end

Cheat.RegisterCallback("OnPostCreateMove", OnPostCreateMove)
Cheat.RegisterCallback("OnRenderer", OnRenderer)
