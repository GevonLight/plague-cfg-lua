package.path = "C:\\plaguecheat.cc\\lib\\?.lua;" .. package.path

local wm = require("stalkerslib")

local SCRIPT_NAME = "Stalkers"
wm.SetScriptName(SCRIPT_NAME)

local function slider_int(name, def, min, max)
    if Menu.SliderInt then
        return Menu.SliderInt(name, def, min, max)
    end
    local s = Menu.Slider and Menu.Slider(name, def, min, max)
    if s and s.GetInt == nil and s.GetValue then
        function s:GetInt()
            return math.floor(self:GetValue())
        end
    end
    return s or {GetInt = function() return def end}
end

local corner_combo = Menu.Combo("Watermark corner", 0, wm.positions)
local style_combo = Menu.Combo("Watermark style", 2, wm.watermark_styles)
local spectators_checkbox = Menu.Checker("Spectator list", false)
local killsay_checkbox = Menu.Checker("KillSay", false)
local hitmarker_checkbox = Menu.Checker("Hitmarker", false)
local hitmarker_size = slider_int("Hitmarker size", 8, 2, 30)
local hitmarker_color_picker = Menu.Checker("Hitmarker color", false, true)
local hitlog_checkbox = Menu.Checker("Hit logs", false)
local hitlog_mode = Menu.Combo("Hitlog mode", 0, wm.hitlog_modes)
local hitlog_pos = Menu.Combo("Hitlog position", 0, wm.hitlog_positions)
local hit_color_picker = Menu.Checker("Hit color", false, true)
local miss_color_picker = Menu.Checker("Miss color", false, true)
local jumpscout_checkbox = Menu.Checker("Better jumpscout", false)
local hitgroups = {
    [0] = "generic",
    [1] = "head",
    [2] = "chest",
    [3] = "stomach",
    [4] = "left arm",
    [5] = "right arm",
    [6] = "left leg",
    [7] = "right leg",
    [8] = "neck"
}
local miss_reasons = {
    [0] = "resolver",
    [1] = "spread",
    [2] = "occlusion",
    [3] = "prediction"
}

local kill_messages = { "gg", "nice", "ez", "owned by stalkers lua t.me/stalkerslua", "stalkers one love t.me/stalkerslua", "get good t.me/stalkerslua", "bastard", "retard kid" }

local function GetLocalPlayerPawn()
    local highest = Entities.GetHighestEntityIndex() or 0
    for i = 1, highest do
        local e = Entities.GetEntityFromIndex(i)
        if e and e.m_bIsLocalPlayerController then
            return e.m_hPawn
        end
    end
    return nil
end

local function enemy_hittable(cmd, pawn)
    local node = pawn and pawn.m_pGameSceneNode
    if not node then return false end
    local my_pos = node.m_vecAbsOrigin
    if not my_pos then return false end
    local highest = Entities.GetHighestEntityIndex() or 0
    for i = 1, highest do
        local e = Entities.GetEntityFromIndex(i)
        if e and not e.m_bIsLocalPlayerController and not e.m_bIsHLTV then
            local epawn = e.m_hPawn
            if epawn and epawn.m_iTeamNum ~= pawn.m_iTeamNum and epawn.m_iHealth > 0 then
                local enode = epawn.m_pGameSceneNode
                if enode then
                    local enemy_pos = enode.m_vecAbsOrigin
                    local dy = enemy_pos.y - my_pos.y
                    local dx = enemy_pos.x - my_pos.x
                    local yaw = math.deg(math.atan2(dy, dx))
                    local diff = yaw - cmd.m_angViewAngles.y
                    while diff > 180 do diff = diff - 360 end
                    while diff < -180 do diff = diff + 360 end
                    if math.abs(diff) < 5 then
                        return true
                    end
                end
            end
        end
    end
    return false
end

local IN_SPEED = bit.lshift(1, 17)

local function OnPreCreateMove(cmd)
    if not jumpscout_checkbox:GetBool() then
        cmd.m_nButtons = bit.band(cmd.m_nButtons or 0, bit.bnot(IN_SPEED))
        return
    end
    local pawn = GetLocalPlayerPawn()
    if not pawn or pawn.m_iHealth <= 0 then
        cmd.m_nButtons = bit.band(cmd.m_nButtons or 0, bit.bnot(IN_SPEED))
        return
    end
    local weapon_services = pawn.m_pWeaponServices
    if not weapon_services then return end
    local w = Entities.GetEntityFromIndex(weapon_services.m_hActiveWeapon)
    if not w or Entities.GetDesignerName(w) ~= "weapon_ssg08" then
        cmd.m_nButtons = bit.band(cmd.m_nButtons or 0, bit.bnot(IN_SPEED))
        return
    end
    if bit.band(pawn.m_fFlags or 0, 1) ~= 0 then
        cmd.m_nButtons = bit.band(cmd.m_nButtons or 0, bit.bnot(IN_SPEED))
        return
    end
    if enemy_hittable(cmd, pawn) then
        cmd.m_nButtons = bit.bor(cmd.m_nButtons or 0, IN_SPEED)
    else
        cmd.m_nButtons = bit.band(cmd.m_nButtons or 0, bit.bnot(IN_SPEED))
    end
end

local function OnRenderer()
    local idx = 0
    if corner_combo and corner_combo.GetInt then
        idx = corner_combo:GetInt()
    end
    wm.SetPosition(wm.positions[idx + 1])
    local style_idx = style_combo and style_combo:GetInt() or 0
    wm.SetStyle(wm.watermark_styles[style_idx + 1])
    wm.Draw()

    if spectators_checkbox:GetBool() then
        local specs = wm.GetSpectators()
        if #specs > 0 then
            wm.DrawSpectators(specs)
        end
    end
    if hitmarker_checkbox:GetBool() then
        local hm_col = hitmarker_color_picker:GetBool() and hitmarker_color_picker:GetColor() or wm.GetAccentColor()
        wm.SetHitmarkerStyle(hitmarker_size:GetInt(), hm_col)
        wm.DrawHitmarker()
    end
    if hitlog_checkbox:GetBool() then
        local hit_col = hit_color_picker:GetBool() and hit_color_picker:GetColor() or wm.hitlog_color_hit
        local miss_col = miss_color_picker:GetBool() and miss_color_picker:GetColor() or wm.hitlog_color_miss
        wm.SetHitlogColors(hit_col, miss_col)
        local mode = wm.hitlog_modes[hitlog_mode:GetInt() + 1]
        local pos = wm.hitlog_positions[hitlog_pos:GetInt() + 1]
        wm.DrawHitLogs(mode, pos)
    end
end

local function OnFireGameEvent(event)
    local name = event:GetName()
    if name == "player_death" then
        local attacker = event:GetPlayerController("attacker")
        if attacker and attacker.m_bIsLocalPlayerController and killsay_checkbox:GetBool() then
            CVar.ExecuteClientCmd("say " .. kill_messages[math.random(#kill_messages)])
        end
    elseif name == "player_hurt" then
        local attacker = event:GetPlayerController("attacker")
        if attacker and attacker.m_bIsLocalPlayerController then
            if hitmarker_checkbox:GetBool() then
                wm.RegisterHit()
            end
            if hitlog_checkbox:GetBool() then
                local victim = event:GetPlayerController("userid")
                local dmg = event:GetInt("dmg_health") or 0
                local hg = event:GetInt("hitgroup") or 0
                local name = victim and victim.m_sSanitizedPlayerName or "enemy"
                wm.AddHitLog(string.format("Hit %s in %s for %d", name, hitgroups[hg] or hg, dmg), "Hit")
            end
        end
    elseif name == "aim_miss" then
        if hitlog_checkbox:GetBool() then
            local shooter = event:GetPlayerController("attacker") or event:GetPlayerController("player") or event:GetPlayerController("userid")
            if not shooter or shooter.m_bIsLocalPlayerController then
                local victim = event:GetPlayerController("target")
                local reason_id = event:GetInt("reason") or 0
                local reason = miss_reasons[reason_id] or event:GetString("reason") or tostring(reason_id)
                local name = victim and victim.m_sSanitizedPlayerName or "enemy"
                wm.AddHitLog(string.format("Missed %s due to %s", name, reason), "Miss")
            end
        end
    end
end

Cheat.RegisterCallback("OnPreCreateMove", OnPreCreateMove)
Cheat.RegisterCallback("OnRenderer", OnRenderer)
Cheat.RegisterCallback("OnFireGameEvent", OnFireGameEvent)