local ffi = require("ffi")
ffi.cdef[[
    typedef long long int64_t;
    typedef void (__fastcall *PlayEffect_t)(const char* pEffectName, int nSplitScreenSlot, uintptr_t hEntity, char bRemove, int nMagnitude, char bNoColorCorrection, unsigned int nAttachment, int nFlags, char bFromPuppet);
]]

local sig = Cheat.FindPattern("client.dll", "48 89 5C 24 ? 48 89 74 24 ? 55 57 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B")

if not sig then
    print("No SIG for PlayEffect")
    return
end

local PlayEffect = ffi.cast("PlayEffect_t", sig)
local items2 = {"I will add later if i find any"}
local items1 = {"particles/inferno_fx/molotov_explosion.vpcf",
                "particles/explosions_fx/explosion_c4_500.vpcf",
                "particles/inferno_fx/explosion_incend_air_falling.vpcf",
                "particles/inferno_fx/explosion_incend_air_splash07a.vpcf"}
    
local lp1 = Menu.Checker("Play On Local Player", true)
local victim1 = Menu.Checker("Play On Victim", false)
local effectsv = Menu.Combo('Victim Effect', 0, items1)
local effectsl = Menu.Combo('Local Effect', 0, items2)
local function on_game_event(event_data)
    local success, err = pcall(function()
        if event_data:GetName() ~= 'player_death' then
            return
        end


        local victim = event_data:GetPlayerPawn("userid")
        local attacker_controller = event_data:GetPlayerController("attacker")

        if not attacker_controller or not attacker_controller.m_bIsLocalPlayerController then
            return
        end


        if not victim then
            return
        end
        

        local local_player_pawn = event_data:GetPlayerPawn("attacker")

        if not local_player_pawn then
            return
        end


        local victim_ptr = ffi.cast('uintptr_t*', victim)[0]
        local local_ptr = ffi.cast('uintptr_t*', local_player_pawn)[0]

        if victim_ptr and victim1:GetBool() then
            PlayEffect(tostring(items1[effectsv:GetInt() + 1]), 5, victim_ptr, 0, 0, 0, 0, 0, 0)
        end

        if local_ptr and lp1:GetBool() then
            PlayEffect("particles/blood_impact/impact_taser_bodyfx.vpcf", 5, local_ptr, 0, 0, 0, 0, 0, 0)
        end
    end)
    if not success then
        print("Error" .. tostring(err))
    end
end

Cheat.RegisterCallback("OnFireGameEvent", on_game_event)
