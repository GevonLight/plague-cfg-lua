local WM = {}

WM.font_name = "wm_font"

if Renderer and Renderer.LoadFontFromFile then
    Renderer.LoadFontFromFile(WM.font_name, "verdana", 13, true)
elseif Renderer and Renderer.LoadFont then
    Renderer.LoadFont(WM.font_name, 13, true)
end

WM.script_name = "Script"

function WM.SetScriptName(name)
    if type(name) == "string" and name ~= "" then
        WM.script_name = name
    end
end

WM.positions = {
    "Top-left",
    "Top-right",
    "Bottom-left",
    "Bottom-right"
}

WM.current_position = WM.positions[1]
WM.extra_lines = {}
WM.hit_end_time = 0
WM.hitmarker_duration = 0.4
WM.hitmarker_size = 8
WM.hitmarker_color = Color(255, 255, 255, 255)
WM.spec_pos = {x = 10, y = 200}
WM.spec_drag = false
WM.spec_drag_offset = {x = 0, y = 0}
WM.hitlogs = {}
WM.hitlog_modes = {"All", "Hit", "Miss"}
WM.hitlog_positions = {"Below crosshair", "Top-left", "Top-right", "Bottom-left", "Bottom-right"}
WM.hitlog_position = WM.hitlog_positions[1]
WM.hitlog_color_hit = Color(120, 255, 120, 255)
WM.hitlog_color_miss = Color(255, 120, 120, 255)
WM.watermark_styles = {"Classic", "Modern", "Neverlose"}
WM.current_style = WM.watermark_styles[2]

WM.accent_color = Color(60, 110, 255, 255)

function WM.SetAccentColor(col)
    if col then WM.accent_color = col end
end

function WM.SetPosition(pos)
    for _, p in ipairs(WM.positions) do
        if p == pos then
            WM.current_position = p
            return
        end
    end
end

function WM.GetPosition()
    return WM.current_position
end

function WM.SetExtraLines(lines)
    if type(lines) == "table" then
        WM.extra_lines = lines
    else
        WM.extra_lines = {}
    end
end

local function text_width(text)
    if Renderer and Renderer.CalcTextSize then
        local sz = Renderer.CalcTextSize(WM.font_name, text)
        return sz.x
    elseif Renderer and Renderer.GetTextSize then
        local sz = Renderer.GetTextSize(WM.font_name, text)
        return sz.x
    end
    return #text * 6
end

function WM.GetAccentColor()
    return WM.accent_color
end

function WM.GetPing()
    if not Entities or not Entities.GetHighestEntityIndex then return 0 end
    local highest = Entities.GetHighestEntityIndex() or 0
    for i = 1, highest do
        local e = Entities.GetEntityFromIndex(i)
        if e and e.m_bIsLocalPlayerController then
            return e.m_iPing or 0
        end
    end
    return 0
end

function WM.SetHitlogPosition(pos)
    for _, p in ipairs(WM.hitlog_positions) do
        if p == pos then
            WM.hitlog_position = p
            return
        end
    end
end

function WM.SetHitlogColors(hitCol, missCol)
    if hitCol then WM.hitlog_color_hit = hitCol end
    if missCol then WM.hitlog_color_miss = missCol end
end

function WM.SetHitmarkerStyle(size, color)
    if type(size) == "number" then WM.hitmarker_size = size end
    if color then WM.hitmarker_color = color end
end

function WM.SetStyle(style)
    for _, s in ipairs(WM.watermark_styles) do
        if s == style then
            WM.current_style = s
            return
        end
    end
end

function WM.GetStyle()
    return WM.current_style
end

local function get_initials(name)
    local initials = ""
    for word in string.gmatch(name or "", "%S+") do
        initials = initials .. string.sub(word, 1, 1)
        if #initials >= 2 then break end
    end
    if #initials < 2 then
        local cleaned = string.gsub(name or "", "%s", "")
        initials = string.sub(cleaned, 1, 2)
    end
    return string.upper(initials)
end

local function draw_fps_icon(x, y, col)
    Renderer.DrawLine(Vector2D(x, y + 6), Vector2D(x + 2, y + 4), col, 2)
    Renderer.DrawLine(Vector2D(x + 2, y + 4), Vector2D(x + 4, y + 6), col, 2)
    Renderer.DrawLine(Vector2D(x + 4, y + 6), Vector2D(x + 8, y), col, 2)
end

local function draw_clock_icon(x, y, col)
    Renderer.DrawRect(Vector2D(x, y), Vector2D(x + 8, y + 8), col, 4)
    Renderer.DrawLine(Vector2D(x + 4, y + 4), Vector2D(x + 4, y + 2), col, 1)
    Renderer.DrawLine(Vector2D(x + 4, y + 4), Vector2D(x + 6, y + 4), col, 1)
end

local function draw_user_icon(x, y, col)
    Renderer.DrawRectFilled(Vector2D(x + 2, y), Vector2D(x + 6, y + 4), col, 4)
    Renderer.DrawRectFilled(Vector2D(x + 1, y + 4), Vector2D(x + 7, y + 8), col, 4)
end

local function draw_ping_icon(x, y, col)
    Renderer.DrawRectFilled(Vector2D(x, y + 6), Vector2D(x + 1, y + 8), col, 0)
    Renderer.DrawRectFilled(Vector2D(x + 3, y + 4), Vector2D(x + 4, y + 8), col, 0)
    Renderer.DrawRectFilled(Vector2D(x + 6, y + 2), Vector2D(x + 7, y + 8), col, 0)
end

function WM.GetSpectators()
    local specs = {}
    if not Entities or not Entities.GetHighestEntityIndex then return specs end
    local local_ctrl, local_pawn
    local highest = Entities.GetHighestEntityIndex() or 0
    for i = 1, highest do
        local e = Entities.GetEntityFromIndex(i)
        if e and e.m_bIsLocalPlayerController then
            local_ctrl = e
            local_pawn = e.m_hPawn
            break
        end
    end
    if not local_pawn then return specs end
    local spectated = local_pawn
    if local_pawn.m_iHealth == 0 then
        local obs = local_pawn.m_pObserverServices
        if obs then
            local target = Entities.GetEntityFromHandle(obs.m_hObserverTarget)
            if target then spectated = target end
        end
    end
    for i = 1, highest do
        local e = Entities.GetEntityFromIndex(i)
        if e and e ~= local_ctrl and not e.m_bIsHLTV then
            local pawn = e.m_hObserverPawn
            if pawn and pawn.m_iHealth == 0 then
                local obs = pawn.m_pObserverServices
                if obs then
                    local target = Entities.GetEntityFromHandle(obs.m_hObserverTarget)
                    if target == spectated then
                        table.insert(specs, e.m_sSanitizedPlayerName)
                    end
                end
            end
        end
    end
    return specs
end

function WM.DrawSpectators(specs)
    if not Renderer or not Renderer.DrawRectFilled then return end
    if #specs == 0 then
        WM.spec_drag = false
        return
    end
    local accent = WM.GetAccentColor()
    local width, line_h = 160, 15
    local height = 20 + #specs * line_h
    local x, y = WM.spec_pos.x, WM.spec_pos.y

    local cursor = Input.GetCursorPos()
    local mx, my = cursor.x, cursor.y
    local inside = mx >= x and mx <= x + width and my >= y and my <= y + height
    if Input.GetKeyDown(0x01) then
        if not WM.spec_drag and inside then
            WM.spec_drag = true
            WM.spec_drag_offset.x = mx - x
            WM.spec_drag_offset.y = my - y
        elseif WM.spec_drag then
            WM.spec_pos.x = mx - WM.spec_drag_offset.x
            WM.spec_pos.y = my - WM.spec_drag_offset.y
        end
    else
        WM.spec_drag = false
    end

    x, y = WM.spec_pos.x, WM.spec_pos.y
    Renderer.DrawRectFilled(Vector2D(x, y), Vector2D(x + width, y + height), Color(20, 20, 25, 200), 4)
    Renderer.DrawRect(Vector2D(x, y), Vector2D(x + width, y + height), accent, 4)
    Renderer.DrawText(WM.font_name, "Spectators", Vector2D(x + 8, y + 4), false, false, Color(255, 255, 255, 255))
    for i, name in ipairs(specs) do
        Renderer.DrawText(WM.font_name, name, Vector2D(x + 8, y + 4 + i * line_h), false, false, Color(255, 255, 255, 255))
    end
end

function WM.RegisterHit(duration)
    duration = duration or WM.hitmarker_duration
    WM.hitmarker_duration = duration
    local now = Globals and Globals.GetCurrentTime and Globals.GetCurrentTime() or 0
    WM.hit_end_time = now + duration
end

function WM.DrawHitmarker()
    if not Renderer or not Renderer.DrawLine then return end
    local now = Globals and Globals.GetCurrentTime and Globals.GetCurrentTime() or 0
    local remain = WM.hit_end_time - now
    if remain <= 0 then return end
    local alpha = math.floor(WM.hitmarker_color.a * remain / WM.hitmarker_duration)
    local screen = Renderer.GetScreenSize()
    local cx, cy = screen.x / 2, screen.y / 2
    local col = Color(WM.hitmarker_color.r, WM.hitmarker_color.g, WM.hitmarker_color.b, alpha)
    local size = WM.hitmarker_size
    Renderer.DrawLine(Vector2D(cx - size, cy - size), Vector2D(cx - size / 2, cy - size / 2), col, 2)
    Renderer.DrawLine(Vector2D(cx + size, cy - size), Vector2D(cx + size / 2, cy - size / 2), col, 2)
    Renderer.DrawLine(Vector2D(cx - size, cy + size), Vector2D(cx - size / 2, cy + size / 2), col, 2)
    Renderer.DrawLine(Vector2D(cx + size, cy + size), Vector2D(cx + size / 2, cy + size / 2), col, 2)
end

function WM.AddHitLog(text, typ)
    local now = Globals and Globals.GetCurrentTime and Globals.GetCurrentTime() or 0
    table.insert(WM.hitlogs, {text = text, typ = typ, time = now})
end

local function calc_log_size(text)
    return text_width(text) + 10, 18
end

function WM.DrawHitLogs(mode, position)
    if not Renderer or not Renderer.DrawText then return end
    position = position or WM.hitlog_position
    local now = Globals and Globals.GetCurrentTime and Globals.GetCurrentTime() or 0
    for i = #WM.hitlogs, 1, -1 do
        if now - WM.hitlogs[i].time > 5 then
            table.remove(WM.hitlogs, i)
        end
    end

    local screen = Renderer.GetScreenSize()
    local base_x, base_y = screen.x / 2, screen.y / 2 + 100
    local grow_down = true
    if position == "Top-left" then
        base_x, base_y = 10, 10
    elseif position == "Top-right" then
        base_x, base_y = screen.x - 10, 10
    elseif position == "Bottom-left" then
        base_x, base_y = 10, screen.y - 10
        grow_down = false
    elseif position == "Bottom-right" then
        base_x, base_y = screen.x - 10, screen.y - 10
        grow_down = false
    end

    local offset = 0
    for _, log in ipairs(WM.hitlogs) do
        if mode == "All" or mode == log.typ then
            local elapsed = now - log.time
            local alpha = math.floor(255 * (1 - elapsed / 5))
            if alpha < 0 then alpha = 0 end
            local w, h = calc_log_size(log.text)
            local x = base_x - w / 2
            local y = grow_down and (base_y + offset) or (base_y - offset - h)
            if position == "Top-left" or position == "Bottom-left" then
                x = base_x
            elseif position == "Top-right" or position == "Bottom-right" then
                x = base_x - w
            end
            local accent = (log.typ == "Hit") and WM.hitlog_color_hit or WM.hitlog_color_miss
            accent = Color(accent.r, accent.g, accent.b, alpha)
            local bg = Color(20, 20, 25, math.floor(180 * (alpha / 255)))
            Renderer.DrawRectFilled(Vector2D(x, y), Vector2D(x + w, y + h), bg, 4)
            Renderer.DrawRectFilled(Vector2D(x, y), Vector2D(x + 3, y + h), accent, 4)
            local text_col = Color(255, 255, 255, alpha)
            Renderer.DrawText(WM.font_name, log.text, Vector2D(x + 6, y + 3), false, false, text_col)
            offset = offset + h + 2
        end
    end
end

function WM.Draw(name, position, lines, style)
    position = position or WM.current_position
    style = style or WM.current_style
    name = name or WM.script_name
    if not Renderer or not Renderer.GetScreenSize then return end

    local frame_time = Globals and Globals.GetFrameTime and Globals.GetFrameTime() or 0
    local fps = 0
    if frame_time > 0 then
        fps = math.floor(1 / frame_time + 0.5)
    end
    local time_full = os.date("%H:%M:%S")
    local time_short = os.date("%H:%M")
    local user = Cheat and Cheat.GetUserName and Cheat.GetUserName() or "Unknown"
    local ping = WM.GetPing()

    if style == "Neverlose" then
        local tag_text = get_initials(name)
        local icon_size = 8
        local seg_pad = 4
        local body_elements = {
            {icon = draw_fps_icon, text = string.format("%d fps", fps)},
            {icon = draw_clock_icon, text = time_short},
            {icon = draw_ping_icon, text = string.format("%d ms", ping)},
            {icon = draw_user_icon, text = user}
        }
        local body_w = seg_pad
        for _, e in ipairs(body_elements) do
            local tw = text_width(e.text)
            e.text_w = tw
            e.width = icon_size + 2 + tw + seg_pad
            body_w = body_w + e.width
        end
        local tag_w = text_width(tag_text) + seg_pad * 2
        local gap = 3
        local width = tag_w + gap + body_w
        local height = 20
        local x, y = 10, 10
        local screen = Renderer.GetScreenSize()
        if position == "Top-right" then
            x = screen.x - width - 10
        elseif position == "Bottom-left" then
            y = screen.y - height - 10
        elseif position == "Bottom-right" then
            x = screen.x - width - 10
            y = screen.y - height - 10
        end
        local accent = WM.GetAccentColor()
        Renderer.DrawRectFilled(Vector2D(x, y), Vector2D(x + tag_w, y + height), accent, 6)
        Renderer.DrawText(WM.font_name, tag_text, Vector2D(x + seg_pad, y + 4), false, false, Color(0, 0, 0, 255))
        local body_x = x + tag_w + gap
        Renderer.DrawRectFilled(Vector2D(body_x, y), Vector2D(body_x + body_w, y + height), Color(20, 20, 25, 200), 6)
        local cursor = body_x + seg_pad
        for _, e in ipairs(body_elements) do
            e.icon(cursor, y + 6, accent)
            cursor = cursor + icon_size + 2
            Renderer.DrawText(WM.font_name, e.text, Vector2D(cursor, y + 4), false, false, Color(255, 255, 255, 255))
            cursor = cursor + e.text_w + seg_pad
        end
        return
    end

    local info_line = string.format("%d fps | %s | %s | %d ms", fps, time_full, user, ping)
    local header_line = info_line
    if style == "Classic" then
        header_line = string.format("%s | %s", string.upper(name), info_line)
    end
    local content = {header_line}
    local extras = lines or WM.extra_lines
    if type(extras) == "table" then
        for _, line in ipairs(extras) do
            table.insert(content, line)
        end
    end

    local padding = 8
    local tag_text = string.upper(name)
    local tag_w, width = 0, 0
    if style == "Modern" then
        tag_w = text_width(tag_text) + padding * 2
        width = tag_w
    end
    for _, text in ipairs(content) do
        local w = text_width(text) + padding * 2
        if style == "Modern" then
            if tag_w + w > width then width = tag_w + w end
        else
            if w > width then width = w end
        end
    end

    local height = 20 + (#content - 1) * 15
    local x, y = 10, 10
    local screen = Renderer.GetScreenSize()

    if position == "Top-right" then
        x = screen.x - width - 10
    elseif position == "Bottom-left" then
        y = screen.y - height - 10
    elseif position == "Bottom-right" then
        x = screen.x - width - 10
        y = screen.y - height - 10
    end

    local accent = WM.GetAccentColor()

    if style == "Modern" then
        Renderer.DrawRectFilled(Vector2D(x, y), Vector2D(x + width, y + height), Color(25, 25, 30, 220), 6)
        Renderer.DrawText(WM.font_name, tag_text, Vector2D(x + padding, y + 4), false, false, Color(255, 255, 255, 255))
        for i, text in ipairs(content) do
            local tx = x + tag_w + padding
            local ty = y + 4 + (i - 1) * 15
            Renderer.DrawText(WM.font_name, text, Vector2D(tx, ty), false, false, Color(255, 255, 255, 255))
        end
    else
        Renderer.DrawRectFilled(Vector2D(x, y), Vector2D(x + width, y + height), Color(20, 20, 25, 200), 4)
        Renderer.DrawRect(Vector2D(x, y), Vector2D(x + width, y + height), accent, 4)
        for i, text in ipairs(content) do
            local tx = x + padding
            local ty = y + 4 + (i - 1) * 15
            Renderer.DrawText(WM.font_name, text, Vector2D(tx + 1, ty + 1), false, false, Color(0, 0, 0, 200))
            Renderer.DrawText(WM.font_name, text, Vector2D(tx, ty), false, false, Color(255, 255, 255, 255))
        end
    end
end

return WM