package.path = "C:\\plaguecheat.cc\\lib\\?.lua;" .. package.path
local GUI = require("GUI_LIB")
local LIP = require("LIP")
GUI.Initialize()

local kerning_map = {
    ["LO"] = -2, ["OO"] = -3, ["NE"] = -2, ["LI"] = -1,
    ["Hit Enemy"] = -3,
    ["Enemy in"] = -2,
    ["in the"] = -1,
    ["the head"] = -2,
    ["head for"] = -1,
    ["for 100"] = -2,
    ["100 damage"] = -1,
    ["Hurt by"] = -2,
    ["by Player"] = -1,
    ["Player in"] = -2,
    ["damage"] = -1,
}

local watermark_kerning_map = {
    ["PL"] = -2, ["LA"] = -1, ["AG"] = -1, ["GU"] = -1, ["UE"] = -1, ["EC"] = -1, ["CH"] = -1, ["HE"] = -1, ["EA"] = -1, ["AT"] = -1,
    ["User"] = -2, ["FPS"] = -1, ["Ping"] = -1, ["Ms"] = -1,
    ["User FPS"] = -3,
    ["FPS Ping"] = -2,
    ["Ping Ms"] = -2,
}

local widthMapUI = {
  [' '] = 4, ['!'] = 4, ['"'] = 5, ['#'] = 9, ['$'] = 7, ['%'] = 13, ['&'] = 9,
  ['\''] = 3, ['('] = 5, [')'] = 5, ['*'] = 7, ['+'] = 9, [','] = 4, ['-'] = 5,
  ['.'] = 4, ['/'] = 5, ['0'] = 7, ['1'] = 7, ['2'] = 7, ['3'] = 7, ['4'] = 7,
  ['5'] = 7, ['6'] = 7, ['7'] = 7, ['8'] = 7, ['9'] = 7, [':'] = 5, [';'] = 5,
  ['<'] = 9, ['='] = 9, ['>'] = 9, ['?'] = 6, ['@'] = 12, ['A'] = 8, ['B'] = 8,
  ['C'] = 8, ['D'] = 9, ['E'] = 7, ['F'] = 7, ['G'] = 9, ['H'] = 9, ['I'] = 5,
  ['J'] = 5, ['K'] = 8, ['L'] = 6, ['M'] = 10, ['N'] = 9, ['O'] = 9, ['P'] = 7,
  ['Q'] = 9, ['R'] = 8, ['S'] = 7, ['T'] = 8, ['U'] = 9, ['V'] = 8, ['W'] = 12,
  ['X'] = 8, ['Y'] = 7, ['Z'] = 7, ['['] = 5, ['\\'] = 5, [']'] = 5, ['^'] = 9,
  ['_'] = 7, ['`'] = 7, ['a'] = 7, ['b'] = 7, ['c'] = 6, ['d'] = 7, ['e'] = 7,
  ['f'] = 4, ['g'] = 7, ['h'] = 7, ['i'] = 3, ['j'] = 4, ['k'] = 6, ['l'] = 3,
  ['m'] = 11, ['n'] = 7, ['o'] = 7, ['p'] = 7, ['q'] = 7, ['r'] = 5, ['s'] = 6,
  ['t'] = 4, ['u'] = 7, ['v'] = 6, ['w'] = 10, ['x'] = 6, ['y'] = 6, ['z'] = 6,
  ['{'] = 6, ['|'] = 5, ['}'] = 6, ['~'] = 9,
}

local function ApproxTextWidthUI(txt)
    local totalWidth = 0
    local text_to_measure = tostring(txt or "")
    for i = 1, #text_to_measure do
        local ch = text_to_measure:sub(i, i)
        totalWidth = totalWidth + (widthMapUI[ch] or 7)
    end
    return totalWidth
end

local function ApplyKerning(currentX, prevText, nextText)
    if prevText and nextText then
        local pair = prevText:sub(-1) .. nextText:sub(1, 1)
        local kerningAdjustment = kerning_map[pair] or 0
        return currentX + kerningAdjustment
    end
    return currentX
end

local function ApplyWatermarkKerning(currentX, prevText, nextText)
    if prevText and nextText then
        local pair = prevText:sub(-1) .. nextText:sub(1, 1)
        local kerningAdjustment = watermark_kerning_map[pair] or 0
        return currentX + kerningAdjustment
    end
    return currentX
end

GUI.colors.window = Color(30, 35, 45, 240)
GUI.colors.header = Color(30, 35, 45, 240)
GUI.colors.button = Color(30, 35, 45, 240)
GUI.colors.checkbox = Color(50, 55, 65, 255)
GUI.colors.checkboxActive = Color(100, 150, 255, 255)
GUI.colors.slider = Color(30, 35, 45, 240)
GUI.colors.sliderTrack = Color(50, 55, 65, 255)
GUI.colors.sliderBar = Color(100, 150, 255, 255)
GUI.colors.combobox = Color(30, 35, 45, 240)
GUI.colors.comboboxDropdownBg = Color(30, 35, 45, 240)
GUI.colors.comboboxHover = Color(50, 55, 65, 255)
GUI.colors.comboboxActive = Color(100, 150, 255, 255)
GUI.colors.text = Color(255, 255, 255, 255)
GUI.colors.sidebarButtonActive = Color(100, 150, 255, 255)
GUI.colors.sidebarButtonTextActive = Color(255, 255, 255, 255)
GUI.colors.buttonHover = Color(50, 55, 65, 255)
GUI.colors.buttonActive = Color(100, 150, 255, 255)
GUI.colors.sliderTextActive = Color(255, 255, 255, 255)
GUI.colors.sliderOutline = Color(60, 65, 75, 255)
GUI.colors.headerText = Color(255, 255, 255, 255)

local enabled = Menu.Checker("Watermark: Enable", true)
local pos_x = Menu.Slider("Watermark: Position X", 1820, 0, 1920)
local pos_y = Menu.Slider("Watermark: Position Y", 10, 0, 1080)
local show_fps = Menu.Checker("FPS", false)
local show_ping = Menu.Checker("Ping", false)
local show_username = Menu.Checker("Username", false)
local show_time = Menu.Checker("clock", false)
local value_color = Menu.Checker("Color", false, true)
local spectator_enabled = Menu.Checker("Spectator List", false)

local watermark_enabled = Menu.Checker("Enable Watermark", true)
local watermark_pos_x = 1640
local watermark_pos_y = 3
local show_fps = Menu.Checker("Show FPS", true)
local show_ping = Menu.Checker("Show Ping", false)
local show_username = Menu.Checker("Show Username", false)
local show_time = Menu.Checker("Show Clock", false)
local hitlog_enabled = Menu.Checker("Enable Hitlog", false)
local hitlog_pos_x = 10
local hitlog_pos_y = 3
local spectator_pos_x = 1790
local spectator_pos_y = 410
local spectator_enabled = Menu.Checker("Enable Spectator List", false)
local box_opacity = Menu.Slider("Box Opacity", 256, 100, 280)
local gradient_intensity = Menu.Slider("Gradient Intensity", 255, 100, 255)
local animation_speed = Menu.Slider("Animation Speed", 8, 1, 20)
local fade_speed = Menu.Slider("Fade Speed", 8, 1, 20)

local blockbot_enabled = Menu.Checker("Blockbot Enable", false)
local blockbot_key = Menu.Slider("Blockbot Key", 86, 0, 255)
local blockbot_mode = Menu.Slider("Blocking Mode", 0, 0, 1)
local autojump_enabled = Menu.Checker("Auto Jump", false)

local hitsound_enabled = Menu.Checker("Enable Hitsound", false)
local hitsound_volume = Menu.Slider("Hitsound Volume", 50, 1, 100)
local hitsound_type = Menu.Slider("Hitsound Type", 0, 0, 7)
local hitsound_pitch = Menu.Slider("Hitsound Pitch", 100, 50, 200)

local sound_esp_enabled = Menu.Checker("Sound ESP", false)
local sound_peak_radius = Menu.Slider("Peak Radius", 50, 0, 100)
local sound_draw_always = Menu.Checker("Draw Always", false)


local weapon_models_enabled = Menu.Checker("Weapon Models Enable", false)
local weapon_model_selection = Menu.Slider("Weapon Model", 0, 0, 200) -- Geniş range


local hitsound_types = {"Hitmarker", "FT", "Minecraft", "COD", "Bubble", "Bell", "Click", "Pop"}



local function listFilesRecursive(base_path)
    local files = {}
    
    local weapon_files = {
        {path = base_path .. "\\w_rif_ak47_v.vmdl_c", file = "w_rif_ak47_v.vmdl_c"},
        {path = base_path .. "\\w_rif_m4a1_v.vmdl_c", file = "w_rif_m4a1_v.vmdl_c"},
        {path = base_path .. "\\w_pist_glock18_v.vmdl_c", file = "w_pist_glock18_v.vmdl_c"},
        {path = base_path .. "\\w_snip_awp_v.vmdl_c", file = "w_snip_awp_v.vmdl_c"},
        {path = base_path .. "\\w_pist_deagle_v.vmdl_c", file = "w_pist_deagle_v.vmdl_c"}
    }
    return weapon_files
end

local weapon_names = {
    "weapon_glock", "weapon_hkp2000", "weapon_usp_silencer", "weapon_elite", "weapon_p250",
    "weapon_tec9", "weapon_fn57", "weapon_deagle", "weapon_galilar", "weapon_famas",
    "weapon_ak47", "weapon_m4a1", "weapon_m4a1_silencer", "weapon_ssg08", "weapon_aug",
    "weapon_sg556", "weapon_awp", "weapon_scar20", "weapon_g3sg1", "weapon_nova",
    "weapon_xm1014", "weapon_mag7", "weapon_m249", "weapon_negev", "weapon_mac10",
    "weapon_mp9", "weapon_mp7", "weapon_ump45", "weapon_p90", "weapon_bizon",
    "weapon_knife", "weapon_taser", "weapon_defuser", "weapon_heavyarmor", "weapon_molotov",
    "weapon_incgrenade", "weapon_decoy", "weapon_flashbang", "weapon_hegrenade", "weapon_smokegrenade",
    "weapon_healthshot", "weapon_c4", "weapon_revolver", "weapon_fire_grenade", "weapon_cz75a"
}

local weapon_index_map = {}
for i, name in ipairs(weapon_names) do
    weapon_index_map[name] = i
end

local function GetWeaponIndex(name)
    return weapon_index_map[name]
end

local weapons_path = FileSystem.GetGameDirectory() .. "\\csgo\\weapons"
local weapons_path_len = #weapons_path

local menu_names = {}
table.insert(menu_names, "None")

local file_names = {}

local files = listFilesRecursive(weapons_path)

for _, entry in ipairs(files) do
    local full_path = entry.path
    local file = entry.file

    local relative_path = full_path:sub(weapons_path_len - 6):gsub("\\", "/")

    if file:sub(-7) == ".vmdl_c" then
        local base_name = file:sub(1, -8)
        local relative_name = relative_path:sub(1, -8)

        if base_name:sub(-2) == "_w" then
            -- skip _w files
        elseif base_name:sub(-2) == "_v" then
            -- remove _v suffix
            base_name = base_name:sub(1, -3)
            table.insert(menu_names, base_name)
            table.insert(file_names, relative_name)
        else
            table.insert(menu_names, base_name)
            table.insert(file_names, relative_name)
        end
    end
end

local weapon_config = {}
for i = 1, 64 do
    weapon_config[i] = 0
end

local old_weapon_index = 0
local once = false





local sound_runtime_state = {
    active_sound_indicators = {},
    processed_sounds = {},
}

local dmgmarkers_enabled = Menu.Checker("Enable Dmg Markers", false)

local style_selection = 0
local styles = {"Default", "Green", "Orange", "Red"}

local watermark_state = {
    username = Cheat.GetUserName() or "User",
    base_segments = {},
    total_display_segments_count = 0,
    display_segments = {},
    padding = 10,
    innerHeight = 0,
    x = 5, y = 10,
    drag_offset_x = 0, drag_offset_y = 0,
    prev_mouse_down = false,
    saved_x = 0, saved_y = 0,
    avg_frame_time = 0.0,
    smoothing_alpha = 0.005,
    calculated_fps = 0.0,
    last_is_connected = nil,
    text_vertical_offset = 4,
    kerning_map = { ["BALENDIN"] = -2, },
}

if watermark_state.username == "plaguecheat" then
    watermark_state.username = Cheat.GetUserName()
end

watermark_state.base_segments = {
    { text = "BALENDIN", color = Color(255, 255, 255) },
    { text = "MULTI", color = Color(0, 255, 255) },
    { text = " | ", color = Color(150, 150, 150) },
    { text = watermark_state.username, color = Color(0, 255, 255) },
}
watermark_state.total_display_segments_count = #watermark_state.base_segments + 4
for i = 1, watermark_state.total_display_segments_count do
    watermark_state.display_segments[i] = { text = "", color = Color(0,0,0) }
end
for i = 1, #watermark_state.base_segments do
    watermark_state.display_segments[i].text = watermark_state.base_segments[i].text
    watermark_state.display_segments[i].color = watermark_state.base_segments[i].color
end
watermark_state.innerHeight = 13 + watermark_state.padding
watermark_state.saved_x = watermark_state.x
watermark_state.saved_y = watermark_state.y

local last_server_id = nil
local last_map_name = nil

local CONTROL_KEY = 0x11
local SNAP_DISTANCE_THRESHOLD = 250
local SNAP_INDICATOR_COLOR = Color(255, 255, 255, 85)

local function apply_style(style_index)
    if style_index == 0 then
        GUI.colors.window = Color(25, 30, 40, 240)
        GUI.colors.header = Color(25, 30, 40, 240)
        GUI.colors.checkbox = Color(40, 45, 55, 255)
        GUI.colors.checkboxActive = Color(100, 150, 255, 255)
        GUI.colors.sliderTrack = Color(40, 45, 55, 255)
        GUI.colors.sliderBar = Color(100, 150, 255, 255)
        GUI.colors.comboboxHover = Color(40, 45, 55, 255)
        GUI.colors.comboboxActive = Color(100, 150, 255, 255)
        GUI.colors.buttonHover = Color(40, 45, 55, 255)
        GUI.colors.buttonActive = Color(120, 180, 255, 255)
    elseif style_index == 1 then
        GUI.colors.window = Color(20, 35, 25, 240)
        GUI.colors.header = Color(20, 35, 25, 240)
        GUI.colors.checkbox = Color(40, 55, 45, 255)
        GUI.colors.checkboxActive = Color(0, 255, 100, 255)
        GUI.colors.sliderTrack = Color(40, 55, 45, 255)
        GUI.colors.sliderBar = Color(0, 255, 100, 255)
        GUI.colors.comboboxHover = Color(40, 55, 45, 255)
        GUI.colors.comboboxActive = Color(0, 255, 100, 255)
        GUI.colors.buttonHover = Color(40, 55, 45, 255)
        GUI.colors.buttonActive = Color(0, 255, 100, 255)
    elseif style_index == 2 then
        GUI.colors.window = Color(35, 25, 15, 240)
        GUI.colors.header = Color(35, 25, 15, 240)
        GUI.colors.checkbox = Color(55, 40, 25, 255)
        GUI.colors.checkboxActive = Color(255, 165, 0, 255)
        GUI.colors.sliderTrack = Color(55, 40, 25, 255)
        GUI.colors.sliderBar = Color(255, 165, 0, 255)
        GUI.colors.comboboxHover = Color(55, 40, 25, 255)
        GUI.colors.comboboxActive = Color(255, 165, 0, 255)
        GUI.colors.buttonHover = Color(55, 40, 25, 255)
        GUI.colors.buttonActive = Color(255, 165, 0, 255)
    elseif style_index == 3 then
        GUI.colors.window = Color(35, 20, 20, 240)
        GUI.colors.header = Color(35, 20, 20, 240)
        GUI.colors.checkbox = Color(55, 35, 35, 255)
        GUI.colors.checkboxActive = Color(255, 50, 50, 255)
        GUI.colors.sliderTrack = Color(55, 35, 35, 255)
        GUI.colors.sliderBar = Color(255, 50, 50, 255)
        GUI.colors.comboboxHover = Color(55, 35, 35, 255)
        GUI.colors.comboboxActive = Color(255, 50, 50, 255)
        GUI.colors.buttonHover = Color(55, 35, 35, 255)
        GUI.colors.buttonActive = Color(255, 50, 50, 255)
    end
end

local function render_gui_menu()
    if GUI.windows and #GUI.windows > 0 then
        for i, window in ipairs(GUI.windows) do
            if window.visible then
                GUI.Render()
                break
            end
        end
    end
end

Cheat.RegisterCallback("OnRenderer", render_gui_menu)

local function force_show_menu()
    if GUI.windows and #GUI.windows > 0 then
        for i, window in ipairs(GUI.windows) do
            window.visible = true
        end
    end
end

local function create_custom_menu()
    local config = {
        windowTitle = "Balendin Multi Lua",
        contentTitle = "=== BALENDIN MULTI LUA ===",
        topRightText = "v1.0",
        x = 100,
        y = 100,
        width = 500,
        height = 600,
        sidebarWidth = 150,
        sidebarSpacing = 10,
        contentTitleSpacing = 15,
        categories = {"General", "BlockBot", "Sounds", "Misc"}
    }
    
    local window = GUI.CreatePropperMenuLayout(config)
    
    GUI.BeginCategory("General")
    GUI.MenuCombobox("Style", styles, style_selection, function(index)
        style_selection = index
        apply_style(style_selection)

    end)
    GUI.MenuCheckbox("Enable Watermark", true, function(value) 
        watermark_enabled:SetBool(value)
    end)
    GUI.MenuCheckbox("Show FPS", true, function(value)
        if value == false then
            show_fps:SetBool(true)
        else
            show_fps:SetBool(true)
        end
    end)
    GUI.MenuCheckbox("Show Ping", false, function(value)
        show_ping:SetBool(value)
    end)
    GUI.MenuCheckbox("Show Username", false, function(value)
        show_username:SetBool(value)
    end)
    GUI.MenuCheckbox("Show Clock", false, function(value)
        show_time:SetBool(value)
    end)
    GUI.MenuCheckbox("Enable Hitlog", false, function(value)
        hitlog_enabled:SetBool(value)
    end)
    GUI.MenuCheckbox("Enable Spectator List", false, function(value)
        spectator_enabled:SetBool(value)
    end)
    
    GUI.BeginCategory("BlockBot")
    GUI.MenuCheckbox("Blockbot Enable", false, function(value)
        blockbot_enabled:SetBool(value)
    end)
    GUI.MenuSlider("Blockbot Key", 0, 255, 86, function(value)
        blockbot_key:SetInt(value)
    end)
    GUI.MenuSlider("Blocking Mode", 0, 1, 0, function(value)
        blockbot_mode:SetInt(value)
    end)
    GUI.MenuCheckbox("Auto Jump", false, function(value)
        autojump_enabled:SetBool(value)
    end)
    
    GUI.BeginCategory("Sounds")
    GUI.MenuCheckbox("Enable Hitsound", false, function(value)
        hitsound_enabled:SetBool(value)
    end)
    GUI.MenuSlider("Hitsound Volume", 1, 100, 50, function(value)
        hitsound_volume:SetInt(value)
    end)
    GUI.MenuCombobox("Hitsound Type", hitsound_types, hitsound_type:GetInt(), function(index)
        hitsound_type:SetInt(index)
    end)
    GUI.MenuSlider("Hitsound Pitch", 50, 200, 100, function(value)
        hitsound_pitch:SetInt(value)
    end)
    GUI.MenuCheckbox("Sound ESP", false, function(value)
        sound_esp_enabled:SetBool(value)
    end)
    GUI.MenuSlider("Peak Radius", 0, 100, 50, function(value)
        sound_peak_radius:SetInt(value)
    end)
    GUI.MenuCheckbox("Draw Always", false, function(value)
        sound_draw_always:SetBool(value)
    end)
    
    GUI.BeginCategory("Misc")
    GUI.MenuCheckbox("Weapon Models Enable", false, function(value)
        weapon_models_enabled:SetBool(value)
    end)
    GUI.MenuSlider("Weapon Model", 0, math.max(200, #menu_names - 1), 0, function(value)
        weapon_model_selection:SetInt(value)
    end)
    GUI.MenuCheckbox("Enable Dmg Markers", false, function(value)
        dmgmarkers_enabled:SetBool(value)
    end)
    GUI.MenuSlider("Box Opacity", 100, 255, 240, function(value)
        box_opacity:SetInt(value)
    end)
    GUI.MenuSlider("Gradient Intensity", 100, 255, 255, function(value)
        gradient_intensity:SetInt(value)
    end)
    GUI.MenuSlider("Animation Speed", 1, 20, 8, function(value)
        animation_speed:SetInt(value)
    end)
    GUI.MenuSlider("Fade Speed", 1, 20, 8, function(value)
        fade_speed:SetInt(value)
    end)
    
    apply_style(style_selection)
end

Renderer.LoadFontFromFile("wm_font", "Verdana", 12, true)
Renderer.LoadFontFromFile("wm_font_spec", "Verdana", 13, true)

local last_time = Globals.GetCurrentTime()
local frame_count = 0
local fps = 0

local function update_fps()
    local isConnected = Globals.IsConnected()
    
    if not isConnected then
        frame_count = 0
        fps = 0
        last_time = Globals.GetCurrentTime()
        return
    end
    
    frame_count = frame_count + 1
    local current_time = Globals.GetCurrentTime()
    if current_time - last_time >= 1 then
        fps = frame_count
        frame_count = 0
        last_time = current_time
    end
end

local function get_ping()
    if not Globals.IsConnected() then
        return 0
    end
    
    local highest_entity_index = Entities.GetHighestEntityIndex() or 0
    for i = 1, highest_entity_index do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_bIsLocalPlayerController then
            return entity.m_iPing or 0
        end
    end
    return 0
end

local function lerp(a, b, t)
    return a + (b - a) * t
end

local function draw_gradient_line(start, finish, thickness)
    local width = finish.x - start.x
    for i = 0, width do
        local t = i / width
        local r = lerp(100, 150, t)
        local g = lerp(150, 100, t)
        local b = lerp(255, 200, t)
        Renderer.DrawRectFilled(
            Vector2D(start.x + i, start.y),
            Vector2D(start.x + i + 1, start.y + thickness),
            Color(r, g, b, gradient_intensity:GetInt())
        )
    end
end

local function draw_fade_rect(start, finish, color, radius, fade_width)
    local width = finish.x - start.x
    local height = finish.y - start.y
    for i = 0, width do
        local t = 0
        if i < fade_width then
            t = 1 - (i / fade_width)
        elseif i > width - fade_width then
            t = (i - (width - fade_width)) / fade_width
        end
        local alpha = lerp(color.a, 0, t)
        Renderer.DrawRectFilled(
            Vector2D(start.x + i, start.y),
            Vector2D(start.x + i + 1, finish.y),
            Color(color.r, color.g, color.b, math.floor(alpha)),
            radius
        )
    end
end

local watermark_drag = { dragging = false, offset_x = 0, offset_y = 0 }
local spectator_drag = { dragging = false, offset_x = 0, offset_y = 0 }

local blockbot_state = {
    keybind_active = false,
    last_key_state = false,
    blockEnemy = nil,
    currentTarget = nil,
    bot_has_active_jump_command = false
}

local sound_runtime_state = {
    active_sound_indicators = {},
    processed_sounds = {}
}

local hit_effects_state = {
    impacts = {},
    num_impacts = 0,
    hitmarkers = {},
    num_hitmarkers = 0,
    fade_rate = 2.0,
    rise_speed = 50.0
}

local function draw_watermark()
    if not watermark_enabled:GetBool() then return end
    
    local isConnected = Globals.IsConnected()
    
    if not isConnected then
        watermark_state.avg_frame_time = 0.0
        watermark_state.calculated_fps = 0.0
    else
        local current_frame_time = Globals.GetFrameTime() or (1/60)
        if watermark_state.avg_frame_time == 0.0 then
            watermark_state.avg_frame_time = current_frame_time
        else
            watermark_state.avg_frame_time = watermark_state.smoothing_alpha * current_frame_time + (1 - watermark_state.smoothing_alpha) * watermark_state.avg_frame_time
        end
        watermark_state.calculated_fps = (watermark_state.avg_frame_time > 0.000001) and (1.0 / watermark_state.avg_frame_time) or 0.0
    end
    
    fps = math.floor(watermark_state.calculated_fps)

    local white = Color(255, 255, 255, 255)
    local blue_highlight = Color(100, 150, 255, 255)
    local purple_highlight = Color(150, 100, 200, 255)
    local bg = Color(30, 35, 45, box_opacity:GetInt())
    
    if style_selection == 1 then
        bg = Color(20, 35, 25, box_opacity:GetInt())
        blue_highlight = Color(0, 255, 100, 255)
        purple_highlight = Color(0, 255, 100, 255)
    elseif style_selection == 2 then
        bg = Color(35, 25, 15, box_opacity:GetInt())
        blue_highlight = Color(255, 165, 0, 255)
        purple_highlight = Color(255, 165, 0, 255)
    elseif style_selection == 3 then
        bg = Color(35, 20, 20, box_opacity:GetInt())
        blue_highlight = Color(255, 50, 50, 255)
        purple_highlight = Color(255, 50, 50, 255)
    end

    local items = {}
   
    if show_username:GetBool() then
        table.insert(items, { label = "User", value = Cheat.GetUserName(), value_color = Color(184, 211, 255, 255), is_user = true })
    end
    if show_fps:GetBool() then
        table.insert(items, { label = "Fps", value = tostring(fps), value_color = Color(150, 159, 242, 255), is_left = true })
    end
    if show_ping:GetBool() then
        table.insert(items, { label = "Ms", value = tostring(get_ping()), value_color = purple_highlight, is_left = true })
    end
    
    if show_time:GetBool() then
        table.insert(items, { label = nil, value = os.date("%H:%M:%S"), value_color = white, is_time = true })
    end
    
    local spacing = 8
    local total_width = 0
    
            for i, item in ipairs(items) do
        if item.is_time and i ~= #items then goto continue end
        if item.value then
            total_width = total_width + ApproxTextWidthUI(tostring(item.value))
            if item.label then
                total_width = total_width + ApproxTextWidthUI(item.label)
            end
            if i ~= #items then
                total_width = total_width + spacing
            end
        end
        ::continue::
    end
    local text_width = total_width + 8
    local text_height = 22
    local pad = 8
    
    local active_count = 0
    if show_fps:GetBool() then active_count = active_count + 1 end
    if show_username:GetBool() then active_count = active_count + 1 end
    if show_ping:GetBool() then active_count = active_count + 1 end
    if show_time:GetBool() then active_count = active_count + 1 end
    
    local base_x = 1740
    if active_count == 3 then
        base_x = 1800
    elseif active_count == 2 then
        base_x = 1900
    elseif active_count == 1 then
        base_x = 1930
    end
    
    local screen_width = 1920
    local max_x = screen_width - text_width - pad * 2 - 20
    watermark_pos_x = math.min(base_x, max_x)
    
    local start = Vector2D(watermark_pos_x, 3)
    local finish = Vector2D(start.x + text_width + pad * 2, start.y + text_height)

    Renderer.DrawRectFilled(start, finish, bg, 4)
    
    if style_selection ~= 4 then
        local line_y = start.y + 0.1
        local gradient_start = Vector2D(start.x + 1, line_y)
        local gradient_end = Vector2D(finish.x - 1, line_y)
        local width = gradient_end.x - gradient_start.x
        for i = 0, width do
            local t = i / width
            local r, g, b
            if style_selection == 1 then
            
                r = 0
                g = 255
                b = 100
            elseif style_selection == 2 then
                
                r = 255
                g = 165
                b = 0
            elseif style_selection == 3 then
                
                r = 255
                g = 50
                b = 50
            else
                
                r = lerp(100, 150, t)
                g = lerp(150, 100, t)
                b = lerp(255, 200, t)
            end
            local alpha = 255
            if i < 3 then
                alpha = lerp(0, 255, i / 3)
            elseif i > width - 3 then
                alpha = lerp(255, 0, (i - (width - 3)) / 3)
            end
            Renderer.DrawLine(
                Vector2D(gradient_start.x + i, line_y - 0.1),
                Vector2D(gradient_start.x + i, line_y + 2),
                Color(r, g, b, math.floor(alpha)),
                1
            )
        end
    end

    local x = start.x + pad
    local y = start.y + (text_height - 14) / 2 + 2
    for i, item in ipairs(items) do
        if item.is_time and i ~= #items then goto continue end
        if item.value then
            if item.is_user or item.is_left then
                local label = item.label
                local value = tostring(item.value)
                
                local label_width = ApproxTextWidthUI(label)
                local value_width = ApproxTextWidthUI(value)
                
                Renderer.DrawText("wm_font", label, Vector2D(x, y), false, false, white)
                x = x + label_width
                
                x = ApplyWatermarkKerning(x, label, value)
                
                Renderer.DrawText("wm_font", value, Vector2D(x, y), false, false, item.value_color or blue_highlight)
                x = x + value_width
            else
                local value = tostring(item.value)
                local value_width = ApproxTextWidthUI(value)
                
                Renderer.DrawText("wm_font", value, Vector2D(x, y), false, false, item.value_color or blue_highlight)
                x = x + value_width
                
                if item.label then
                    x = ApplyWatermarkKerning(x, value, item.label)
                    x = x + 1
                    
                    local label_width = ApproxTextWidthUI(item.label)
                    Renderer.DrawText("wm_font", item.label, Vector2D(x, y), false, false, white)
                    x = x + label_width
                 end
            end
            x = x + spacing 
        end
        ::continue::
    end

    if Input.IsMenuOpen and Input.IsMenuOpen() then
        local mouse = Input.GetCursorPos and Input.GetCursorPos() or {x=0, y=0}
        local mouse_down = Input.GetKeyDown and Input.GetKeyDown(0x01)
        local wm_x = watermark_pos_x
        local wm_y = watermark_pos_y
        local wm_w = text_width + 16 + 20 + 56
        local wm_h = 22
        
        if not watermark_drag.dragging then
            if mouse_down and mouse.x >= wm_x and mouse.x <= wm_x + wm_w and mouse.y >= wm_y and mouse.y <= wm_y + wm_h then
                watermark_drag.dragging = true
                watermark_drag.offset_x = mouse.x - wm_x
                watermark_drag.offset_y = mouse.y - wm_y
            end
        else
            if mouse_down then
                local new_x = mouse.x - watermark_drag.offset_x
                local new_y = 3
                

                
                watermark_pos_x = new_x
                watermark_pos_y = new_y
            else
                watermark_drag.dragging = false
            end
        end
        

    end

end

local logs = {}
local max_logs = 4
local log_display_time = 5
local log_anim_speed = 8
local log_fade_speed = 0.08
local log_anim_states = {}


local harm_logs = {}
local max_harm_logs = 4
local harm_log_display_time = 5
local harm_log_anim_states = {}

local function add_log(log)
    table.insert(logs, 1, log)
    if #logs > max_logs then table.remove(logs) end
end


local function add_harm_log(log)
    table.insert(harm_logs, 1, log)
    if #harm_logs > max_harm_logs then table.remove(harm_logs) end
end

local hitbox_names = {
    [0] = "generic", [1] = "head", [2] = "chest", [3] = "stomach",
    [4] = "left arm", [5] = "right arm", [6] = "left leg", [7] = "right leg", [-1] = "unknown"
}

local function check_server_change()
    local current_server_id = CVar.FindVar("cl_current_server_id")
    local current_map_name = CVar.FindVar("map_name")
    
    if current_server_id and current_map_name then
        local server_id = current_server_id:GetString()
        local map_name = current_map_name:GetString()
        
        if last_server_id and last_server_id ~= server_id then
            logs = {}
            log_anim_states = {}
            harm_logs = {}
            harm_log_anim_states = {}
        end
        
        if last_map_name and last_map_name ~= map_name then
            logs = {}
            log_anim_states = {}
            harm_logs = {}
            harm_log_anim_states = {}
        end
        
        last_server_id = server_id
        last_map_name = map_name
    end
end

local function on_fire_game_event(event)
    local event_name = event:GetName()
    
    check_server_change()
    
    if event_name == "cs_win_panel_match" then
        logs = {}
        log_anim_states = {}
        harm_logs = {}
        harm_log_anim_states = {}
        return
    end
    
    if not Globals.IsConnected() then
        logs = {}
        log_anim_states = {}
        harm_logs = {}
        harm_log_anim_states = {}
        return
    end
    
    if hitlog_enabled:GetBool() and event_name == "player_hurt" then
        local attacker = nil
        if event.GetPlayerController then attacker = event:GetPlayerController("attacker") end
        if attacker and attacker.m_bIsLocalPlayerController then
            local victim = nil
            if event.GetPlayerController then victim = event:GetPlayerController("userid") end
            local victim_name = victim and victim.m_sSanitizedPlayerName or "Unknown"
            local hitgroup = -1
            if event.GetInt then hitgroup = event:GetInt("hitgroup") or -1 end
            local hitbox = hitbox_names[hitgroup] or hitbox_names[-1]
            local damage = 0
            if event.GetInt then damage = event:GetInt("dmg_health") or 0 end
            local health = 0
            if event.GetInt then health = event:GetInt("health") or 0 end
            add_log({
                type = "hit",
                victim = victim_name,
                hitbox = hitbox,
                damage = damage,
                health = health,
                time = Globals.GetCurrentTime()
            })
        end
        
        
        local victim = nil
        if event.GetPlayerController then victim = event:GetPlayerController("userid") end
        if victim and victim.m_bIsLocalPlayerController then
            local attacker = nil
            if event.GetPlayerController then attacker = event:GetPlayerController("attacker") end
            local attacker_name = attacker and attacker.m_sSanitizedPlayerName or "Unknown"
            local damage = 0
            if event.GetInt then damage = event:GetInt("dmg_health") or 0 end
            local health = 0
            if event.GetInt then health = event:GetInt("health") or 0 end
            local hitgroup = -1
            if event.GetInt then hitgroup = event:GetInt("hitgroup") or -1 end
            local hitbox = hitbox_names[hitgroup] or hitbox_names[-1]
            
            add_harm_log({
                type = "harm",
                attacker = attacker_name,
                hitbox = hitbox,
                damage = damage,
                health = health,
                time = Globals.GetCurrentTime()
            })
        end
    end

    
    if hitsound_enabled:GetBool() and event:GetName() == "player_hurt" then
        local attacker = nil
        if event.GetPlayerController then attacker = event:GetPlayerController("attacker") end
        if attacker and attacker.m_bIsLocalPlayerController then
            local hitsound_type_value = hitsound_type:GetInt()
            local volume = hitsound_volume:GetInt() / 100
            local pitch = hitsound_pitch:GetInt() / 100
            
            CVar.ExecuteClientCmd("snd_toolvolume " .. volume)
            
            if hitsound_type_value == 0 then
                CVar.ExecuteClientCmd("play \\sounds\\hitmarker")
            elseif hitsound_type_value == 1 then
                CVar.ExecuteClientCmd("play \\sounds\\ft")
            elseif hitsound_type_value == 2 then
                CVar.ExecuteClientCmd("play \\sounds\\minecraft")
            elseif hitsound_type_value == 3 then
                CVar.ExecuteClientCmd("play \\sounds\\cod")
            elseif hitsound_type_value == 4 then
                CVar.ExecuteClientCmd("play \\sounds\\bubble")
            elseif hitsound_type_value == 5 then
                CVar.ExecuteClientCmd("play \\sounds\\bell")
            elseif hitsound_type_value == 6 then
                CVar.ExecuteClientCmd("play \\sounds\\click")
            elseif hitsound_type_value == 7 then
                CVar.ExecuteClientCmd("play \\sounds\\pop")
            end
        end
    end

    if sound_esp_enabled:GetBool() and event:GetName() == "player_sound" then
        local currentTime = Globals.GetCurrentTime()
        local userid = event:GetPlayerPawn("userid") or 0
        local eventRadius = event:GetInt("radius") or 0
        local duration = event:GetInt("duration") or 2

        local soundId = string.format("%s_%f_%d", tostring(userid), currentTime, eventRadius)

        if sound_runtime_state.processed_sounds[soundId] then
            return
        end

        sound_runtime_state.processed_sounds[soundId] = currentTime

        local localPlayerPawn = nil
        for i = 1, 64 do
            local entity = Entities.GetEntityFromIndex(i)
            if entity and entity.m_bIsLocalPlayerController and entity.m_hPawn then
                localPlayerPawn = Entities.GetEntityFromHandle(entity.m_hPawn)
                break
            end
        end

        if userid and userid.m_iTeamNum and localPlayerPawn and localPlayerPawn.m_iTeamNum and (userid.m_iTeamNum == localPlayerPawn.m_iTeamNum) then
            return
        end

        if userid and userid.m_pGameSceneNode and userid.m_pGameSceneNode.m_vecAbsOrigin then
            local position = userid.m_pGameSceneNode.m_vecAbsOrigin
            
            local initial_distance_check_passed = false
            if localPlayerPawn and localPlayerPawn.m_pGameSceneNode and localPlayerPawn.m_pGameSceneNode.m_vecAbsOrigin then
                local current_player_distance = localPlayerPawn.m_pGameSceneNode.m_vecAbsOrigin:DistTo(position)
                if sound_draw_always:GetBool() or (current_player_distance <= eventRadius) then
                    initial_distance_check_passed = true
                end
            end

            table.insert(sound_runtime_state.active_sound_indicators, {
                startTime = Globals.GetCurrentTime(),
                duration = duration,
                position = position,
                eventRadius = eventRadius,
                soundId = soundId,
                initial_distance_check_passed = initial_distance_check_passed
            })
        end
    end

    if dmgmarkers_enabled:GetBool() then
    local name = event:GetName()

    if name == "bullet_impact" then
        local ctrl = event:GetPlayerController("userid")
        if ctrl and ctrl.m_bIsLocalPlayerController then
            local pos = Vector(
                event:GetInt("x"),
                event:GetInt("y"),
                event:GetInt("z")
            )
                hit_effects_state.num_impacts = hit_effects_state.num_impacts + 1
                hit_effects_state.impacts[hit_effects_state.num_impacts] = { time = 1.0, position = pos }
        end
    elseif name == "player_hurt" then
        local att = event:GetPlayerController("attacker")
        if not att or not att.m_bIsLocalPlayerController then return end
        local victim = event:GetPlayerPawn("userid")
        if not victim or not victim.m_pGameSceneNode then
            return
        end

        local vicPos = victim.m_pGameSceneNode.m_vecAbsOrigin
        local best_i, best_d2 = -1, math.huge

        for i = 1, hit_effects_state.num_impacts do
            local imp = hit_effects_state.impacts[i]
            local dx = imp.position.x - vicPos.x
            local dy = imp.position.y - vicPos.y
            local dz = imp.position.z - vicPos.z
            local d2 = dx*dx + dy*dy + dz*dz
            if d2 < best_d2 then
                best_d2, best_i = d2, i
            end
        end

        if best_i > 0 then
            local damage = event:GetInt("dmg_health")
                hit_effects_state.num_hitmarkers = hit_effects_state.num_hitmarkers + 1
                hit_effects_state.hitmarkers[hit_effects_state.num_hitmarkers] = {
                    opacity = 1.0,
                position = hit_effects_state.impacts[best_i].position,
                    damage = damage,
                    offset = 0
                }
                
                for i = best_i, hit_effects_state.num_impacts - 1 do
                    hit_effects_state.impacts[i] = hit_effects_state.impacts[i + 1]
                end
                hit_effects_state.impacts[hit_effects_state.num_impacts] = nil
                hit_effects_state.num_impacts = hit_effects_state.num_impacts - 1
        end
    end
    end
end

Cheat.RegisterCallback("OnFireGameEvent", on_fire_game_event)

local function update_log_anim_states(line_height, log_spacing)
        for i, log in ipairs(logs) do
            if not log_anim_states[log] then
                log_anim_states[log] = {y_offset = -line_height, alpha = 0}
            end
            local target_offset = (i-1) * (line_height + 4) -- Bloodline.lua'daki spacing
        local state = log_anim_states[log]
        if math.abs(state.y_offset - target_offset) > 1 then
            state.y_offset = state.y_offset + (target_offset - state.y_offset) * (0.25 * animation_speed:GetInt() / 10)
        else
            state.y_offset = target_offset
        end
        local now = Globals.GetCurrentTime()
        if now - log.time < log_display_time then
            state.alpha = math.min(1, state.alpha + 0.2)
        else
            state.alpha = math.max(0, state.alpha - (log_fade_speed * fade_speed:GetInt() / 10))
        end
    end
    for log, state in pairs(log_anim_states) do
        local found = false
        for _, l in ipairs(logs) do if l == log then found = true break end end
        if not found and state.alpha <= 0.01 then log_anim_states[log] = nil end
    end
end


local function update_harm_log_anim_states(line_height, log_spacing)
    for i, log in ipairs(harm_logs) do
        if not harm_log_anim_states[log] then
            harm_log_anim_states[log] = {y_offset = -line_height, alpha = 0}
        end
        local target_offset = (i-1) * (line_height + 4)
        local state = harm_log_anim_states[log]
        if math.abs(state.y_offset - target_offset) > 1 then
            state.y_offset = state.y_offset + (target_offset - state.y_offset) * (0.25 * animation_speed:GetInt() / 10)
        else
            state.y_offset = target_offset
        end
        local now = Globals.GetCurrentTime()
        if now - log.time < harm_log_display_time then
            state.alpha = math.min(1, state.alpha + 0.2)
        else
            state.alpha = math.max(0, state.alpha - (log_fade_speed * fade_speed:GetInt() / 10))
        end
    end
    for log, state in pairs(harm_log_anim_states) do
        local found = false
        for _, l in ipairs(harm_logs) do if l == log then found = true break end end
        if not found and state.alpha <= 0.01 then harm_log_anim_states[log] = nil end
    end
end




local function update_combined_log_anim_states(line_height, log_spacing, combined_logs)
    for i, combined_log in ipairs(combined_logs) do
        local log = combined_log.log
        local log_type = combined_log.type
        local state = log_type == "hit" and log_anim_states[log] or harm_log_anim_states[log]
        
        if not state then
            if log_type == "hit" then
                log_anim_states[log] = {y_offset = -line_height, alpha = 0}
                state = log_anim_states[log]
            else
                harm_log_anim_states[log] = {y_offset = -line_height, alpha = 0}
                state = harm_log_anim_states[log]
            end
        end

        local target_offset = (i-1) * (line_height + 4) 
        if math.abs(state.y_offset - target_offset) > 1 then
            state.y_offset = state.y_offset + (target_offset - state.y_offset) * (0.25 * animation_speed:GetInt() / 10)
        else
            state.y_offset = target_offset
        end
        
        local now = Globals.GetCurrentTime()
        local display_time = log_type == "hit" and log_display_time or harm_log_display_time
        if now - log.time < display_time then
            state.alpha = math.min(1, state.alpha + 0.2)
        else
            state.alpha = math.max(0, state.alpha - (log_fade_speed * fade_speed:GetInt() / 10))
        end
    end
    
    for log, state in pairs(log_anim_states) do
        local found = false
        for _, l in ipairs(logs) do if l == log then found = true break end end
        if not found and state.alpha <= 0.01 then log_anim_states[log] = nil end
    end
    
    for log, state in pairs(harm_log_anim_states) do
        local found = false
        for _, l in ipairs(harm_logs) do if l == log then found = true break end end
        if not found and state.alpha <= 0.01 then harm_log_anim_states[log] = nil end
    end
end

local function draw_logs()
    if not hitlog_enabled:GetBool() and not (Input.IsMenuOpen and Input.IsMenuOpen()) then return end
    local now = Globals.GetCurrentTime()
    local x = hitlog_pos_x
    local y = 3 
    local line_height = 18 
    local pad_x = 8 
    local pad_y = 3
    local blue_highlight = Color(100, 150, 255, 255)
    local purple_highlight = Color(150, 100, 200, 255)
    local red_highlight = Color(255, 100, 100, 255)
    local bg = Color(30, 35, 45, box_opacity:GetInt())
    local log_spacing = 4 
    
    if style_selection == 1 then
        -- Green theme
        bg = Color(20, 35, 25, box_opacity:GetInt())
        blue_highlight = Color(0, 255, 100, 255)
        purple_highlight = Color(0, 255, 100, 255)
        red_highlight = Color(255, 100, 100, 255)
    elseif style_selection == 2 then
        -- Orange theme
        bg = Color(35, 25, 15, box_opacity:GetInt())
        blue_highlight = Color(255, 165, 0, 255)
        purple_highlight = Color(255, 165, 0, 255)
        red_highlight = Color(255, 100, 100, 255)
    elseif style_selection == 3 then
        -- Red theme
        bg = Color(35, 20, 20, box_opacity:GetInt())
        blue_highlight = Color(255, 50, 50, 255)
        purple_highlight = Color(255, 50, 50, 255)
        red_highlight = Color(255, 100, 100, 255)
    end

    
    local combined_logs = {}
    for i, log in ipairs(logs) do
        table.insert(combined_logs, {log = log, type = "hit", index = i})
    end
    for i, log in ipairs(harm_logs) do
        table.insert(combined_logs, {log = log, type = "harm", index = i})
    end
    
    
    table.sort(combined_logs, function(a, b) return a.log.time > b.log.time end)
    
    
    if #combined_logs > 4 then
        combined_logs = {combined_logs[1], combined_logs[2], combined_logs[3], combined_logs[4]}
    end
    
    
    update_combined_log_anim_states(line_height + log_spacing, log_spacing, combined_logs)
    

    local log_spacing_adjustment = 0 
    
    
    if (Input.IsMenuOpen and Input.IsMenuOpen()) and #logs == 0 and #harm_logs == 0 then
        local prefix = "Hit "; local name = "Enemy"; local mid1 = " in the "; local hitbox = "head"; local mid2 = " for "; local damage = "100"; local mid3 = " damage"
        local w_prefix = ApproxTextWidthUI(prefix)
        local w_name = ApproxTextWidthUI(name)
        local w_mid1 = ApproxTextWidthUI(mid1)
        local w_hitbox = ApproxTextWidthUI(hitbox)
        local w_mid2 = ApproxTextWidthUI(mid2)
        local w_damage = ApproxTextWidthUI(damage)
        local w_mid3 = ApproxTextWidthUI(mid3)
        local text_w = w_prefix + w_name + w_mid1 + w_hitbox + w_mid2 + w_damage + w_mid3
        local box_x = x
        local box_y = y
        local box_w = math.max(36, text_w + pad_x*2 + 6) 
        local box_h = line_height -- box_h değişkenini tanımla
        local start = Vector2D(box_x, box_y)
        local finish = Vector2D(box_x + box_w, box_y + box_h)
        local alpha = box_opacity:GetInt()
        local text_alpha = 255
        Renderer.DrawRectFilled(start, finish, Color(bg.r, bg.g, bg.b, alpha), 4)
        
        if style_selection ~= 4 then
            local line_y = start.y + 0.1
            local gradient_start = Vector2D(start.x + 1, line_y)
            local gradient_end = Vector2D(finish.x - 1, line_y)
            local width = gradient_end.x - gradient_start.x
            for i = 0, width do
                local t = i / width
                local r, g, b
                if style_selection == 1 then
                    
                    r = 0
                    g = 255
                    b = 100
                elseif style_selection == 2 then
                    
                    r = 255
                    g = 165
                    b = 0
                elseif style_selection == 3 then
                    
                    r = 255
                    g = 50
                    b = 50
                else
                    
                    r = lerp(100, 150, t)
                    g = lerp(150, 100, t)
                    b = lerp(255, 200, t)
                end
                local alpha = 255
                if i < 3 then
                    alpha = lerp(0, 255, i / 3)
                elseif i > width - 3 then
                    alpha = lerp(255, 0, (i - (width - 3)) / 3)
                end
                Renderer.DrawLine(
                    Vector2D(gradient_start.x + i, line_y - 0.1),
                    Vector2D(gradient_start.x + i, line_y + 2),
                    Color(r, g, b, math.floor(alpha)),
                    1
                )
            end
        end
        
        local font_height = Renderer.CalcTextSize and Renderer.CalcTextSize("wm_font", "A").y or 14
        local draw_x = x + pad_x
        local draw_y = box_y + (box_h - font_height) / 2 + 2
        
        
        Renderer.DrawText("wm_font", prefix, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
        draw_x = draw_x + w_prefix
        draw_x = ApplyKerning(draw_x, prefix, name)
        
        Renderer.DrawText("wm_font", name, Vector2D(draw_x, draw_y), false, false, Color(100, 150, 255, text_alpha))
        draw_x = draw_x + w_name
        draw_x = ApplyKerning(draw_x, name, mid1)
        
        Renderer.DrawText("wm_font", mid1, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
        draw_x = draw_x + w_mid1
        draw_x = ApplyKerning(draw_x, mid1, hitbox)
        
        Renderer.DrawText("wm_font", hitbox, Vector2D(draw_x, draw_y), false, false, Color(150, 159, 242, text_alpha))
        draw_x = draw_x + w_hitbox
        draw_x = ApplyKerning(draw_x, hitbox, mid2)
        
        Renderer.DrawText("wm_font", mid2, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
        draw_x = draw_x + w_mid2
        draw_x = ApplyKerning(draw_x, mid2, damage)
        
        Renderer.DrawText("wm_font", damage, Vector2D(draw_x, draw_y), false, false, Color(purple_highlight.r, purple_highlight.g, purple_highlight.b, text_alpha))
        draw_x = draw_x + w_damage
        draw_x = ApplyKerning(draw_x, damage, mid3)
        
        Renderer.DrawText("wm_font", mid3, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
        if style_selection == 4 then
            draw_x = draw_x + 5
            Renderer.DrawText("wm_font", "(85)", Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
        end
            return
        end

    
    for i, combined_log in ipairs(combined_logs) do
        local log = combined_log.log
        local log_type = combined_log.type
        local state = log_type == "hit" and log_anim_states[log] or harm_log_anim_states[log]
        
        if state and state.alpha > 0.01 then
            if log_type == "hit" then
                local name = tostring(log.victim or "")
                local hitbox = tostring(log.hitbox or "")
                local damage = tostring(log.damage or "")
                local health = tostring(log.health or "")
                local prefix = "Hit "
                local mid1 = " in the "
                local mid2 = " for "
                 local mid3 = " damage"
                
                
                local w_prefix = ApproxTextWidthUI(prefix)
                local w_name = ApproxTextWidthUI(name)
                local w_mid1 = ApproxTextWidthUI(mid1)
                local w_hitbox = ApproxTextWidthUI(hitbox)
                local w_mid2 = ApproxTextWidthUI(mid2)
                local w_damage = ApproxTextWidthUI(damage)
                local w_mid3 = ApproxTextWidthUI(mid3)
                
                local text_w = w_prefix + w_name + w_mid1 + w_hitbox + w_mid2 + w_damage + w_mid3
                local box_x = x
                local box_y = y + state.y_offset
                local box_w = math.max(36, text_w + pad_x*2 + 6) 
                local box_h = line_height
                local start = Vector2D(box_x, box_y)
                local finish = Vector2D(box_x + box_w, box_y + box_h)
                local alpha = math.floor(box_opacity:GetInt() * state.alpha)
                local text_alpha = math.floor(255 * state.alpha)
                Renderer.DrawRectFilled(start, finish, Color(bg.r, bg.g, bg.b, alpha), 4)
                
                local line_y = start.y + 0.1
                local gradient_start = Vector2D(start.x + 1, line_y)
                local gradient_end = Vector2D(finish.x - 1, line_y)
                local width = gradient_end.x - gradient_start.x
                for i = 0, width do
                    local t = i / width
                    local r, g, b
                    if style_selection == 1 then
                        r = lerp(0, 200, t)
                        g = lerp(200, 255, t)
                        b = lerp(255, 255, t)
                    elseif style_selection == 4 then
                        r = lerp(120, 180, t)
                        g = lerp(80, 120, t)
                        b = lerp(180, 200, t)
                    else
                        r = lerp(100, 150, t)
                        g = lerp(150, 100, t)
                        b = lerp(255, 200, t)
                    end
                    local alpha = 255
                    if i < 3 then
                        alpha = lerp(0, 255, i / 3)
                    elseif i > width - 3 then
                        alpha = lerp(255, 0, (i - (width - 3)) / 3)
                    end
                    Renderer.DrawLine(
                        Vector2D(gradient_start.x + i, line_y - 0.1),
                        Vector2D(gradient_start.x + i, line_y + 2),
                        Color(r, g, b, math.floor(alpha)),
                        1
                    )
                end
                
                local font_height = Renderer.CalcTextSize and Renderer.CalcTextSize("wm_font", "A").y or 14
                local draw_x = x + pad_x
                local draw_y = box_y + (box_h - font_height) / 2 + 2
                
                
                Renderer.DrawText("wm_font", prefix, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
                draw_x = draw_x + w_prefix
                draw_x = ApplyKerning(draw_x, prefix, name)
                
                Renderer.DrawText("wm_font", name, Vector2D(draw_x, draw_y), false, false, Color(184, 211, 255, text_alpha))
                draw_x = draw_x + w_name
                draw_x = ApplyKerning(draw_x, name, mid1)
                
                Renderer.DrawText("wm_font", mid1, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
                draw_x = draw_x + w_mid1
                draw_x = ApplyKerning(draw_x, mid1, hitbox)
                
                Renderer.DrawText("wm_font", hitbox, Vector2D(draw_x, draw_y), false, false, Color(150, 159, 242, text_alpha))
                draw_x = draw_x + w_hitbox
                draw_x = ApplyKerning(draw_x, hitbox, mid2)
                
                Renderer.DrawText("wm_font", mid2, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
                draw_x = draw_x + w_mid2
                draw_x = ApplyKerning(draw_x, mid2, damage)
                
                Renderer.DrawText("wm_font", damage, Vector2D(draw_x, draw_y), false, false, Color(purple_highlight.r, purple_highlight.g, purple_highlight.b, text_alpha))
                draw_x = draw_x + w_damage
                draw_x = ApplyKerning(draw_x, damage, mid3)
                
                Renderer.DrawText("wm_font", mid3, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
                if style_selection == 4 and health and health ~= "" then
                    draw_x = draw_x + 5
                    Renderer.DrawText("wm_font", "(" .. health .. ")", Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
                end
            elseif log_type == "harm" then
                local attacker = tostring(log.attacker or "")
                local hitbox = tostring(log.hitbox or "")
                local damage = tostring(log.damage or "")
                local health = tostring(log.health or "")
                local prefix = "Hurt by "
                local mid1 = " in the "
                local mid2 = " for "
                local mid3 = " damage"
                
                
                local w_prefix = ApproxTextWidthUI(prefix)
                local w_attacker = ApproxTextWidthUI(attacker)
                local w_mid1 = ApproxTextWidthUI(mid1)
                local w_hitbox = ApproxTextWidthUI(hitbox)
                local w_mid2 = ApproxTextWidthUI(mid2)
                local w_damage = ApproxTextWidthUI(damage)
                local w_mid3 = ApproxTextWidthUI(mid3)
                
                local text_w = w_prefix + w_attacker + w_mid1 + w_hitbox + w_mid2 + w_damage + w_mid3
                local box_x = x
                local box_y = y + state.y_offset
                local box_w = math.max(36, text_w + pad_x*2 + 6) 
                local box_h = line_height
                local start = Vector2D(box_x, box_y)
                local finish = Vector2D(box_x + box_w, box_y + box_h)
                local alpha = math.floor(box_opacity:GetInt() * state.alpha)
                local text_alpha = math.floor(255 * state.alpha)
                Renderer.DrawRectFilled(start, finish, Color(bg.r, bg.g, bg.b, alpha), 4)
                
                local line_y = start.y + 0.1
                local gradient_start = Vector2D(start.x + 1, line_y)
                local gradient_end = Vector2D(finish.x - 1, line_y)
                local width = gradient_end.x - gradient_start.x
                for i = 0, width do
                    local t = i / width
                    local r, g, b
                    if style_selection == 1 then
                        r = lerp(0, 200, t)
                        g = lerp(200, 255, t)
                        b = lerp(255, 255, t)
                    elseif style_selection == 4 then
                        r = lerp(120, 180, t)
                        g = lerp(80, 120, t)
                        b = lerp(180, 200, t)
                    else
                        r = lerp(100, 150, t)
                        g = lerp(150, 100, t)
                        b = lerp(255, 200, t)
                    end
                    local alpha = 255
                    if i < 3 then
                        alpha = lerp(0, 255, i / 3)
                    elseif i > width - 3 then
                        alpha = lerp(255, 0, (i - (width - 3)) / 3)
                    end
                    Renderer.DrawLine(
                        Vector2D(gradient_start.x + i, line_y - 0.1),
                        Vector2D(gradient_start.x + i, line_y + 2),
                        Color(r, g, b, math.floor(alpha)),
                        1
                    )
                end
                
                local font_height = Renderer.CalcTextSize and Renderer.CalcTextSize("wm_font", "A").y or 14
                local draw_x = x + pad_x
                local draw_y = box_y + (box_h - font_height) / 2 + 2
                
                
                Renderer.DrawText("wm_font", prefix, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
                draw_x = draw_x + w_prefix
                draw_x = ApplyKerning(draw_x, prefix, attacker)
                
                Renderer.DrawText("wm_font", attacker, Vector2D(draw_x, draw_y), false, false, Color(red_highlight.r, red_highlight.g, red_highlight.b, text_alpha))
                draw_x = draw_x + w_attacker
                draw_x = ApplyKerning(draw_x, attacker, mid1)
                
                Renderer.DrawText("wm_font", mid1, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
                draw_x = draw_x + w_mid1
                draw_x = ApplyKerning(draw_x, mid1, hitbox)
                
                Renderer.DrawText("wm_font", hitbox, Vector2D(draw_x, draw_y), false, false, Color(150, 159, 242, text_alpha))
                draw_x = draw_x + w_hitbox
                draw_x = ApplyKerning(draw_x, hitbox, mid2)
                
                Renderer.DrawText("wm_font", mid2, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
                draw_x = draw_x + w_mid2
                draw_x = ApplyKerning(draw_x, mid2, damage)
                
                Renderer.DrawText("wm_font", damage, Vector2D(draw_x, draw_y), false, false, Color(red_highlight.r, red_highlight.g, red_highlight.b, text_alpha))
                draw_x = draw_x + w_damage
                draw_x = ApplyKerning(draw_x, damage, mid3)
                
                Renderer.DrawText("wm_font", mid3, Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
                if style_selection == 4 and health and health ~= "" then
                    draw_x = draw_x + 5
                    Renderer.DrawText("wm_font", "(" .. health .. ")", Vector2D(draw_x, draw_y), false, false, Color(255,255,255,text_alpha))
                end
            end
        end
    end
end
Cheat.RegisterCallback("OnRenderer", draw_logs)
Cheat.RegisterCallback("OnRenderer", draw_watermark)

local function HandleBlockBotInput()
    local key_pressed = Input.GetKeyDown and Input.GetKeyDown(blockbot_key:GetInt())
    if key_pressed and not blockbot_state.last_key_state then
        blockbot_state.keybind_active = not blockbot_state.keybind_active
    end
    blockbot_state.last_key_state = key_pressed
end

local function BlockbotLogic(cmd)
    if not blockbot_enabled:GetBool() or not blockbot_state.keybind_active then
        if blockbot_state.bot_has_active_jump_command then 
            CVar.ExecuteClientCmd("-jump")
            blockbot_state.bot_has_active_jump_command = false 
        end
        blockbot_state.blockEnemy = nil
        blockbot_state.currentTarget = nil
        return
    end

    local localPlayer = nil
    for i = 1, 64 do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_bIsLocalPlayerController then
            localPlayer = entity
                break
        end
    end

    if not localPlayer or not localPlayer.m_hPawn then
        if blockbot_state.bot_has_active_jump_command then 
            CVar.ExecuteClientCmd("-jump")
            blockbot_state.bot_has_active_jump_command = false 
        end
        blockbot_state.blockEnemy = nil
        blockbot_state.currentTarget = nil
        return
    end

    local localPlayerPawn = Entities.GetEntityFromHandle(localPlayer.m_hPawn)
    if not localPlayerPawn or not localPlayerPawn.m_pGameSceneNode then
        if blockbot_state.bot_has_active_jump_command then 
            CVar.ExecuteClientCmd("-jump")
            blockbot_state.bot_has_active_jump_command = false 
        end
        blockbot_state.blockEnemy = nil
        blockbot_state.currentTarget = nil
        return
    end

    local localPlayerOrigin = localPlayerPawn.m_pGameSceneNode.m_vecAbsOrigin
    local bestTeammatePawn = nil
    local bestDistance = math.huge

    for i = 1, 64 do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_iTeamNum == localPlayer.m_iTeamNum and entity ~= localPlayer and entity.m_hPawn then
            local teammatePawn = Entities.GetEntityFromHandle(entity.m_hPawn)
            if teammatePawn and teammatePawn.m_pGameSceneNode and teammatePawn.m_bPawnIsAlive then
                local distance = localPlayerOrigin:DistTo(teammatePawn.m_pGameSceneNode.m_vecAbsOrigin)
                if distance < bestDistance and distance < 1000 then
                    bestDistance = distance
                    bestTeammatePawn = teammatePawn
            end
        end
    end
end

    if bestTeammatePawn then
        blockbot_state.blockEnemy = bestTeammatePawn
        blockbot_state.currentTarget = bestTeammatePawn
    else
        blockbot_state.blockEnemy = nil
        blockbot_state.currentTarget = nil
    end

    if blockbot_state.blockEnemy and blockbot_state.blockEnemy.m_pGameSceneNode then
        local targetOrigin = blockbot_state.blockEnemy.m_pGameSceneNode.m_vecAbsOrigin
        local direction = (targetOrigin - localPlayerOrigin):Normalized()
        
        if blockbot_mode:GetInt() == 0 then
            cmd.viewangles = direction:ToEulerAngles()
        else
            local forward = direction
            local right = Vector(0, 0, 1):Cross(forward):Normalized()
            local up = forward:Cross(right):Normalized()
            
            local targetPos = targetOrigin + forward * 50
            local moveDirection = (targetPos - localPlayerOrigin):Normalized()
            
            cmd.forwardmove = moveDirection.x * 450
            cmd.sidemove = moveDirection.y * 450
        end

        if autojump_enabled:GetBool() and not localPlayerPawn.m_bPawnIsAlive then
            if not blockbot_state.bot_has_active_jump_command then
                CVar.ExecuteClientCmd("+jump")
                blockbot_state.bot_has_active_jump_command = true
            end
        end
    end
end

local function get_spectators()
    local local_player = nil
	for i = 1, 64 do
		local entity = Entities.GetEntityFromIndex(i)
		if entity and entity.m_bIsLocalPlayerController then
            local_player = entity.m_hPawn
			break
		end
	end
    if not local_player then return {} end
    
    local spectators = {}
	for i = 1, 64 do
		local entity = Entities.GetEntityFromIndex(i)
		if entity and not entity.m_bIsHLTV and not entity.m_bPawnIsAlive then
			local pawn = entity.m_hObserverPawn
			if pawn then
				local observer_services = pawn.m_pObserverServices
				if observer_services then
                    local target = Entities.GetEntityFromHandle(observer_services.m_hObserverTarget)
                    if target and target == local_player then
                        table.insert(spectators, entity.m_sSanitizedPlayerName or "Unknown")
					end
				end
			end
		end
	end
    return spectators
end

local function draw_spectator_names()
    if not spectator_enabled:GetBool() and not (Input.IsMenuOpen and Input.IsMenuOpen()) then return end
    local spectators = get_spectators and get_spectators() or {}
    
    if #spectators == 0 and not (Input.IsMenuOpen and Input.IsMenuOpen()) then return end
    
    local spec_x = spectator_pos_x
    local spec_y = spectator_pos_y
    local font = "wm_font_spec"
    local box_w = 200
    local box_h = #spectators * 18 + 22
    if #spectators == 0 then box_h = 42 end
    
    if Input.IsMenuOpen and Input.IsMenuOpen() then
        local mouse = Input.GetCursorPos and Input.GetCursorPos() or {x=0, y=0}
        local mouse_down = Input.GetKeyDown and Input.GetKeyDown(0x01)

        
        if not spectator_drag.dragging then
            if mouse_down and mouse.x >= spec_x and mouse.x <= spec_x + box_w and mouse.y >= spec_y and mouse.y <= spec_y + box_h then
                spectator_drag.dragging = true
                spectator_drag.offset_x = mouse.x - spec_x
                spectator_drag.offset_y = mouse.y - spec_y
            end
        else
            if mouse_down then
                local new_x = mouse.x - spectator_drag.offset_x
                local new_y = mouse.y - spectator_drag.offset_y
                

                
                spectator_pos_x = new_x
                spectator_pos_y = new_y
            else
                spectator_drag.dragging = false
            end
        end
        

    end
    
    local bg = Color(30, 35, 45, box_opacity:GetInt())
    if style_selection == 1 then
        -- Green theme
        bg = Color(20, 35, 25, box_opacity:GetInt())
    elseif style_selection == 2 then
        -- Orange theme
        bg = Color(35, 25, 15, box_opacity:GetInt())
    elseif style_selection == 3 then
        -- Red theme
        bg = Color(35, 20, 20, box_opacity:GetInt())
    end
    
    local start = Vector2D(spec_x, spec_y)
    local finish = Vector2D(spec_x + box_w, spec_y + box_h)
    
    Renderer.DrawRectFilled(start, finish, bg, 4)
    
    if style_selection ~= 4 then
        local line_y = start.y + 0.1
        local gradient_start = Vector2D(start.x + 1, line_y)
        local gradient_end = Vector2D(finish.x - 1, line_y)
        local width = gradient_end.x - gradient_start.x
        for i = 0, width do
            local t = i / width
            local r, g, b
            if style_selection == 1 then
                
                r = 0
                g = 255
                b = 100
            elseif style_selection == 2 then
                
                r = 255
                g = 165
                b = 0
            elseif style_selection == 3 then
                
                r = 255
                g = 50
                b = 50
            else
                
                r = lerp(100, 150, t)
                g = lerp(150, 100, t)
                b = lerp(255, 200, t)
            end
            local alpha = 255
            if i < 3 then
                alpha = lerp(0, 255, i / 3)
            elseif i > width - 3 then
                alpha = lerp(255, 0, (i - (width - 3)) / 3)
            end
            Renderer.DrawLine(
                Vector2D(gradient_start.x + i, line_y - 0.1),
                Vector2D(gradient_start.x + i, line_y + 2),
                Color(r, g, b, math.floor(alpha)),
                1
            )
        end
    end

    local white = Color(255, 255, 255, 255)
    local title_width = Renderer.CalcTextSize and Renderer.CalcTextSize("wm_font_spec", "Spectators").x or #"Spectators" * 7
    local title_x = spec_x + (box_w - title_width) / 2
    Renderer.DrawText("wm_font_spec", "Spectators", Vector2D(title_x, spec_y + 5), false, false, white)
    
    if #spectators == 0 and (Input.IsMenuOpen and Input.IsMenuOpen()) then
        local preview_names = {"Player1", "Player2", "Player3"}
        for i, name in ipairs(preview_names) do
            Renderer.DrawText(font, name, Vector2D(spec_x + 10, spec_y + 25 + (i-1)*18), false, false, Color(255,255,255,240))
        end
        return
    end
    
    for i, name in ipairs(spectators) do
        Renderer.DrawText(font, name, Vector2D(spec_x + 10, spec_y + 25 + (i-1)*18), false, false, Color(255,255,255,240))
    end
end
Cheat.RegisterCallback("OnRenderer", draw_spectator_names)

local function render_sound_esp()
    if not sound_esp_enabled:GetBool() then return end

    local currentTime = Globals.GetCurrentTime()
    local indicatorsToRemove = {}

    local localPlayerPawn = nil
    for i = 1, 64 do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_bIsLocalPlayerController and entity.m_hPawn then
            localPlayerPawn = Entities.GetEntityFromHandle(entity.m_hPawn)
            break
        end
    end

    local localPlayerPosition = nil
    if localPlayerPawn and localPlayerPawn.m_pGameSceneNode and localPlayerPawn.m_pGameSceneNode.m_vecAbsOrigin then
        localPlayerPosition = localPlayerPawn.m_pGameSceneNode.m_vecAbsOrigin
    end

    local peakDrawingRadius = sound_peak_radius:GetInt()

    for i, indicator in ipairs(sound_runtime_state.active_sound_indicators) do
        if not indicator.initial_distance_check_passed then
            goto continue_loop
        end

        local elapsedTime = currentTime - indicator.startTime

        if elapsedTime > indicator.duration then
            table.insert(indicatorsToRemove, i)
        else
            local baseColor = Color(100, 150, 255, 255)
            
            if localPlayerPosition and indicator.position and indicator.eventRadius then
                local distance = localPlayerPosition:DistTo(indicator.position)
                
                local maxDistance = indicator.eventRadius
                local normalizedDistance = math.min(distance / maxDistance, 1.0)
                
                local alpha = math.floor(255 * (1.0 - elapsedTime / indicator.duration))
                local color = Color(baseColor.r, baseColor.g, baseColor.b, alpha)
                
                local screenPos = Renderer.WorldToScreen(indicator.position)
                if screenPos then
                    local radius = math.max(5, peakDrawingRadius * (1.0 - elapsedTime / indicator.duration))
                    Renderer.DrawCircleFilled(screenPos, color, radius)
                end
            end
        end
        ::continue_loop::
    end

    for i = #indicatorsToRemove, 1, -1 do
        table.remove(sound_runtime_state.active_sound_indicators, indicatorsToRemove[i])
    end

    for soundId, soundTime in pairs(sound_runtime_state.processed_sounds) do
        if currentTime - soundTime > 5.0 then
            sound_runtime_state.processed_sounds[soundId] = nil
        end
    end
end

local function render_dmg_markers()
    if not dmgmarkers_enabled:GetBool() then return end

    local dt = Globals.GetFrameTime()

    for i = 1, hit_effects_state.num_hitmarkers do
        local hm = hit_effects_state.hitmarkers[i]
        hm.opacity = hm.opacity - dt * hit_effects_state.fade_rate
        hm.offset = hm.offset + dt * hit_effects_state.rise_speed
        
        if hm.opacity > 0 then
            local sp = Renderer.WorldToScreen(hm.position)
            if sp then
                sp.y = sp.y - 15 - hm.offset
                local alpha = math.floor(hm.opacity * 255)
                local color = Color(100, 150, 255, alpha)
                Renderer.DrawText("wm_font", tostring(hm.damage), sp, true, true, color)
            end
        end
    end

    for i = hit_effects_state.num_hitmarkers, 1, -1 do
        if hit_effects_state.hitmarkers[i].opacity <= 0 then
            for j = i, hit_effects_state.num_hitmarkers - 1 do
                hit_effects_state.hitmarkers[j] = hit_effects_state.hitmarkers[j + 1]
            end
            hit_effects_state.hitmarkers[hit_effects_state.num_hitmarkers] = nil
            hit_effects_state.num_hitmarkers = hit_effects_state.num_hitmarkers - 1
        end
    end
end

Cheat.RegisterCallback("OnRenderer", render_sound_esp)
Cheat.RegisterCallback("OnRenderer", render_dmg_markers)
Cheat.RegisterCallback("OnCreateMove", BlockbotLogic)
Cheat.RegisterCallback("OnRenderer", HandleBlockBotInput)

create_custom_menu()

-- Weapon Models callback - Sadeleştirilmiş versiyon
local function OnFrameStageNotify(stage)
    if stage ~= 6 or not weapon_models_enabled:GetBool() then
        return
    end

    local pawn = nil
    for i = 1, 64 do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_bIsLocalPlayerController then
            pawn = entity.m_hPawn
            break
        end
    end

    if not pawn then return end
    
    local wpn_services = pawn.m_pWeaponServices
    if not wpn_services then return end

    local weapon = Entities.GetEntityFromIndex(wpn_services.m_hActiveWeapon)
    if not weapon then return end

    -- Basit weapon model değiştirme
    if weapon_model_selection:GetInt() > 0 then
        local model_names = {"ak47", "m4a1", "awp", "deagle", "glock"}
        local selected_model = model_names[weapon_model_selection:GetInt()]
        if selected_model then
            -- Model değiştirme işlemi burada yapılacak
        end
    end
end

Cheat.RegisterCallback("OnFrameStageNotify", OnFrameStageNotify)

-- Sound ESP fonksiyonu - tekrarlanmış olanı kaldır
local function render_sound_esp()
    if not sound_esp_enabled:GetBool() then 
        return 
    end

    local currentTime = Globals.GetCurrentTime()
    local indicatorsToRemove = {}

    local localPlayerPawn = nil
    for i = 1, 64 do
        local entity = Entities.GetEntityFromIndex(i)
        if entity and entity.m_bIsLocalPlayerController and entity.m_hPawn then
            localPlayerPawn = Entities.GetEntityFromHandle(entity.m_hPawn)
            break
        end
    end

    local localPlayerPosition = nil
    if localPlayerPawn and localPlayerPawn ~= 0 and localPlayerPawn.m_pGameSceneNode and localPlayerPawn.m_pGameSceneNode.m_vecAbsOrigin then
        localPlayerPosition = localPlayerPawn.m_pGameSceneNode.m_vecAbsOrigin
    end

    local peakDrawingRadius = sound_peak_radius:GetInt()

    for i, indicator in ipairs(sound_runtime_state.active_sound_indicators) do
        if not indicator.initial_distance_check_passed then
            goto continue_loop
        end

        local elapsedTime = currentTime - indicator.startTime

        if elapsedTime > indicator.duration then
            table.insert(indicatorsToRemove, i)
        else
           
            local baseColor = Color(255, 255, 255)
            
            
            if localPlayerPosition and indicator.position and indicator.eventRadius then
                local distance = localPlayerPosition:DistTo(indicator.position)
                
                local maxDistance = indicator.eventRadius
                local normalizedDistance = math.min(distance / maxDistance, 1.0)
                
                
                if normalizedDistance <= 0.33 then
                    baseColor = Color(255, 0, 0) 
                elseif normalizedDistance <= 0.66 then
                    baseColor = Color(255, 255, 0) 
                else
                    baseColor = Color(0, 255, 0) 
                end
            end

            local currentRadius
            local currentAlpha

            local currentPeakRadius = (peakDrawingRadius * 0.5) + (indicator.eventRadius / 15) 
            currentPeakRadius = math.min(currentPeakRadius, 50)

            local expansionPhaseDuration = indicator.duration * 0.3
            local shatterPhaseDuration = indicator.duration * 0.4

            if elapsedTime <= expansionPhaseDuration then
                local progress = elapsedTime / expansionPhaseDuration
                currentRadius = currentPeakRadius * progress
                currentAlpha = 255
                
                local drawColor = Color(baseColor.r, baseColor.g, baseColor.b, math.floor(currentAlpha))
                Renderer.DrawCircle3D(indicator.position, drawColor, math.max(1, math.floor(currentRadius)))
            else
                local progressInShatter = (elapsedTime - expansionPhaseDuration) / shatterPhaseDuration
                
                local numFragments = 6
                local fragmentSpread = 5 + (indicator.eventRadius / 60)
                
                local fragmentBaseSize = 2

                for f = 0, numFragments - 1 do
                    local fragmentAngle = (f / numFragments) * 2 * math.pi + (currentTime * 5)
                    
                    local startFragmentRadius = currentPeakRadius * 0.8
                    local currentFragmentRadius = startFragmentRadius + (fragmentSpread * progressInShatter)
                    
                    currentFragmentRadius = math.min(currentFragmentRadius, currentPeakRadius + 15)

                    local fragmentX = indicator.position.x + math.cos(fragmentAngle) * currentFragmentRadius
                    local fragmentY = indicator.position.y + math.sin(fragmentAngle) * currentFragmentRadius
                    local fragmentZ = indicator.position.z

                    local fragmentPosition = Vector(fragmentX, fragmentY, fragmentZ)

                    local fragmentAlpha = 255 * (1 - progressInShatter)
                    fragmentAlpha = math.max(0, math.floor(fragmentAlpha))

                    local fragmentSize = math.max(1, math.floor(fragmentBaseSize * (1 - progressInShatter * 0.5)))
                    
                    local fragmentColor = Color(baseColor.r, baseColor.g, baseColor.b, fragmentAlpha)
                    Renderer.DrawCircle3D(fragmentPosition, fragmentColor, fragmentSize)
                end
            end
        end
        ::continue_loop::
    end

    for i = #indicatorsToRemove, 1, -1 do
        table.remove(sound_runtime_state.active_sound_indicators, indicatorsToRemove[i])
    end
    
    local ticksToKeep = currentTime - 10.0
    for soundId, soundTime in pairs(sound_runtime_state.processed_sounds) do
        if soundTime < ticksToKeep then
            sound_runtime_state.processed_sounds[soundId] = nil
        end
    end
end

Cheat.RegisterCallback("OnRenderer", render_sound_esp)

--this lua Made By Balendin(balendin5559)